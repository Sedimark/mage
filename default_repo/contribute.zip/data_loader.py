import pandas as pd

if 'data_loader' not in globals():
    from mage_ai.data_preparation.decorators import data_loader


@data_loader
def load_data_broker(*args, **kwargs):

    return pd.DataFrame() # or python dict
