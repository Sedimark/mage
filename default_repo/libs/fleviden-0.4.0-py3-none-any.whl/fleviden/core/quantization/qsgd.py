# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements the Quantized Stochastic Gradient Descent Algorithm [1].

Reference:

[1] Alistarh, D., Grubic, D., Li, J., Tomioka, R., & Vojnovic, M. (2017).
QSGD: Communication-efficient SGD via gradient quantization and encoding.
Advances in neural information processing systems, 30.
"""

import random

import numpy as np
from BitVector import BitVector

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Qsgd(Pod):
    """An implementation of the full QSGD algorithm for lossy compression.

    The algorithm is divided in two blocks:

        1. Quantization of the real-numbered vector.

        2. Encoding to bitstream.

    The first functionality is implemented in the `_quantize()` and `_dequantize()`
    functions. The second is implemented in the `_elias_encode()` and `_elias_decode()`
    ones.

    The encoding transforms the vector into a BitVector,
    while the decoding performs the inverse transformation.
    """

    def __init__(
        self,
        num_levels: int,
        entries: list,
        scaling: str = 'l2norm',
        replace: bool = True,
        encode: bool = True,
    ):
        """Creates a new Qsgd pod.

        Parameters
        ----------
            num_levels : int
                Number of quantization levels.

            entries : list[str]
                Entries to encode/decode.

            scaling : str, optional
                How the scaling factor is computed in the quantization step.
                Supported: l2-norm, l1-norm or max. Default is 'l2norm'.

            replace : bool, optional
                If True, the entries in the request dictionary are replaced by the outputs.
                If False, a new entry is added with the name "[entry]_qsgd_[encoded/decoded]",
                e.g., "weights_qsgd_encoded". Default is True.

            encode : bool, optional
                If True, the entries are encoded to bistream.

        Inputs
        ------
            Interfaces.ENCODE (/encode)
                Triggers the encoding of the specified entries in the request dictionary.

            Interfaces.DECODE (/decode)
                Triggers the decoding of the specified entries in the request dictionary.

        Outputs
        -------
            Interfaces.ENCODED (/encoded)
                After all the entries have been encoded.

            Interfaces.DECODED (/decoded)
                After all the entries have been decoded.

        """
        super().__init__()

        self.num_levels = num_levels
        self.scaling = scaling
        self.entries = entries
        self.replace = replace
        self.encode = encode

        self.register(Interfaces.ENCODE, self._encode)
        self.register(Interfaces.ENCODED)

        self.register(Interfaces.DECODE, self._decode)
        self.register(Interfaces.DECODED)

    async def _encode(self, req: dict) -> None:
        """Performs the encoding of the specified entries in the
        request dictionary.

        Parameters
        ----------
            req : dict
                The request dictionary containing the keys
                listed in the entries parameter.

        Triggers
        --------
            Interfaces.ERROR (/error)
                If the entry is not a vector of numbers.

            Interfaces.WARNING (/warning)
                If the req dictionary doesn't contain an entry.

            Interfaces.ENCODED (/encoded)
                After all the entries have been encoded.
        """

        for entry in self.entries:
            if entry not in req:
                await self.trigger(
                    Interfaces.WARNING,
                    mandatory=False,
                    req={**req, **self.__get_invalid_key_warning(entry)},
                )
            else:
                vector = np.array(req[entry])

                if not np.issubdtype(vector.dtype, np.number):
                    await self.trigger(
                        Interfaces.ERROR,
                        mandatory=False,
                        req={**req, **self.__get_value_error(vector)},
                    )
                    break

                entry_key = entry
                if not self.replace:
                    entry_key = entry + "_qsgd_encoded"  # For example: req["weights_qsgd_encoded"]

                scale, sigma, delta = self._quantize(vector)
                if self.encode:
                    encoded = self._elias_encode(scale, sigma, delta)
                    encoded_key = entry + "_encoded"  # For example: weights_encoded
                    req[entry_key] = {encoded_key: encoded, 'num_levels': self.num_levels}
                else:
                    req[entry_key] = {
                        "scale": scale,
                        "sigma": sigma,
                        "delta": delta,
                        "num_levels": self.num_levels,
                    }

        await self.trigger(Interfaces.ENCODED, req)

    async def _decode(self, req: dict) -> None:
        """Performs the decoding of the specified entries in the
        request dictionary.

        Parameters
        ----------
            req : dict
                The request dictionary containing the keys
                listed in the entries parameter.

        Triggers
        --------
            Interfaces.WARNING (/warning)
                If the req dictionary doesn't contain an entry.

            Interfaces.DECODED (/decoded)
                After all the entries have been decoded.
        """

        for entry in self.entries:
            if entry not in req:
                await self.trigger(
                    Interfaces.WARNING,
                    mandatory=False,
                    req={**req, **self.__get_invalid_key_warning(entry)},
                )
            else:
                entry_key = entry
                if not self.replace:
                    entry_key = entry + "_qsgd_decoded"  # For example: req["weights_qsgd_decoded"]

                # Use num_levels of the req if key is present. Else, use the pod's num_levels
                if 'num_levels' in req[entry]:
                    num_levels = req[entry]['num_levels']
                else:
                    num_levels = self.num_levels

                if self.encode:
                    encoded_key = entry + "_encoded"
                    encoded = req[entry][encoded_key]
                    scale, sigma, delta = self._elias_decode(encoded)
                else:
                    scale, sigma, delta = (
                        req[entry]['scale'],
                        req[entry]['sigma'],
                        req[entry]['delta'],
                    )

                decoded = self._dequantize(scale, sigma, delta, num_levels=num_levels)

                req[entry_key] = decoded

        await self.trigger(Interfaces.DECODED, req)

    def _quantize(self, vector: np.ndarray):
        """
        Quantizes a vector with the number of quantization levels.

        Parameters
        ----------
        vector : ndarray
            Vector to quantize.

        Returns
        -------
        scale : float
            Scaling factor of the vector.
        sigma : ndarray
            Vector encoding the sign of the values.
        delta : ndarray
            Vector of the quantization interval of the values.
        """
        sigma = np.sign(vector)
        scale, delta = self._get_scale_delta(vector)

        return scale, sigma, delta

    def _dequantize(
        self, scale: float, sigma: np.ndarray, delta: np.ndarray, num_levels: int
    ) -> np.ndarray:
        """Dequantizes a vector provided in the form of scale, sign
        and quantized intervals.

        Parameters
        -----------
            scale : float
                Scaling factor of the vector.

            sigma : ndarray
                Vector encoding the sign of the values.

            delta : ndarray
                Vector of the quantization interval of the values.

            num_levels : int, optional
                Number of quantization levels.

        Returns
        -------
            vector : ndarray
                Vector to quantize.
        """
        decoded = np.array(scale * sigma * delta / num_levels)

        return decoded

    def _elias_encode(self, scale: float, sigma: np.ndarray, delta: np.ndarray) -> BitVector:
        """Encodes a quantized vector following the QSGD scheme.

        Parameters
        -----------
            scale : float
                Scaling factor of the vector.

            sigma : ndarray
                Vector encoding the sign of the values.

            delta : ndarray
                Vector of the quantization interval
                of the values.

        Returns
        -------
            code : bitvector
                Bitstream with the encoded vector.
        """
        # 1) Initialize BitVector.
        encoded = BitVector(size=0)

        # 2) Encode the length of the deltas.
        encoded += self._elias(len(delta))

        # 3) Encode the scaling factor in the next 32 bits.
        scale_bv = BitVector(intVal=np.float32(scale).view(np.int32))
        scale_bv.pad_from_left(32 - scale_bv.length())  # Pad to fill 32 bits
        encoded += scale_bv

        # 4) Encode the relative indices, sign and delta of nonzero values.
        previous = 0

        for i, value in enumerate(delta):
            if value != 0:
                # 4.1) Encode relative index (+1)
                encoded += self._elias((i - previous) + 1)  # The +1 is to avoid Elias(0)

                # 4.2) Append the sign bit
                signbit = int(0 if sigma[i] < 0 else 1)
                encoded += BitVector(intVal=signbit)

                # 4.3) Encode the delta value
                encoded += self._elias(value)

                previous = i

        return encoded

    def _elias_decode(self, code: BitVector) -> tuple[float, np.ndarray, np.ndarray]:
        """Decodes the bitstream encoded with the QSGD scheme.

        Parameters
        -----------
            code : bitvector
                Bitstream with the encoded vector.

        Returns
        ----------
            scale : float
                Scaling factor of the vector.

            sigma : ndarray
                Vector encoding the sign of the values.

            delta : ndarray
                Vector of the quantization interval
                of the values.
        """
        # 0) Remove possible padding
        first_bit = code.next_set_bit(0)  # Find first bit to remove zero padding
        code = code[first_bit:]

        # 1) Decode the length of the deltas
        length, code = self._delias(code)

        # 2) Decode scaling factor from the next 32 bits
        scale = np.int32(code[:32].int_val()).view(np.float32)
        code = code[32:]

        # 3) Decode indices, signs and nonzero delta values
        sigma = np.ones(length)
        delta = np.zeros(length)
        last_position = 0

        while len(code) > 1:
            # 3.1) Decode relative index
            pos, code = self._delias(code)
            pos -= 1  # The encoder adds +1 to the indices

            # 3.2) Decode sign bit
            sign = -1 if code[0] == 0 else 1

            # 3.3) Decode delta value
            value, code = self._delias(code[1:])

            idx = last_position + pos
            delta[idx] = int(value)
            sigma[idx] = int(sign)

            last_position = idx

        return scale, sigma, delta

    # Auxiliary functions for quantize()
    def _get_scaling_factor(self, vector: np.ndarray) -> float:
        """Computes the scaling factor of the quantized vector as either the
        norm of the max value.

        The max value preserves more values (lower error), but doesn't
        have the sparsity guarantees of the l2 norm.

        Parameters
        ----------
            vector : ndarray
                Real-numbered vector.

        Returns
        -------
            scale : float
                Scaling factor.
        """

        if self.scaling in ['l2norm', 'l2', '2', 'l2-norm']:
            return np.linalg.norm(vector)

        if self.scaling in ['l1norm', 'l1', '1', 'l1-norm']:
            return np.linalg.norm(vector, 1)

        if self.scaling in ['max']:
            return np.max(vector)

        return np.linalg.norm(vector)

    def _find_quantization_interval(self, value: float) -> int:
        """Finds the quantization interval of a normalized value given the
        number of quantization levels. In this context, normalized means
        that it has been divided by the scaling factor.

        The output interval can be either l or l+1, with a probability that
        is inversely proportional to the distance of the value to the boundaries.
        For example: with only 2 quantization levels, a value 0.4 could be assigned
        l=0 with 60% change and l=1 with 40% chance.

        Parameters
        ----------
            value : float
                Normalized value of a vector.

        Returns
        -------
            l : int
                Quantization interval.
        """

        for i in range(self.num_levels):
            if value <= (i + 1) / self.num_levels:
                r = random.uniform(0, 1)
                p = value * self.num_levels - i
                if r < 1 - p:
                    return i
                return i + 1

    def _get_scale_delta(self, vector: np.ndarray) -> tuple[float, np.ndarray]:
        """Computes the quantized intervals of a real-numbered vector.

        Parameters
        ----------
            vector : ndarray

        Returns
        -------
            scale : float
                The scaling factor.

            delta : ndarray
                Vector of quantized levels.
        """

        # 1) Get the scaling factor and convert it to bitvector
        scale = self._get_scaling_factor(vector)

        # 2) Get the vector of quantized intervals
        delta = np.array([self._find_quantization_interval(abs(value) / scale) for value in vector])

        return scale, delta

    # Auxiliary functions for elias_encode() and elias_decode()
    def _elias(self, n: int, code: BitVector = BitVector(intVal=0)):
        """Encodes an integer number with its Elias-omega code.
        Elias-omega code is only defined for n > 1.

        Parameters
        ------------
            n : int
                Number to decode.

        Returns
        -------
            code : bitvector
                Elias-omega code of n.
        """

        if n == 1:
            return code

        binary = BitVector(intVal=n)

        n = len(binary) - 1

        return self._elias(n, binary + code)

    def _delias(self, code: BitVector, n: int = 1) -> BitVector:
        """Decodes the Elias-omega code into an integer.

        Parameters
        -----------
            code : bitvector
                Bitstream with the Elias-omega code.

            n : int
                Integer number.

        Returns
        -------
            code : bitvector
                Bitstream with the remaining Elias-omega code.
        """

        if code[0] == 0:
            return n, code[1:]

        begin = code[: 1 + n]
        end = code[1 + n :]
        n = begin.int_val()

        return self._delias(end, n)

    def __get_invalid_key_warning(self, entry) -> dict:
        name = "MissingKey"
        description = "The key is not present in the request dictionary."
        details = {"invalid_key": entry}
        return super()._get_warning(name, description, details)

    def __get_value_error(self, vector) -> dict:
        name = "ValueError"
        description = "The input vector does not contain numerical values."
        details = {"invalid_type": vector.dtype}
        return super()._get_error(name, description, details)
