# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""


import tempfile
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, patch

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset

from fleviden.core.interfaces import Interfaces
from fleviden.core.trainers.pytorch import Pytorch


class SimpleModel(nn.Module):
    def __init__(self):
        super(SimpleModel, self).__init__()
        self.fc = nn.Linear(20, 1)

    def forward(self, x):
        return self.fc(x)


def create_and_save_architecture(filepath):
    architecture = """
import torch.nn as nn

class SimpleModel(nn.Module):
    def __init__(self):
        super(SimpleModel, self).__init__()
        self.fc = nn.Linear(20, 1)

    def forward(self, x):
        return self.fc(x)
"""
    with open(filepath, 'w') as f:
        f.write(architecture)


def create_and_save_model(filepath, with_optimizer=True):
    # Create a simple classification dataset
    model = SimpleModel()
    loss_function = nn.BCEWithLogitsLoss()
    optimizer = optim.Adam(model.parameters(), lr=1e-3)

    # Save the model
    if with_optimizer:
        checkpoint = {
            'model_state': model.state_dict(),
            'optimizer_class_name': optimizer.__class__.__name__,
            'optimizer_state': optimizer.state_dict(),
            'loss': loss_function,
            'loss_class_name': loss_function.__class__.__name__,
            'loss_state': loss_function.state_dict(),
        }
    else:
        checkpoint = {
            'model_state': model.state_dict(),
            'loss': loss_function,
            'loss_class_name': loss_function.__class__.__name__,
            'loss_state': loss_function.state_dict(),
        }

    torch.save(checkpoint, filepath)


class TestPytorch(IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp_arch_file = tempfile.NamedTemporaryFile(suffix='.py', delete=True)
        create_and_save_architecture(self.temp_arch_file.name)

        self.temp_model_file = tempfile.NamedTemporaryFile(suffix='.pth', delete=True)
        create_and_save_model(self.temp_model_file.name)

        self.temp_model_no_optim_file = tempfile.NamedTemporaryFile(suffix='.pth', delete=True)
        create_and_save_model(self.temp_model_no_optim_file.name, with_optimizer=False)

        self.temp_model_save_file = tempfile.NamedTemporaryFile(suffix='.pth', delete=True)
        self.temp_weights_save_file = tempfile.NamedTemporaryFile(suffix='.pth', delete=True)

    def tearDown(self):
        # Clean up the temporary model file
        self.temp_arch_file.close()
        self.temp_model_file.close()

    async def test_load_model(self):
        # Load the model
        mock_loaded = AsyncMock()

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_file.name, modulepath=self.temp_arch_file.name
        )

        pod_pytorch.register(Interfaces.LOADED_MODEL, mock_loaded)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})

        mock_loaded.assert_called()
        req = mock_loaded.call_args[0][0]
        self.assertIn('weights', req)

    async def test_load_model_no_optimizer(self):
        # Load the model
        mock_loaded = AsyncMock()

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_no_optim_file.name,
            modulepath=self.temp_arch_file.name,
        )

        pod_pytorch.register(Interfaces.LOADED_MODEL, mock_loaded)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})

        mock_loaded.assert_called()
        req = mock_loaded.call_args[0][0]
        self.assertIn('weights', req)

    async def test_load_from_file(self):
        # Load the model
        mock_loaded = AsyncMock()

        filepath = self.temp_model_file.name
        modulepath = self.temp_arch_file.name

        pod_pytorch = Pytorch(load_model_filepath="not-a-filepath", modulepath="not-a-modulepath")

        pod_pytorch.register(Interfaces.LOADED_MODEL, mock_loaded)

        await pod_pytorch.trigger(
            Interfaces.LOAD_MODEL, {"filepath": filepath, "modulepath": modulepath}
        )

        mock_loaded.assert_called()
        req = mock_loaded.call_args[0][0]
        self.assertIn('weights', req)

    async def test_load_error(self):
        # Load the model
        mock_loaded = AsyncMock()
        mock_error = AsyncMock()

        pod_pytorch = Pytorch(
            load_model_filepath="not-a-filepath", modulepath=self.temp_arch_file.name
        )

        pod_pytorch.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_pytorch.register(Interfaces.ERROR, mock_error)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})

        mock_loaded.assert_not_called()
        mock_error.assert_called()

    async def test_train_weights(self):
        # Train the model
        mock_loaded = AsyncMock()
        mock_trained = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        epochs = 1
        batch_size = 32
        dataloader_args = {"num_workers": 0, "shuffle": True}
        req = {
            'features': features,
            'targets': targets,
            'epochs': epochs,
            'batch_size': batch_size,
            'dataloader_args': dataloader_args,
        }

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_file.name,
            modulepath=self.temp_arch_file.name,
            send_gradients=False,
        )

        pod_pytorch.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_pytorch.register(Interfaces.TRAINED, mock_trained)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_pytorch.trigger(Interfaces.TRAIN, {**req, **req_load})

        mock_trained.assert_called()
        req = mock_trained.call_args[0][0]
        self.assertIn('weights', req)

    async def test_train_weights_send_gradients(self):
        # Train the model
        mock_loaded = AsyncMock()
        mock_trained = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        epochs = 1
        batch_size = 32
        dataloader_args = {"num_workers": 0, "shuffle": True}
        req = {
            'features': features,
            'targets': targets,
            'epochs': epochs,
            'batch_size': batch_size,
            'dataloader_args': dataloader_args,
        }

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_file.name,
            modulepath=self.temp_arch_file.name,
            send_gradients=True,
        )

        pod_pytorch.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_pytorch.register(Interfaces.TRAINED, mock_trained)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_pytorch.trigger(Interfaces.TRAIN, {**req, **req_load})

        mock_trained.assert_called()
        req = mock_trained.call_args[0][0]
        self.assertIn('gradients', req)

    async def test_custom_dataset_class(self):

        class CustomDataset(Dataset):
            def __init__(self, features, targets):
                self.features = torch.tensor(np.array(features), dtype=torch.float32)
                self.targets = torch.tensor(np.array(targets), dtype=torch.float32)

            def __len__(self):
                return len(self.features)

            def __getitem__(self, idx):
                return self.features[idx], self.targets[idx]

        # Train the model
        mock_loaded = AsyncMock()
        mock_trained = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        epochs = 1
        batch_size = 32
        dataloader_args = {"num_workers": 0, "shuffle": True}
        req = {
            'features': features,
            'targets': targets,
            'epochs': epochs,
            'batch_size': batch_size,
            'dataloader_args': dataloader_args,
        }

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_file.name,
            modulepath=self.temp_arch_file.name,
            custom_dataset_class=CustomDataset,
            send_gradients=False,
        )

        pod_pytorch.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_pytorch.register(Interfaces.TRAINED, mock_trained)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_pytorch.trigger(Interfaces.TRAIN, {**req, **req_load})

        mock_trained.assert_called()
        req = mock_trained.call_args[0][0]
        self.assertIn('weights', req)

    async def test_evaluate_model(self):
        # Train the model
        mock_evaluated = AsyncMock()
        mock_loaded = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        completed = True

        req = {'features': features, 'targets': targets, 'completed': completed}

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_file.name,
            modulepath=self.temp_arch_file.name,
            metrics=['neg_mean_squared_error'],
        )
        pod_pytorch.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_pytorch.register(Interfaces.EVALUATED, mock_evaluated)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_pytorch.trigger(Interfaces.EVALUATE, {**req, **req_load})

        mock_evaluated.assert_called()
        req = mock_evaluated.call_args[0][0]

    async def test_predict_model(self):
        # Train the model
        mock_predicted = AsyncMock()
        mock_loaded = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        identifiers = np.random.randint(100, size=(100, 1))

        req = {'features': features, 'targets': targets, 'identifiers': identifiers}

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_file.name, modulepath=self.temp_arch_file.name
        )
        pod_pytorch.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_pytorch.register(Interfaces.PREDICTED, mock_predicted)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_pytorch.trigger(Interfaces.PREDICT, {**req, **req_load})

        mock_predicted.assert_called()
        req = mock_predicted.call_args[0][0]

    async def test_update_weights_with_gradients(self):
        mock_updated = AsyncMock()

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_file.name, modulepath=self.temp_arch_file.name
        )
        pod_pytorch.register(Interfaces.UPDATED_WEIGHTS, mock_updated)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})

        grads = np.random.random(np.array(pod_pytorch.weights).shape).tolist()
        expected_weights = np.array(pod_pytorch.weights) - np.array(grads)

        await pod_pytorch.trigger(Interfaces.UPDATE_WEIGHTS, {'gradients': grads})
        mock_updated.assert_called()

        np.testing.assert_array_equal(pod_pytorch.weights, expected_weights)

    async def test_update_weights_with_weights(self):
        mock_updated = AsyncMock()

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_file.name, modulepath=self.temp_arch_file.name
        )
        pod_pytorch.register(Interfaces.UPDATED_WEIGHTS, mock_updated)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})

        new_weights = np.random.random(np.array(pod_pytorch.weights).shape).tolist()

        await pod_pytorch.trigger(Interfaces.UPDATE_WEIGHTS, {'weights': new_weights})

        mock_updated.assert_called()
        np.testing.assert_array_equal(pod_pytorch.weights, new_weights)

    async def test_update_weights_warning(self):
        mock_updated = AsyncMock()
        mock_error = AsyncMock()

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_file.name, modulepath=self.temp_arch_file.name
        )
        pod_pytorch.register(Interfaces.UPDATED_WEIGHTS, mock_updated)
        pod_pytorch.register(Interfaces.ERROR, mock_error)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})
        await pod_pytorch.trigger(Interfaces.UPDATE_WEIGHTS, {})

        mock_updated.assert_not_called()
        mock_error.assert_called()
        req = mock_error.call_args[0][0]
        self.assertIn('error', req)
        self.assertEqual(req['error']['name'], 'NoWeights')

    async def test_save_model(self):
        mock_saved = AsyncMock()

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_file.name,
            modulepath=self.temp_arch_file.name,
            save_model_filepath=self.temp_model_save_file.name,
        )
        pod_pytorch.register(Interfaces.SAVED_MODEL, mock_saved)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})
        await pod_pytorch.trigger(Interfaces.SAVE_MODEL, {})

        mock_saved.assert_called()
        req = mock_saved.call_args[0][0]
        self.assertIn('filepath', req)
        self.assertEqual(req['filepath'], self.temp_model_save_file.name)

    async def test_save_model_error(self):
        mock_saved = AsyncMock()
        mock_error = AsyncMock()

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_file.name,
            modulepath=self.temp_arch_file.name,
            save_model_filepath=None,
        )
        pod_pytorch.register(Interfaces.SAVED_MODEL, mock_saved)
        pod_pytorch.register(Interfaces.ERROR, mock_error)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})
        await pod_pytorch.trigger(Interfaces.SAVE_MODEL, {})

        mock_saved.assert_not_called()
        mock_error.assert_called()
        req = mock_error.call_args[0][0]
        self.assertIn('error', req)
        self.assertEqual(req['error']['name'], 'PytorchModelSavingError')

    async def test_save_weights(self):
        mock_saved = AsyncMock()

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_file.name,
            modulepath=self.temp_arch_file.name,
            save_weights_filepath=self.temp_weights_save_file.name,
        )
        pod_pytorch.register(Interfaces.SAVED_WEIGHTS, mock_saved)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})
        await pod_pytorch.trigger(Interfaces.SAVE_WEIGHTS, {})

        mock_saved.assert_called()
        req = mock_saved.call_args[0][0]
        self.assertIn('filepath', req)
        self.assertEqual(req['filepath'], self.temp_weights_save_file.name)

    async def test_save_weights_error(self):
        mock_saved = AsyncMock()
        mock_error = AsyncMock()

        pod_pytorch = Pytorch(
            load_model_filepath=self.temp_model_file.name,
            modulepath=self.temp_arch_file.name,
            save_weights_filepath=None,
        )
        pod_pytorch.register(Interfaces.SAVED_WEIGHTS, mock_saved)
        pod_pytorch.register(Interfaces.ERROR, mock_error)

        await pod_pytorch.trigger(Interfaces.LOAD_MODEL, {})
        await pod_pytorch.trigger(Interfaces.SAVE_WEIGHTS, {})

        mock_saved.assert_not_called()
        mock_error.assert_called()
        req = mock_error.call_args[0][0]
        self.assertIn('error', req)
        self.assertEqual(req['error']['name'], 'PytorchWeightsSavingError')
