# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.flow.switch import Switch
from fleviden.core.interfaces import Interfaces


class TestSwitch(IsolatedAsyncioTestCase):
    async def test_forward(self):
        mock_forwarded = AsyncMock()
        mock_not_forwarded = AsyncMock()
        mock_on = AsyncMock()
        mock_off = AsyncMock()

        switch = Switch(default=False)
        switch.register(Interfaces.FORWARDED, mock_forwarded)
        switch.register(Interfaces.NOT_FORWARDED, mock_not_forwarded)
        switch.register(Interfaces.TURNED_ON, mock_on)
        switch.register(Interfaces.TURNED_OFF, mock_off)

        req = {"Test": "Data"}

        await switch.trigger(Interfaces.FORWARD, req)
        mock_forwarded.assert_not_called()
        mock_not_forwarded.assert_called_once_with({})

        await switch.trigger(Interfaces.TURN_ON, {})
        mock_on.assert_called_once()

        await switch.trigger(Interfaces.FORWARD, req)
        mock_forwarded.assert_called_with(req)

        await switch.trigger(Interfaces.TURN_OFF, {})
        mock_off.assert_called_once()

        await switch.trigger(Interfaces.FORWARD, req)
        mock_not_forwarded.assert_called_with({})
