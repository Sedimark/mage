# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.arch.cen.client import Client
from fleviden.core.interfaces import Interfaces


class TestClient(IsolatedAsyncioTestCase):

    async def test_train(self):
        mock_train = AsyncMock()
        weights = [0.1, 0.2, 0.3]
        client = Client('client', server_id="west-north-america")

        client.register(Interfaces.UPDATED, mock_train)
        await client.trigger(
            Interfaces.UPDATE,
            {"origin": "west-north-america", "weights": weights, 'clients': 'client'},
        )

        req = mock_train.call_args.args[0]
        mock_train.assert_called()
        self.assertEqual(req["weights"], weights)

    async def test_unregistered_server(self):
        mock_error = AsyncMock()
        weights = [0.1, 0.2, 0.3]
        client = Client('client', "west-north-america")

        client.register(Interfaces.ERROR, mock_error)
        await client.trigger(
            Interfaces.UPDATE, {"origin": "south-europe", "weights": weights, 'clients': 'client'}
        )

        mock_error.assert_called()
        req = mock_error.call_args.args[0]
        self.assertEqual(req["error"]["name"], "UnregisteredServer")

    async def test_subscribe(self):
        mock_subscribed = AsyncMock()
        client = Client('client', server_id="west-north-america")

        client.register(Interfaces.SUBSCRIBED, mock_subscribed)

        await client.trigger(Interfaces.SUBSCRIBE, {"origin": "west-north-america"})

        mock_subscribed.assert_called()
        req = mock_subscribed.call_args.args[0]
        self.assertIn("client", req)

    async def test_unsubscribe(self):
        mock_unsubscribed = AsyncMock()
        client = Client('client', server_id="west-north-america")

        client.register(Interfaces.UNSUBSCRIBED, mock_unsubscribed)

        await client.trigger(Interfaces.UNSUBSCRIBE, {"origin": "west-north-america"})

        mock_unsubscribed.assert_called()
        req = mock_unsubscribed.call_args.args[0]
        self.assertIn("client", req)

    async def test_forward(self):
        mock_forwarded = AsyncMock()

        client = Client('client', server_id="west-north-america", num_rounds=1)
        client.register(Interfaces.FORWARDED, mock_forwarded)

        await client.trigger(Interfaces.FORWARD, {"weights": [0.1, 0.2, 0.3]})

        mock_forwarded.assert_called()

    async def test_completed_after_forward(self):
        mock_completed = AsyncMock()

        client = Client('client', server_id="server", num_rounds=1)
        client.register(Interfaces.COMPLETED, mock_completed)

        # Receive update
        await client.trigger(
            Interfaces.UPDATE,
            {"origin": "server", "clients": ['client'], "weights": [0.1, 0.2, 0.3]},
        )
        # Forward trained weights
        await client.trigger(Interfaces.FORWARD, {"weights": [0.1, 0.2, 0.3]})

        mock_completed.assert_called()
        req = mock_completed.call_args.args[0]
        self.assertIn("num_rounds", req)

    async def test_completed_after_update(self):
        mock_completed = AsyncMock()

        client = Client('client', server_id="server", num_rounds=1)
        client.register(Interfaces.COMPLETED, mock_completed)

        # Forward trained weights
        await client.trigger(Interfaces.FORWARD, {"weights": [0.1, 0.2, 0.3]})

        # Receive update
        await client.trigger(
            Interfaces.UPDATE,
            {"origin": "server", "clients": ['client'], "weights": [0.1, 0.2, 0.3]},
        )

        mock_completed.assert_called()
        req = mock_completed.call_args.args[0]
        self.assertIn("num_rounds", req)
