# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from BitVector import BitVector

from fleviden.core.encoders.stringcoder import StringCoder
from fleviden.core.interfaces import Interfaces


class TestStringcoder(IsolatedAsyncioTestCase):
    async def test_encode_b64(self):
        mock_encoded = AsyncMock()
        expected_encoded = "gA=="  # 128 in base64

        weights = BitVector(intVal=128)

        code = 'base64'
        stringcoder = StringCoder(code=code, entries=["weights"], replace=True)
        stringcoder.register(Interfaces.ENCODED, mock_encoded)

        await stringcoder.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]
        output = req["weights"]

        self.assertEqual(expected_encoded, output)

    async def test_decode_b64(self):
        mock_decoded = AsyncMock()
        expected_decoded = BitVector(intVal=128)

        weights = "gA=="  # 128 in base64
        code = 'base64'
        stringcoder = StringCoder(code=code, entries=["weights"], replace=True)
        stringcoder.register(Interfaces.DECODED, mock_decoded)

        await stringcoder.trigger(Interfaces.DECODE, {"weights": weights})

        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]
        output = req["weights"]

        self.assertEqual(expected_decoded, output)

    async def test_encode_hex(self):
        mock_encoded = AsyncMock()
        expected_encoded = "80"  # 128 in hexadecimal

        weights = BitVector(intVal=128)

        code = 'hex'
        stringcoder = StringCoder(code=code, entries=["weights"], replace=True)
        stringcoder.register(Interfaces.ENCODED, mock_encoded)

        await stringcoder.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]
        output = req["weights"]

        self.assertEqual(expected_encoded, output)

    async def test_decode_hex(self):
        mock_decoded = AsyncMock()
        expected_decoded = BitVector(intVal=128)

        weights = "80"  # 128 in hexadecimal
        code = 'hex'
        stringcoder = StringCoder(code=code, entries=["weights"], replace=True)
        stringcoder.register(Interfaces.DECODED, mock_decoded)

        await stringcoder.trigger(Interfaces.DECODE, {"weights": weights})

        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]
        output = req["weights"]

        self.assertEqual(expected_decoded, output)

    async def test_encode_no_replace(self):
        mock_encoded = AsyncMock()
        expected_key = "weights_hex_encoded"

        weights = BitVector(intVal=128)

        code = 'hex'
        stringcoder = StringCoder(code=code, entries=["weights"], replace=False)
        stringcoder.register(Interfaces.ENCODED, mock_encoded)

        await stringcoder.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        self.assertTrue(expected_key in req)
        self.assertGreater(len(req), 1)

    async def test_decode_no_replace(self):
        mock_decoded = AsyncMock()
        expected_key = "weights_hex_decoded"

        weights = "80"  # 128 in hexadecimal
        code = 'hex'
        stringcoder = StringCoder(code=code, entries=["weights"], replace=False)
        stringcoder.register(Interfaces.DECODED, mock_decoded)

        await stringcoder.trigger(Interfaces.DECODE, {"weights": weights})

        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        self.assertTrue(expected_key in req)
        self.assertGreater(len(req), 1)

    async def test_encode_invalid_entry(self):
        mock_warning = AsyncMock()

        weights = BitVector(intVal=128)

        code = 'base64'
        stringcoder = StringCoder(code=code, entries=["this is not an entry in req"], replace=True)
        stringcoder.register(Interfaces.WARNING, mock_warning)

        await stringcoder.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_warning.assert_called()
        req = mock_warning.call_args.args[0]
        self.assertEqual(req["warning"]["name"], "MissingKey")

    async def test_decode_invalid_entry(self):
        mock_warning = AsyncMock()

        weights = "gA=="  # 128 in base64

        code = 'base64'
        stringcoder = StringCoder(code=code, entries=["this is not an entry in req"], replace=True)
        stringcoder.register(Interfaces.WARNING, mock_warning)

        await stringcoder.trigger(Interfaces.DECODE, {"weights": weights})

        mock_warning.assert_called()
        req = mock_warning.call_args.args[0]
        self.assertEqual(req["warning"]["name"], "MissingKey")

    async def test_encode_invalid_code(self):
        mock_error = AsyncMock()
        weights = BitVector(intVal=128)

        code = 'this is not a supported code'
        stringcoder = StringCoder(code=code, entries=["weights"], replace=True)
        stringcoder.register(Interfaces.ERROR, mock_error)

        await stringcoder.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_error.assert_called()

    async def test_decode_invalid_code(self):
        mock_error = AsyncMock()

        weights = "gA=="  # 128 in base64
        code = 'this is not a valid code'
        stringcoder = StringCoder(code=code, entries=["weights"], replace=True)
        stringcoder.register(Interfaces.ERROR, mock_error)

        await stringcoder.trigger(Interfaces.DECODE, {"weights": weights})

        mock_error.assert_called()

    async def test_encode_multiple_entries(self):
        mock_encoded = AsyncMock()

        weights1 = BitVector(intVal=128)
        weights2 = BitVector(intVal=269)

        code = 'base64'
        stringcoder = StringCoder(code=code, entries=["weights1", "weights2"], replace=True)
        stringcoder.register(Interfaces.ENCODED, mock_encoded)

        await stringcoder.trigger(Interfaces.ENCODE, {"weights1": weights1, "weights2": weights2})

        mock_encoded.assert_called()

    async def test_encode_decode(self):
        mock_encoded = AsyncMock()
        mock_decoded = AsyncMock()

        input_int = 123456789

        weights = BitVector(intVal=input_int)

        stringcoder = StringCoder(code='b64', entries=["weights"], replace=True)
        stringcoder.register(Interfaces.ENCODED, mock_encoded)
        stringcoder.register(Interfaces.DECODED, mock_decoded)

        await stringcoder.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        await stringcoder.trigger(Interfaces.DECODE, req)

        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        output_int = req["weights"].int_val()
        self.assertEqual(input_int, output_int)
