# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.aggregators.avg_aggregator import WeightedAvgAggregator
from fleviden.core.interfaces.interfaces import Interfaces


class TestWeightedAvgAggregator(IsolatedAsyncioTestCase):
    async def test_aggregate_no_alphas(self):
        mock_aggregated = AsyncMock()
        mock_error = AsyncMock()

        input_key = "weights"
        output_key = input_key
        parameters_matrix = [[1, 1], [2, 2], [3, 3]]
        alphas_matrix = None
        req = {input_key: parameters_matrix, "alphas": alphas_matrix}

        aggregator = WeightedAvgAggregator()
        aggregator.register(Interfaces.AGGREGATED, mock_aggregated)
        aggregator.register(Interfaces.ERROR, mock_error)

        await aggregator.trigger(Interfaces.AGGREGATE, req)

        mock_aggregated.assert_called_once_with({output_key: [2, 2]})
        mock_error.assert_not_called()

    async def test_aggregate_with_alphas(self):
        mock_aggregated = AsyncMock()
        mock_error = AsyncMock()

        input_key = "weights"
        output_key = input_key
        parameters_matrix = [[1, 1], [2, 2], [3, 3]]
        alphas_matrix = [0.25, 0.5, 0.25]
        req = {input_key: parameters_matrix, "alphas": alphas_matrix}

        aggregator = WeightedAvgAggregator()
        aggregator.register(Interfaces.AGGREGATED, mock_aggregated)
        aggregator.register(Interfaces.ERROR, mock_error)

        await aggregator.trigger(Interfaces.AGGREGATE, req)

        mock_aggregated.assert_called_once_with({output_key: [2, 2]})
        mock_error.assert_not_called()

    async def test_aggregate_gradients(self):
        mock_aggregated = AsyncMock()
        mock_error = AsyncMock()

        input_key = "gradients"
        output_key = input_key
        parameters_matrix = [[1, 1], [2, 2], [3, 3]]
        alphas_matrix = [0.25, 0.5, 0.25]
        req = {input_key: parameters_matrix, "alphas": alphas_matrix}

        aggregator = WeightedAvgAggregator()
        aggregator.register(Interfaces.AGGREGATED, mock_aggregated)
        aggregator.register(Interfaces.ERROR, mock_error)

        await aggregator.trigger(Interfaces.AGGREGATE, req)

        mock_aggregated.assert_called_once_with({output_key: [2, 2]})
        mock_error.assert_not_called()

    async def test_aggregate_custom_entries(self):
        mock_aggregated = AsyncMock()
        mock_error = AsyncMock()

        input_key = "custom_input"
        output_key = "custom_output"
        parameters_matrix = [[1, 1], [2, 2], [3, 3]]
        alphas_matrix = [0.25, 0.5, 0.25]
        req = {input_key: parameters_matrix, "alphas": alphas_matrix}

        aggregator = WeightedAvgAggregator(input_key=input_key, output_key=output_key)
        aggregator.register(Interfaces.AGGREGATED, mock_aggregated)
        aggregator.register(Interfaces.ERROR, mock_error)

        await aggregator.trigger(Interfaces.AGGREGATE, req)

        mock_aggregated.assert_called_once_with({output_key: [2, 2]})
        mock_error.assert_not_called()

    async def test_input_key_not_found_error(self):
        mock_aggregated = AsyncMock()
        mock_error = AsyncMock()

        input_key = "custom_input"
        output_key = input_key
        parameters_matrix = [[1, 1], [2, 2], [3, 3]]
        alphas_matrix = [0.25, 0.5, 0.25]
        req = {"not-input-entry": parameters_matrix, "alphas": alphas_matrix}

        aggregator = WeightedAvgAggregator(input_key=input_key, output_key=output_key)
        aggregator.register(Interfaces.AGGREGATED, mock_aggregated)
        aggregator.register(Interfaces.ERROR, mock_error)

        await aggregator.trigger(Interfaces.AGGREGATE, req)

        mock_aggregated.assert_not_called()
        mock_error.assert_called_once()
        out = mock_error.call_args[0][0]
        self.assertEqual(out["error"]["name"], "InvalidKeyError")

    async def test_alphas_sum_error(self):
        mock_aggregated = AsyncMock()
        mock_error = AsyncMock()

        input_key = "weights"
        parameters_matrix = [[1, 1], [2, 2], [3, 3]]
        alphas_matrix = [1, 1, 1]
        req = {input_key: parameters_matrix, "alphas": alphas_matrix}

        aggregator = WeightedAvgAggregator()
        aggregator.register(Interfaces.AGGREGATED, mock_aggregated)
        aggregator.register(Interfaces.ERROR, mock_error)

        await aggregator.trigger(Interfaces.AGGREGATE, req)

        mock_aggregated.assert_not_called()
        mock_error.assert_called_once()
        out = mock_error.call_args[0][0]
        self.assertEqual(out["error"]["name"], "InvalidAlphas")
