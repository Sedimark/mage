# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

import random
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

import numpy as np
from BitVector import BitVector

from fleviden.core.interfaces import Interfaces
from fleviden.core.quantization.qsgd import Qsgd


class TestQsgd(IsolatedAsyncioTestCase):
    def setUp(self):
        # To fix the random seed across the tests
        super().setUp()
        random.seed(46)

    async def test_encode(self):
        mock_encoded = AsyncMock()

        weights = np.array([-2, -1, 0, 1, 2])
        expected_encoded = BitVector(
            bitstring="101010010000000100101001100010110000100010010000110101001100"
        )
        num_levels = 3

        qsgd = Qsgd(num_levels=num_levels, entries=["weights"])
        qsgd.register(Interfaces.ENCODED, mock_encoded)

        await qsgd.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        output = req["weights"]["weights_encoded"]

        self.assertEqual(expected_encoded, output)

    async def test_decode(self):
        expected_decoded = np.array([-2, -1, 0, 1, 2])
        mock_decoded = AsyncMock()
        num_levels = 3
        weights_encoded = BitVector(
            bitstring="101010010000000100101001100010110000100010010000110101001100"
        )

        weights = {"weights_encoded": weights_encoded, "num_levels": num_levels}

        qsgd = Qsgd(num_levels=num_levels, entries=["weights"])
        qsgd.register(Interfaces.DECODED, mock_decoded)

        await qsgd.trigger(Interfaces.DECODE, {"weights": weights})

        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        # Round output vector to account for lossy compression
        output = req["weights"].astype(int)

        np.testing.assert_array_equal(expected_decoded, output)

    async def test_decode_missing_num_levels(self):
        expected_decoded = np.array([-2, -1, 0, 1, 2])
        mock_decoded = AsyncMock()
        weights_encoded = BitVector(
            bitstring="101010010000000100101001100010110000100010010000110101001100"
        )

        weights = {"weights_encoded": weights_encoded}

        num_levels = 3
        qsgd = Qsgd(num_levels=num_levels, entries=["weights"])
        qsgd.register(Interfaces.DECODED, mock_decoded)

        await qsgd.trigger(Interfaces.DECODE, {"weights": weights})

        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        # Round output vector to account for lossy compression
        output = req["weights"].astype(int)

        np.testing.assert_array_equal(expected_decoded, output)

    async def test_encode_no_replace(self):
        mock_encoded = AsyncMock()

        weights = np.array([-2, -1, 0, 1, 2])
        expected_key = "weights_qsgd_encoded"
        num_levels = 3

        qsgd = Qsgd(num_levels=num_levels, entries=["weights"], replace=False)
        qsgd.register(Interfaces.ENCODED, mock_encoded)

        await qsgd.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        self.assertTrue(expected_key in req)
        self.assertGreater(len(req), 1)

    async def test_decode_no_replace(self):
        mock_decoded = AsyncMock()
        num_levels = 3
        weights_encoded = BitVector(
            bitstring="101010010000000100101001100010110000100010010000110101001100"
        )
        expected_key = "weights_qsgd_decoded"

        weights = {"weights_encoded": weights_encoded, "num_levels": num_levels}

        qsgd = Qsgd(num_levels=num_levels, entries=["weights"], replace=False)
        qsgd.register(Interfaces.DECODED, mock_decoded)

        await qsgd.trigger(Interfaces.DECODE, {"weights": weights})

        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        self.assertTrue(expected_key in req)
        self.assertGreater(len(req), 1)

    async def test_encode_scaling_l1(self):
        mock_encoded = AsyncMock()

        weights = np.array([-2, -1, 0, 1, 2])
        num_levels = 3
        scaling = 'l1'
        qsgd = Qsgd(num_levels=num_levels, entries=["weights"], scaling=scaling)
        qsgd.register(Interfaces.ENCODED, mock_encoded)

        await qsgd.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()

    async def test_encode_scaling_max(self):
        mock_encoded = AsyncMock()

        weights = np.array([-2, -1, 0, 1, 2])
        num_levels = 3
        scaling = 'max'
        qsgd = Qsgd(num_levels=num_levels, entries=["weights"], scaling=scaling)
        qsgd.register(Interfaces.ENCODED, mock_encoded)

        await qsgd.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()

    async def test_encode_scaling_default(self):
        mock_encoded = AsyncMock()

        weights = np.array([-2, -1, 0, 1, 2])
        num_levels = 3
        scaling = 'this should trigger L2 norm'
        qsgd = Qsgd(num_levels=num_levels, entries=["weights"], scaling=scaling)
        qsgd.register(Interfaces.ENCODED, mock_encoded)

        await qsgd.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()

    async def test_encode_invalid_entry(self):
        mock_warning = AsyncMock()

        weights = np.array([-2, -1, 0, 1, 2])
        num_levels = 3

        qsgd = Qsgd(num_levels=num_levels, entries=["this is not an entry in req"])
        qsgd.register(Interfaces.WARNING, mock_warning)

        await qsgd.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_warning.assert_called()
        req = mock_warning.call_args.args[0]
        self.assertEqual(req["warning"]["name"], "MissingKey")

    async def test_decode_invalid_entry(self):
        mock_warning = AsyncMock()

        weights_encoded = BitVector(
            bitstring="101010010000000100101001100010110000100010010000110101001100"
        )
        num_levels = 3
        weights = {"weights_encoded": weights_encoded, "num_levels": num_levels}

        qsgd = Qsgd(num_levels=num_levels, entries=["this is not an entry in req"])
        qsgd.register(Interfaces.WARNING, mock_warning)

        await qsgd.trigger(Interfaces.DECODE, {"weights": weights})

        mock_warning.assert_called()
        req = mock_warning.call_args.args[0]
        self.assertEqual(req["warning"]["name"], "MissingKey")

    async def test_encode_multiple_entries(self):
        mock_encoded = AsyncMock()

        weights1 = np.array([-2, -1, 0, 1, 2])
        weights2 = np.array([-4, -5, 2, 3, 4])

        num_levels = 3

        qsgd = Qsgd(num_levels=num_levels, entries=["weights1", "weights2"], replace=True)
        qsgd.register(Interfaces.ENCODED, mock_encoded)

        await qsgd.trigger(Interfaces.ENCODE, {"weights1": weights1, "weights2": weights2})

        mock_encoded.assert_called()

    async def test_decode_multiple_entries(self):
        mock_decoded = AsyncMock()
        num_levels = 3
        weights_encoded = BitVector(
            bitstring="101010010000000100101001100010110000100010010000110101001100"
        )

        weights1 = {"weights1_encoded": weights_encoded, "num_levels": num_levels}
        weights2 = {"weights2_encoded": weights_encoded, "num_levels": num_levels}

        qsgd = Qsgd(num_levels=num_levels, entries=["weights1", "weights2"])
        qsgd.register(Interfaces.DECODED, mock_decoded)

        await qsgd.trigger(Interfaces.DECODE, {"weights1": weights1, "weights2": weights2})

        mock_decoded.assert_called()

    async def test_encode_invalid_input(self):
        mock_error = AsyncMock()

        weights = np.array(["these", "are", "not", "numbers"])
        num_levels = 3

        qsgd = Qsgd(num_levels=num_levels, entries=["weights"])
        qsgd.register(Interfaces.ERROR, mock_error)

        await qsgd.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_error.assert_called()
        req = mock_error.call_args.args[0]
        self.assertEqual(req["error"]["name"], "ValueError")

    async def test_encode_decode(self):
        mock_encoded = AsyncMock()
        mock_decoded = AsyncMock()

        input_vector = np.array([-2, -1, 0, 1, 2])
        weights = input_vector

        num_levels = 3
        qsgd = Qsgd(num_levels=num_levels, entries=["weights"])
        qsgd.register(Interfaces.ENCODED, mock_encoded)
        qsgd.register(Interfaces.DECODED, mock_decoded)

        await qsgd.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        await qsgd.trigger(Interfaces.DECODE, req)

        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        output_vector = req["weights"].astype(int)

        np.testing.assert_array_equal(input_vector, output_vector)

    async def test_encode_no_extended(self):
        mock_encoded = AsyncMock()

        weights = np.array([-2, -1, 0, 1, 2])
        num_levels = 3

        qsgd = Qsgd(num_levels=num_levels, entries=["weights"], encode=False)
        qsgd.register(Interfaces.ENCODED, mock_encoded)

        await qsgd.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]
        output = req['weights']
        scale, sigma, delta = output['scale'], output['sigma'], output['delta']

        self.assertAlmostEqual(scale, 3.1622776601683795)
        np.testing.assert_array_equal(sigma, np.array([-1, -1, 0, 1, 1]))
        np.testing.assert_array_equal(delta, np.array([2, 1, 0, 1, 2]))

    async def test_decode_no_extended(self):
        mock_decoded = AsyncMock()
        scale = 3.1622776601683795
        sigma = np.array([-1, -1, 1, 1, 1])
        delta = np.array([2, 1, 0, 1, 2])

        num_levels = 3
        qsgd = Qsgd(num_levels=num_levels, entries=["weights"], encode=False)
        qsgd.register(Interfaces.DECODED, mock_decoded)

        weights = {'scale': scale, 'sigma': sigma, 'delta': delta, 'num_levels': num_levels}

        await qsgd.trigger(Interfaces.DECODE, {"weights": weights})

        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]
        output = req['weights'].astype(int)

        np.testing.assert_array_equal(output, np.array([-2, -1, 0, 1, 2]))

    async def test_encode_decode_no_extended(self):
        mock_encoded = AsyncMock()
        mock_decoded = AsyncMock()

        input_vector = np.array([-2, -1, 0, 1, 2])
        weights = input_vector

        num_levels = 3
        qsgd = Qsgd(num_levels=num_levels, entries=["weights"], encode=False)
        qsgd.register(Interfaces.ENCODED, mock_encoded)
        qsgd.register(Interfaces.DECODED, mock_decoded)

        await qsgd.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        await qsgd.trigger(Interfaces.DECODE, req)

        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        output_vector = req["weights"].astype(int)

        np.testing.assert_array_equal(input_vector, output_vector)
