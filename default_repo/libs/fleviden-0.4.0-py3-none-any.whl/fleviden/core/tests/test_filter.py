# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.flow.filter import Filter
from fleviden.core.interfaces import Interfaces


class TestFilter(IsolatedAsyncioTestCase):
    async def test_filter_remove(self):
        mock_filtered = AsyncMock()

        req = {"to-keep": "data-to-keep", "to-remove": "data-to-remove"}

        filter = Filter(input_entries=["to-remove"], remove=True)
        filter.register(Interfaces.FILTERED, mock_filtered)

        await filter.trigger(Interfaces.FILTER, req)

        mock_filtered.assert_called_once_with({"to-keep": "data-to-keep"})

    async def test_filter_keep(self):
        mock_filtered = AsyncMock()

        req = {"to-keep": "data-to-keep", "to-remove": "data-to-remove"}

        filter = Filter(input_entries=["to-keep"], remove=False)
        filter.register(Interfaces.FILTERED, mock_filtered)

        await filter.trigger(Interfaces.FILTER, req)

        mock_filtered.assert_called_once_with({"to-keep": "data-to-keep"})
