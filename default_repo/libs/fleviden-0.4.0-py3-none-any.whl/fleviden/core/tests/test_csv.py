# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""
# import pandas
import csv
import os
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.interfaces import Interfaces
from fleviden.core.loaders.csv import CSV

test_file = 'test.csv'
rows = [
    ['feature1', 'feature2', 'target'],
    ['0a', '0b', '0c'],
    ['1a', '1b', '1c'],
]


class TestCSV(IsolatedAsyncioTestCase):
    def setUp(self):
        with open(test_file, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerows(rows)

    def tearDown(self):
        os.remove(test_file)

    async def test_load(self):
        mock_loaded = AsyncMock()

        csv_loader = CSV(
            filepath="test.csv",
            features=["feature1", "feature2"],
            targets=["target"],
            pd_args={"delimiter": ","},
            shuffle=False,
        )
        csv_loader.register(Interfaces.LOADED, mock_loaded)

        await csv_loader.trigger(Interfaces.LOAD, {})

        mock_loaded.assert_called()
        loaded_data = csv_loader.loaded_dataframe

        self.assertIsNotNone(loaded_data)
        self.assertEqual(loaded_data["feature1"].values.tolist(), ['0a', '1a'])
        self.assertEqual(loaded_data["feature2"].values.tolist(), ['0b', '1b'])
        self.assertEqual(loaded_data["target"].values.tolist(), ['0c', '1c'])

    async def test_load_shuffle(self):
        mock_loaded = AsyncMock()

        csv_loader = CSV(
            filepath="test.csv",
            features=["feature1", "feature2"],
            targets=["target"],
            pd_args={"delimiter": ","},
            shuffle=True,
        )
        csv_loader.register(Interfaces.LOADED, mock_loaded)

        await csv_loader.trigger(Interfaces.LOAD, {})

        mock_loaded.assert_called()
        loaded_data = csv_loader.loaded_dataframe

        self.assertIsNotNone(loaded_data)
        self.assertIn("feature1", loaded_data.columns)
        self.assertIn("feature2", loaded_data.columns)
        self.assertIn("target", loaded_data.columns)

    async def test_metadata(self):
        mock_metadata = AsyncMock()

        csv_loader = CSV(
            filepath="test.csv",
            features=["feature1", "feature2"],
            targets=["target"],
            pd_args={"delimiter": ","},
            shuffle=False,
        )
        csv_loader.register(Interfaces.METADATA, mock_metadata)

        await csv_loader.trigger(Interfaces.LOAD, {})
        mock_metadata.assert_called()

        req = mock_metadata.call_args[0][0]

        self.assertEqual(req["metadata"]["num_samples"], 2)
        self.assertEqual(req["metadata"]["num_features"], 2)
        self.assertEqual(req["metadata"]["num_targets"], 1)
        self.assertIn("feature_types", req["metadata"])
        self.assertIn("target_types", req["metadata"])

    async def test_clear(self):
        mock_loaded = AsyncMock()
        mock_cleared = AsyncMock()

        csv_loader = CSV(
            filepath="test.csv",
            features=["feature1", "feature2"],
            targets=["target"],
            pd_args={"delimiter": ","},
            shuffle=False,
        )
        csv_loader.register(Interfaces.LOADED, mock_loaded)
        csv_loader.register(Interfaces.CLEARED, mock_cleared)

        await csv_loader.trigger(Interfaces.LOAD, {})

        mock_loaded.assert_called()
        loaded_data = csv_loader.loaded_dataframe
        self.assertIsNotNone(loaded_data)

        await csv_loader.trigger(Interfaces.CLEAR, {})
        mock_cleared.assert_called()
        loaded_data = csv_loader.loaded_dataframe
        self.assertIsNone(loaded_data)

    async def test_reload(self):
        mock_loaded = AsyncMock()
        mock_cleared = AsyncMock()

        csv_loader = CSV(
            filepath="test.csv",
            features=["feature1", "feature2"],
            targets=["target"],
            pd_args={"delimiter": ","},
            shuffle=False,
        )
        csv_loader.register(Interfaces.LOADED, mock_loaded)
        csv_loader.register(Interfaces.CLEARED, mock_cleared)

        loaded_data = csv_loader.loaded_dataframe
        self.assertIsNone(loaded_data)

        await csv_loader.trigger(Interfaces.RELOAD, {})

        mock_cleared.assert_called()
        mock_loaded.assert_called()
        loaded_data = csv_loader.loaded_dataframe
        self.assertIsNotNone(loaded_data)
