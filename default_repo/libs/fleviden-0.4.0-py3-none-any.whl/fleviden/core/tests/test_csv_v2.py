# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, patch

import pandas as pd

from fleviden.core.interfaces import Interfaces
from fleviden.core.loaders.csv_v2 import CSV


class TestCSV_v2(IsolatedAsyncioTestCase):

    @patch("pandas.read_csv")
    async def test_load(self, mock_read_csv):
        mock_loaded = AsyncMock()
        mock_data = pd.DataFrame({"Column1": [1, 2, 3], "Column2": ["A", "B", "C"]})

        csv_loader = CSV("dummy.csv", pd_args={}, output_key="dataframe")
        csv_loader.register(Interfaces.LOADED, mock_loaded)

        mock_read_csv.return_value = mock_data

        await csv_loader.trigger(Interfaces.LOAD, {})

        mock_loaded.assert_called()
        mock_read_csv.assert_called_once_with("dummy.csv")
        loaded_data = csv_loader.dataframe
        self.assertIsNotNone(loaded_data)
        pd.testing.assert_frame_equal(csv_loader.dataframe, mock_data)

    async def test_clear(self):
        mock_cleared = AsyncMock()
        csv_loader = CSV("dummy.csv", pd_args={}, output_key="dataframe")
        mock_data = pd.DataFrame({"Column1": [1, 2, 3], "Column2": ["A", "B", "C"]})

        csv_loader.dataframe = mock_data
        csv_loader.register(Interfaces.CLEARED, mock_cleared)

        await csv_loader.trigger(Interfaces.CLEAR, {})

        mock_cleared.assert_called()
        self.assertIsNone(csv_loader.dataframe)
