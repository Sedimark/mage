# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

import tempfile
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.layers import Dense
from tensorflow.keras.models import Sequential

from fleviden.core.interfaces import Interfaces
from fleviden.core.trainers.keras import Keras


# Function to create and save a simple Keras model
def create_and_save_model(filepath, metrics=True):
    model = Sequential(
        [Dense(10, activation='relu', input_shape=(20,)), Dense(1, activation='sigmoid')]
    )
    if metrics:
        model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    else:
        model.compile(optimizer='adam', loss='binary_crossentropy')
    model.save(filepath)


class TestKeras(IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp_model_file = tempfile.NamedTemporaryFile(suffix='.keras', delete=True)
        self.temp_model_nometrics_file = tempfile.NamedTemporaryFile(suffix='.keras', delete=True)
        self.temp_model_save_file = tempfile.NamedTemporaryFile(suffix='.keras', delete=True)
        self.temp_model_weights_file = tempfile.NamedTemporaryFile(suffix='.h5', delete=True)
        create_and_save_model(self.temp_model_file.name)
        create_and_save_model(self.temp_model_nometrics_file.name, metrics=False)

    def tearDown(self):
        # Clean up the temporary model file
        self.temp_model_file.close()

    async def test_load_model(self):
        # Load the model
        mock_loaded = AsyncMock()

        pod_keras = Keras(load_model_filepath=self.temp_model_file.name)
        pod_keras.register(Interfaces.LOADED_MODEL, mock_loaded)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})

        mock_loaded.assert_called()
        req = mock_loaded.call_args[0][0]
        self.assertIn('weights', req)

    async def test_load_from_file(self):
        # Load the model
        mock_loaded = AsyncMock()

        filepath = self.temp_model_file.name
        req = {'filepath': filepath}

        pod_keras = Keras(load_model_filepath="not-a-filepath")
        pod_keras.register(Interfaces.LOADED_MODEL, mock_loaded)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, req)

        mock_loaded.assert_called()
        req = mock_loaded.call_args[0][0]
        self.assertIn('weights', req)

    async def test_load_no_compiled_metrics(self):
        # Load the model
        mock_loaded = AsyncMock()
        mock_warning = AsyncMock()

        pod_keras = Keras(load_model_filepath=self.temp_model_nometrics_file.name)
        pod_keras.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_keras.register(Interfaces.WARNING, mock_warning)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})

        mock_loaded.assert_called()
        mock_warning.assert_called()
        req = mock_warning.call_args[0][0]
        self.assertIn('warning', req)

    async def test_load_initialize_model(self):
        # Load the model
        mock_loaded = AsyncMock()
        mock_initialized = AsyncMock()

        pod_keras = Keras(
            load_model_filepath=self.temp_model_file.name, initializer="glorot_normal"
        )
        pod_keras.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_keras.register(Interfaces.INITIALIZED_MODEL, mock_initialized)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})

        mock_loaded.assert_called()
        mock_initialized.assert_called()
        req = mock_initialized.call_args[0][0]
        self.assertIn('weights', req)

    async def test_train_model_weights(self):
        # Train the model
        mock_trained = AsyncMock()
        mock_loaded = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        epochs = 1
        batch_size = 32
        req = {'features': features, 'targets': targets, 'epochs': epochs, 'batch_size': batch_size}

        pod_keras = Keras(load_model_filepath=self.temp_model_file.name, send_gradients=False)
        pod_keras.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_keras.register(Interfaces.TRAINED, mock_trained)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_keras.trigger(Interfaces.TRAIN, {**req, **req_load})

        mock_trained.assert_called()
        req = mock_trained.call_args[0][0]
        self.assertIn('weights', req)

    async def test_train_model_gradients(self):
        # Train the model
        mock_trained = AsyncMock()
        mock_loaded = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        epochs = 1
        batch_size = 32
        req = {'features': features, 'targets': targets, 'epochs': epochs, 'batch_size': batch_size}

        pod_keras = Keras(load_model_filepath=self.temp_model_file.name, send_gradients=True)
        pod_keras.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_keras.register(Interfaces.TRAINED, mock_trained)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_keras.trigger(Interfaces.TRAIN, {**req, **req_load})

        mock_trained.assert_called()
        req = mock_trained.call_args[0][0]
        self.assertIn('gradients', req)

    async def test_evaluate_model(self):
        # Train the model
        mock_evaluated = AsyncMock()
        mock_loaded = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        completed = True

        req = {'features': features, 'targets': targets, 'completed': completed}

        pod_keras = Keras(load_model_filepath=self.temp_model_file.name)
        pod_keras.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_keras.register(Interfaces.EVALUATED, mock_evaluated)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_keras.trigger(Interfaces.EVALUATE, {**req, **req_load})

        mock_evaluated.assert_called()
        req = mock_evaluated.call_args[0][0]

    async def test_evaluate_valid_metrics_model(self):
        # Train the model
        mock_evaluated = AsyncMock()
        mock_loaded = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        completed = True

        req = {'features': features, 'targets': targets, 'completed': completed}

        pod_keras = Keras(load_model_filepath=self.temp_model_file.name, metrics=["accuracy"])
        pod_keras.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_keras.register(Interfaces.EVALUATED, mock_evaluated)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_keras.trigger(Interfaces.EVALUATE, {**req, **req_load})

        mock_evaluated.assert_called()
        req = mock_evaluated.call_args[0][0]

    async def test_evaluate_invalid_metrics_model(self):
        # Train the model
        mock_evaluated = AsyncMock()
        mock_loaded = AsyncMock()
        mock_warning = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        completed = True

        req = {'features': features, 'targets': targets, 'completed': completed}

        pod_keras = Keras(load_model_filepath=self.temp_model_file.name, metrics=["not-a-metric"])
        pod_keras.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_keras.register(Interfaces.EVALUATED, mock_evaluated)
        pod_keras.register(Interfaces.WARNING, mock_warning)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_keras.trigger(Interfaces.EVALUATE, {**req, **req_load})

        mock_warning.assert_called()
        mock_evaluated.assert_called()
        req = mock_evaluated.call_args[0][0]

    async def test_predict_model(self):
        # Train the model
        mock_predicted = AsyncMock()
        mock_loaded = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        identifiers = np.random.randint(100, size=(100, 1))

        req = {'features': features, 'targets': targets, 'identifiers': identifiers}

        pod_keras = Keras(load_model_filepath=self.temp_model_file.name)
        pod_keras.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_keras.register(Interfaces.PREDICTED, mock_predicted)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_keras.trigger(Interfaces.PREDICT, {**req, **req_load})

        mock_predicted.assert_called()
        req = mock_predicted.call_args[0][0]

    async def test_update_weights_with_gradients(self):
        mock_updated = AsyncMock()

        pod_keras = Keras(load_model_filepath=self.temp_model_file.name)
        pod_keras.register(Interfaces.UPDATED_WEIGHTS, mock_updated)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})

        grads = np.random.random(np.array(pod_keras.weights).shape).tolist()
        expected_weights = np.array(pod_keras.weights) - np.array(grads)

        await pod_keras.trigger(Interfaces.UPDATE_WEIGHTS, {'gradients': grads})

        mock_updated.assert_called()

        np.testing.assert_array_equal(pod_keras.weights, expected_weights)

    async def test_update_weights_with_weights(self):
        mock_updated = AsyncMock()

        pod_keras = Keras(load_model_filepath=self.temp_model_file.name)
        pod_keras.register(Interfaces.UPDATED_WEIGHTS, mock_updated)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})

        new_weights = np.random.random(np.array(pod_keras.weights).shape).tolist()

        await pod_keras.trigger(Interfaces.UPDATE_WEIGHTS, {'weights': new_weights})

        mock_updated.assert_called()
        np.testing.assert_array_equal(pod_keras.weights, new_weights)

    async def test_update_weights_error(self):
        mock_updated = AsyncMock()
        mock_error = AsyncMock()

        pod_keras = Keras(load_model_filepath=self.temp_model_file.name)
        pod_keras.register(Interfaces.UPDATED_WEIGHTS, mock_updated)
        pod_keras.register(Interfaces.ERROR, mock_error)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})
        await pod_keras.trigger(Interfaces.UPDATE_WEIGHTS, {})

        mock_updated.assert_not_called()
        mock_error.assert_called()
        req = mock_error.call_args[0][0]
        self.assertIn('error', req)
        self.assertEqual(req['error']['name'], 'NoWeights')

    async def test_save_model(self):
        mock_saved = AsyncMock()

        pod_keras = Keras(
            load_model_filepath=self.temp_model_file.name,
            save_model_filepath=self.temp_model_save_file.name,
        )
        pod_keras.register(Interfaces.SAVED_MODEL, mock_saved)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})
        await pod_keras.trigger(Interfaces.SAVE_MODEL, {})

        mock_saved.assert_called()
        req = mock_saved.call_args[0][0]
        self.assertIn('filepath', req)
        self.assertEqual(req['filepath'], self.temp_model_save_file.name)

    async def test_save_model_error(self):
        mock_saved = AsyncMock()
        mock_error = AsyncMock()

        pod_keras = Keras(load_model_filepath=self.temp_model_file.name, save_model_filepath=None)
        pod_keras.register(Interfaces.SAVED_MODEL, mock_saved)
        pod_keras.register(Interfaces.ERROR, mock_error)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})
        await pod_keras.trigger(Interfaces.SAVE_MODEL, {})

        mock_saved.assert_not_called()
        mock_error.assert_called()
        req = mock_error.call_args[0][0]
        self.assertIn('error', req)
        self.assertEqual(req['error']['name'], 'KerasModelSavingError')

    async def test_save_weights(self):
        mock_saved = AsyncMock()

        pod_keras = Keras(
            load_model_filepath=self.temp_model_file.name,
            save_weights_filepath=self.temp_model_weights_file.name,
        )
        pod_keras.register(Interfaces.SAVED_WEIGHTS, mock_saved)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})
        await pod_keras.trigger(
            Interfaces.SAVE_WEIGHTS, {"filepath": self.temp_model_weights_file.name}
        )

        mock_saved.assert_called()
        req = mock_saved.call_args[0][0]
        self.assertIn('filepath', req)
        self.assertEqual(req['filepath'], self.temp_model_weights_file.name)

    async def test_save_weights_error(self):
        mock_saved = AsyncMock()
        mock_error = AsyncMock()

        pod_keras = Keras(load_model_filepath=self.temp_model_file.name, save_weights_filepath=None)
        pod_keras.register(Interfaces.SAVED_WEIGHTS, mock_saved)
        pod_keras.register(Interfaces.ERROR, mock_error)

        await pod_keras.trigger(Interfaces.LOAD_MODEL, {})
        await pod_keras.trigger(Interfaces.SAVE_WEIGHTS, {})

        mock_saved.assert_not_called()
        mock_error.assert_called()
        req = mock_error.call_args[0][0]
        self.assertIn('error', req)
        self.assertEqual(req['error']['name'], 'KerasWeightsSavingError')
