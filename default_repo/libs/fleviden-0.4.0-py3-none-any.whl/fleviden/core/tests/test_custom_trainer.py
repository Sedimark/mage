# pylint: disable=protected-access

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, Mock, patch

from fleviden.core.interfaces import Interfaces
from fleviden.core.trainers.custom_trainer import CustomTrainer


class TestCustomTrainer(IsolatedAsyncioTestCase):
    async def test_load_fn(self):
        custom_trainer = CustomTrainer()
        with patch.object(custom_trainer, 'trigger', new_callable=AsyncMock) as mock_trigger:
            error = {"error": {"name": "LoadTestError"}}
            custom_trainer.load_fn = Mock(return_value={'error': error})
            await custom_trainer._load({})
            mock_trigger.assert_called_with(Interfaces.ERROR, error)

            custom_trainer.load_fn = Mock(return_value={})
            await custom_trainer._load({})
            mock_trigger.assert_called_with(Interfaces.LOADED_MODEL, {})

            custom_trainer.load_fn = Mock(return_value={'initialized': True})
            await custom_trainer._load({})
            mock_trigger.assert_called_with(
                Interfaces.INITIALIZED_MODEL, {'initialized': True}, info_msg="Model initialized"
            )

            custom_trainer.load_fn = Mock(return_value=None)
            await custom_trainer._load({})
            error = {
                "name": "LoadOutputTypeError",
                "description": "An error occurred when loading the model",
                "details": ValueError("The output of the load function must be a dictionary."),
            }
            call_args = mock_trigger.call_args
            assert call_args[0][0] == Interfaces.ERROR
            for key in call_args[0][1]["error"]:
                try:
                    assert call_args[0][1]["error"][key] == error[key]
                except AssertionError:
                    assert str(call_args[0][1]["error"][key]) == str(error[key])

    async def test_train_fn(self):
        custom_trainer = CustomTrainer()
        with patch.object(custom_trainer, 'trigger', new_callable=AsyncMock) as mock_trigger:
            error = {"error": {"name": "TrainTestError"}}
            custom_trainer.train_fn = Mock(return_value={'error': error})
            await custom_trainer._train({})
            mock_trigger.assert_called_with(Interfaces.ERROR, error)

            custom_trainer.train_fn = Mock(return_value={})
            await custom_trainer._train({})
            mock_trigger.assert_called_with(Interfaces.TRAINED, {}, info_msg="Training completed")

            custom_trainer.train_fn = Mock(return_value=None)
            await custom_trainer._train({})
            error = {
                "name": "TrainOutputTypeError",
                "description": "An error occurred when training the model",
                "details": ValueError("The output of the train function must be a dictionary."),
            }
            call_args = mock_trigger.call_args
            assert call_args[0][0] == Interfaces.ERROR
            for key in call_args[0][1]["error"]:
                try:
                    assert call_args[0][1]["error"][key] == error[key]
                except AssertionError:
                    assert str(call_args[0][1]["error"][key]) == str(error[key])

    async def test_evaluate_fn(self):
        custom_trainer = CustomTrainer()
        with patch.object(custom_trainer, 'trigger', new_callable=AsyncMock) as mock_trigger:
            error = {"error": {"name": "EvaluateTestError"}}
            custom_trainer.evaluate_fn = Mock(return_value={'error': error})
            await custom_trainer._evaluate({})
            mock_trigger.assert_called_with(Interfaces.ERROR, error)

            custom_trainer.evaluate_fn = Mock(return_value={})
            await custom_trainer._evaluate({})
            mock_trigger.assert_called_with(
                Interfaces.EVALUATED, {}, info_msg="Evaluation completed"
            )

            custom_trainer.evaluate_fn = Mock(return_value=None)
            await custom_trainer._evaluate({})
            error = {
                "name": "EvaluateOutputTypeError",
                "description": "An error occurred when evaluating the model",
                "details": ValueError("The output of the evaluate function must be a dictionary."),
            }
            call_args = mock_trigger.call_args
            assert call_args[0][0] == Interfaces.ERROR
            for key in call_args[0][1]["error"]:
                try:
                    assert call_args[0][1]["error"][key] == error[key]
                except AssertionError:
                    assert str(call_args[0][1]["error"][key]) == str(error[key])

    async def test_predict_fn(self):
        custom_trainer = CustomTrainer()
        with patch.object(custom_trainer, 'trigger', new_callable=AsyncMock) as mock_trigger:
            error = {"error": {"name": "PredictTestError"}}
            custom_trainer.predict_fn = Mock(return_value={'error': error})
            await custom_trainer._predict({})
            mock_trigger.assert_called_with(Interfaces.ERROR, error)

            custom_trainer.predict_fn = Mock(return_value={})
            await custom_trainer._predict({})
            mock_trigger.assert_called_with(
                Interfaces.PREDICTED, {}, info_msg="Prediction completed"
            )

            custom_trainer.predict_fn = Mock(return_value=None)
            await custom_trainer._predict({})
            error = {
                "name": "PredictOutputTypeError",
                "description": "An error occurred when predicting with the model",
                "details": ValueError("The output of the predict function must be a dictionary."),
            }
            call_args = mock_trigger.call_args
            assert call_args[0][0] == Interfaces.ERROR
            for key in call_args[0][1]["error"]:
                try:
                    assert call_args[0][1]["error"][key] == error[key]
                except AssertionError:
                    assert str(call_args[0][1]["error"][key]) == str(error[key])

    async def test_save_fn(self):
        custom_trainer = CustomTrainer()
        with patch.object(custom_trainer, 'trigger', new_callable=AsyncMock) as mock_trigger:
            error = {"error": {"name": "SaveModelTestError"}}
            custom_trainer.save_fn = Mock(return_value={'error': error})
            await custom_trainer._save_model({})
            mock_trigger.assert_called_with(Interfaces.ERROR, error)

            custom_trainer.save_fn = Mock(return_value={})
            await custom_trainer._save_model({})
            mock_trigger.assert_called_with(Interfaces.SAVED_MODEL, {}, info_msg="Saved model.")

            custom_trainer.save_fn = Mock(return_value=None)
            await custom_trainer._save_model({})
            error = {
                "name": "CustomTrainerSaveModelOutputTypeError",
                "description": "An error occurred when saving the model",
                "details": ValueError("The output of the save function must be a dictionary."),
            }
            call_args = mock_trigger.call_args
            assert call_args[0][0] == Interfaces.ERROR
            for key in call_args[0][1]["error"]:
                try:
                    assert call_args[0][1]["error"][key] == error[key]
                except AssertionError:
                    assert str(call_args[0][1]["error"][key]) == str(error[key])
