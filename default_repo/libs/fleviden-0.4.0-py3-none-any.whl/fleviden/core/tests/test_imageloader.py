# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""
import os
import random
import shutil
import tempfile
import unittest
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

import numpy as np
from PIL import Image

from fleviden.core.interfaces import Interfaces
from fleviden.core.loaders.image_loader import ImageLoader


class TestImageloader(IsolatedAsyncioTestCase):
    def setUp(self):
        # Create a temporary directory
        self.temp_dir = tempfile.mkdtemp(suffix='_dataset')
        self.images_dir = os.path.join(self.temp_dir, 'images')
        self.labels_dir = os.path.join(self.temp_dir, 'labels')
        self.class_names = ['class1', 'class2']

        # Create images and labels directories
        os.makedirs(self.images_dir, exist_ok=True)
        os.makedirs(self.labels_dir, exist_ok=True)

        # Create 10 temporary PNG images with noise
        for idx in range(10):
            image_array = np.random.rand(100, 100, 3) * 255
            image = Image.fromarray(image_array.astype('uint8')).convert('RGB')
            image_path = os.path.join(self.images_dir, f'temporal_img_{idx}.png')
            image.save(image_path)

            # Create corresponding label file with random class
            label = random.choice(self.class_names)
            label_path = os.path.join(self.labels_dir, f'temporal_img_{idx}.txt')
            with open(label_path, 'w') as f:
                f.write(label)

    def tearDown(self):
        # Remove the temporary directory and all its contents
        shutil.rmtree(self.temp_dir)

    async def test_dataset_creation(self):
        # Check if the images and labels directories are created
        self.assertTrue(os.path.exists(self.images_dir))
        self.assertTrue(os.path.exists(self.labels_dir))

        # Check if 10 images and 10 labels are created
        self.assertEqual(len(os.listdir(self.images_dir)), 10)
        self.assertEqual(len(os.listdir(self.labels_dir)), 10)

        # Check if all label files contain either 'class1' or 'class2'
        for label_file in os.listdir(self.labels_dir):
            with open(os.path.join(self.labels_dir, label_file), 'r') as f:
                content = f.read().strip()
                self.assertIn(content, ['class1', 'class2'])

    async def test_load_default_params(self):
        mock_loaded = AsyncMock()

        image_loader = ImageLoader(
            dataset_dir=self.temp_dir,
            images_dir=self.images_dir,
            labels_dir=self.labels_dir,
            image_size=(100, 100),
            grayscale=True,
            class_names=self.class_names,
            one_hot=True,
            shuffle=True,
            channels_first=True,
        )

        image_loader.register(Interfaces.LOADED, mock_loaded)

        await image_loader.trigger(Interfaces.LOAD, {})

        mock_loaded.assert_called()
        req = mock_loaded.call_args[0][0]
        self.assertIsNotNone(req['features'])
        self.assertIsNotNone(req['targets'])

        img_sample = req['features'][0]
        label_sample = req['targets'][0]

        # Check image shape (input size, grayscale and channels first)
        self.assertTrue(img_sample.shape == (1, 100, 100))
        self.assertTrue(label_sample.shape == (2,))

    async def test_load_rgb(self):
        mock_loaded = AsyncMock()

        image_loader = ImageLoader(
            dataset_dir=self.temp_dir,
            images_dir=self.images_dir,
            labels_dir=self.labels_dir,
            image_size=(100, 100),
            grayscale=False,
            class_names=self.class_names,
            one_hot=True,
            shuffle=True,
            channels_first=True,
        )

        image_loader.register(Interfaces.LOADED, mock_loaded)

        await image_loader.trigger(Interfaces.LOAD, {})

        mock_loaded.assert_called()
        req = mock_loaded.call_args[0][0]
        self.assertIsNotNone(req['features'])
        self.assertIsNotNone(req['targets'])

        img_sample = req['features'][0]
        label_sample = req['targets'][0]

        # Check image shape (input size, grayscale and channels first)
        self.assertTrue(img_sample.shape == (3, 100, 100))
        self.assertTrue(label_sample.shape == (2,))

    async def test_load_channels_last(self):
        mock_loaded = AsyncMock()

        image_loader = ImageLoader(
            dataset_dir=self.temp_dir,
            images_dir=self.images_dir,
            labels_dir=self.labels_dir,
            image_size=(100, 100),
            grayscale=False,
            class_names=self.class_names,
            one_hot=True,
            shuffle=True,
            channels_first=False,
        )

        image_loader.register(Interfaces.LOADED, mock_loaded)

        await image_loader.trigger(Interfaces.LOAD, {})

        mock_loaded.assert_called()
        req = mock_loaded.call_args[0][0]
        self.assertIsNotNone(req['features'])
        self.assertIsNotNone(req['targets'])

        img_sample = req['features'][0]
        label_sample = req['targets'][0]

        # Check image shape (input size, grayscale and channels first)
        self.assertTrue(img_sample.shape == (100, 100, 3))
        self.assertTrue(label_sample.shape == (2,))

    async def test_load_no_one_hot(self):
        mock_loaded = AsyncMock()

        image_loader = ImageLoader(
            dataset_dir=self.temp_dir,
            images_dir=self.images_dir,
            labels_dir=self.labels_dir,
            image_size=(100, 100),
            grayscale=False,
            class_names=self.class_names,
            one_hot=False,
            shuffle=True,
            channels_first=True,
        )

        image_loader.register(Interfaces.LOADED, mock_loaded)

        await image_loader.trigger(Interfaces.LOAD, {})

        mock_loaded.assert_called()
        req = mock_loaded.call_args[0][0]
        self.assertIsNotNone(req['features'])
        self.assertIsNotNone(req['targets'])

        img_sample = req['features'][0]
        label_sample = req['targets'][0]

        # Check image shape (input size, grayscale and channels first)
        self.assertTrue(img_sample.shape == (3, 100, 100))
        self.assertTrue(label_sample.shape == ())
        self.assertTrue(isinstance(label_sample, np.int64))

    async def test_load_input_size(self):
        mock_loaded = AsyncMock()

        image_loader = ImageLoader(
            dataset_dir=self.temp_dir,
            images_dir=self.images_dir,
            labels_dir=self.labels_dir,
            image_size=(64, 64),
            grayscale=False,
            class_names=self.class_names,
            one_hot=True,
            shuffle=True,
            channels_first=True,
        )

        image_loader.register(Interfaces.LOADED, mock_loaded)

        await image_loader.trigger(Interfaces.LOAD, {})

        mock_loaded.assert_called()
        req = mock_loaded.call_args[0][0]
        self.assertIsNotNone(req['features'])
        self.assertIsNotNone(req['targets'])

        img_sample = req['features'][0]

        # Check image shape (input size, grayscale and channels first)
        self.assertTrue(img_sample.shape == (3, 64, 64))

    async def test_reload(self):
        mock_loaded = AsyncMock()
        mock_cleared = AsyncMock()

        image_loader = ImageLoader(
            dataset_dir=self.temp_dir,
            images_dir=self.images_dir,
            labels_dir=self.labels_dir,
            image_size=(100, 100),
            grayscale=True,
            class_names=self.class_names,
            one_hot=True,
            shuffle=True,
            channels_first=True,
        )

        image_loader.register(Interfaces.LOADED, mock_loaded)
        image_loader.register(Interfaces.CLEARED, mock_cleared)

        await image_loader.trigger(Interfaces.RELOAD, {})

        mock_cleared.assert_called()
        mock_loaded.assert_called()
