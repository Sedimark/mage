import unittest
from unittest.mock import AsyncMock, patch

import numpy as np

from fleviden.core.interfaces import Interfaces
from fleviden.core.privacy.gaussian_noise import GaussianNoise


class TestGaussianNoise(unittest.IsolatedAsyncioTestCase):
    async def test_add_gaussian_noise_without_clip_value(self):
        delta = 1e-5
        epsilon = 1.0
        gaussian_noise_pod = GaussianNoise(delta, epsilon)
        weights = np.array([0.4, 0.5, 0.6])

        with patch.object(gaussian_noise_pod, 'trigger', new_callable=AsyncMock) as mock_trigger:
            await gaussian_noise_pod._add_gaussian_noise(
                {"weights": weights.tolist(), "num_clients": 3}
            )

            # Check that the trigger method was called with the correct arguments
            args, _ = mock_trigger.call_args
            self.assertEqual(args[0], Interfaces.NOISE_ADDED)
            noisy_weights = np.array(args[1]["weights"])

            # Verify that the noisy weights have been added correctly
            self.assertEqual(noisy_weights.shape, weights.shape)
            self.assertFalse(np.array_equal(noisy_weights, weights))

    async def test_add_gaussian_noise_zero_percentage(self):
        delta = 1e-5
        epsilon = 1.0
        gaussian_noise_pod = GaussianNoise(delta, epsilon, percentage=0.0)
        weights = np.array([0.4, 0.5, 0.6])

        with patch.object(gaussian_noise_pod, 'trigger', new_callable=AsyncMock) as mock_trigger:
            await gaussian_noise_pod._add_gaussian_noise(
                {"weights": weights.tolist(), "num_clients": 3}
            )

            # Check that the trigger method was called with the correct arguments
            args, _ = mock_trigger.call_args
            self.assertEqual(args[0], Interfaces.NOISE_ADDED)
            noisy_weights = np.array(args[1]["weights"])

            # Verify that the noisy weights have been added correctly
            self.assertEqual(noisy_weights.shape, weights.shape)
            self.assertTrue(np.array_equal(noisy_weights, weights))

    async def test_add_gaussian_noise_half_percentage(self):
        delta = 1e-5
        epsilon = 1.0
        gaussian_noise_pod = GaussianNoise(delta, epsilon, percentage=0.5)
        weights = np.array([0.4, 0.5, 0.6, 0.7])

        with patch.object(gaussian_noise_pod, 'trigger', new_callable=AsyncMock) as mock_trigger:
            await gaussian_noise_pod._add_gaussian_noise(
                {"weights": weights.tolist(), "num_clients": 3}
            )

            # Check that the trigger method was called with the correct arguments
            args, _ = mock_trigger.call_args
            self.assertEqual(args[0], Interfaces.NOISE_ADDED)
            noisy_weights = np.array(args[1]["weights"])

            # Verify that the noisy weights have been added correctly
            self.assertEqual(noisy_weights.shape, weights.shape)
            self.assertTrue(np.array_equal(noisy_weights[0:2], weights[0:2]))

    async def test_add_gaussian_noise_with_clip_value(self):
        delta = 1e-5
        epsilon = 1.0
        gaussian_noise_pod = GaussianNoise(delta, epsilon)
        weights = np.array([0.4, 0.5, 0.6])
        clip_value = 0.5

        with patch.object(gaussian_noise_pod, 'trigger', new_callable=AsyncMock) as mock_trigger:
            await gaussian_noise_pod._add_gaussian_noise(
                {"weights": weights.tolist(), "clip_value": clip_value, "num_clients": 3}
            )

            # Check that the trigger method was called with the correct arguments
            args, _ = mock_trigger.call_args
            self.assertEqual(args[0], Interfaces.NOISE_ADDED)
            noisy_weights = np.array(args[1]["weights"])

            # Verify that the noisy weights have been added correctly
            self.assertEqual(noisy_weights.shape, weights.shape)
            self.assertFalse(np.array_equal(noisy_weights, weights))

    async def test_add_gaussian_noise_with_completed_flag(self):
        delta = 1e-5
        epsilon = 1.0
        gaussian_noise_pod = GaussianNoise(delta, epsilon)
        weights = np.array([0.4, 0.5, 0.6])

        with patch.object(gaussian_noise_pod, 'trigger', new_callable=AsyncMock) as mock_trigger:
            await gaussian_noise_pod._add_gaussian_noise(
                {"weights": weights.tolist(), "num_clients": 3, "completed": True}
            )

            # Check that the trigger method was called with the correct arguments
            args, _ = mock_trigger.call_args
            self.assertEqual(args[0], Interfaces.COMPLETED)
            noisy_weights = np.array(args[1]["weights"])

            # Verify that the noisy weights have been added correctly
            self.assertEqual(noisy_weights.shape, weights.shape)
            self.assertFalse(np.array_equal(noisy_weights, weights))

    async def test_generate_noise_with_clip_value(self):
        delta = 1e-5
        epsilon = 1.0
        gaussian_noise_pod = GaussianNoise(delta, epsilon)
        shape = (3,)
        num_clients = 3
        clip_value = 0.5

        noise = await gaussian_noise_pod._generate_noise(shape, num_clients, clip_value)
        self.assertEqual(noise.shape, shape)

    async def test_generate_noise_without_clip_value(self):
        delta = 1e-5
        epsilon = 1.0
        gaussian_noise_pod = GaussianNoise(delta, epsilon)
        shape = (3,)
        num_clients = 3
        clip_value = None

        noise = await gaussian_noise_pod._generate_noise(shape, num_clients, clip_value)
        self.assertEqual(noise.shape, shape)

    async def test_calculate_sensitivity_with_clip_value(self):
        delta = 1e-5
        epsilon = 1.0
        gaussian_noise_pod = GaussianNoise(delta, epsilon)
        num_clients = 3
        clip_value = 0.5

        sensitivity = await gaussian_noise_pod._calculate_sensitivity(num_clients, clip_value)
        self.assertEqual(sensitivity, 2 * clip_value / num_clients)

    async def test_calculate_sensitivity_without_clip_value(self):
        delta = 1e-5
        epsilon = 1.0
        gaussian_noise_pod = GaussianNoise(delta, epsilon)
        num_clients = 3
        clip_value = None

        sensitivity = await gaussian_noise_pod._calculate_sensitivity(num_clients, clip_value)
        self.assertEqual(sensitivity, 2 / num_clients)

    async def test_calculate_sensitivity_without_clip_value_and_with_sensitivity(self):
        delta = 1e-5
        epsilon = 1.0
        sensitivity = 1.0
        gaussian_noise_pod = GaussianNoise(delta, epsilon, sensitivity)
        num_clients = 3
        clip_value = None

        calculated_sensitivity = await gaussian_noise_pod._calculate_sensitivity(
            num_clients, clip_value
        )
        self.assertEqual(calculated_sensitivity, sensitivity)

    async def test_check_and_bound_std_dev(self):
        delta = 1e-5
        epsilon = 1.0
        gaussian_noise_pod = GaussianNoise(delta, epsilon)
        std_dev = float('inf')
        num_clients = 3
        clip_value = 0.5

        bounded_std_dev = await gaussian_noise_pod._check_and_bound_std_dev(
            std_dev, num_clients, clip_value
        )
        self.assertLessEqual(bounded_std_dev, std_dev)

    async def test_warning_when_std_dev_bounded(self):
        delta = 1e-5
        epsilon = 1.0
        sensitivity = float('inf')
        gaussian_noise_pod = GaussianNoise(delta, epsilon, sensitivity)
        weights = np.array([0.4, 0.5, 0.6])
        clip_value = 0.5
        num_clients = 3

        with patch.object(gaussian_noise_pod, 'trigger', new_callable=AsyncMock) as mock_trigger:
            await gaussian_noise_pod._add_gaussian_noise(
                {"weights": weights.tolist(), "clip_value": clip_value, "num_clients": num_clients}
            )

            std_dev = gaussian_noise_pod._calculate_std_dev(sensitivity)
            gaussian_noise_pod.sensitivity = float('inf')
            sensitivity = await gaussian_noise_pod._calculate_sensitivity(num_clients, clip_value)
            bounded_std_dev = gaussian_noise_pod._calculate_std_dev(2 * clip_value / 3)

            # Check that the trigger method was called with the correct arguments
            warn_message = gaussian_noise_pod._get_std_dev_bound_warning(std_dev, bounded_std_dev)
            mock_trigger.assert_any_call(Interfaces.WARNING, warn_message)

    async def test_trigger_completion(self):
        delta = 1e-5
        epsilon = 1.0
        gaussian_noise_pod = GaussianNoise(delta, epsilon)
        noisy_weights = np.array([0.4, 0.5, 0.6])

        with patch.object(gaussian_noise_pod, 'trigger', new_callable=AsyncMock) as mock_trigger:
            await gaussian_noise_pod._trigger_completion(noisy_weights, completed=True)

            args, _ = mock_trigger.call_args
            self.assertEqual(args[0], Interfaces.COMPLETED)
            self.assertTrue(args[1]["completed"])

            await gaussian_noise_pod._trigger_completion(noisy_weights, completed=False)
            args, _ = mock_trigger.call_args
            self.assertEqual(args[0], Interfaces.NOISE_ADDED)

    async def test_calculate_std_dev(self):
        delta = 1e-5
        epsilon = 1.0
        gaussian_noise_pod = GaussianNoise(delta, epsilon)
        sensitivity = 2
        std_dev = gaussian_noise_pod._calculate_std_dev(sensitivity)
        expected_std_dev = sensitivity * np.sqrt(2 * np.log(1.25 / delta)) / epsilon
        self.assertAlmostEqual(std_dev, expected_std_dev)
