# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

# Copyright (c) 2022-2024 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

import asyncio
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.flow.timer import Timer
from fleviden.core.interfaces.interfaces import Interfaces


class TestTimer(IsolatedAsyncioTestCase):
    def setUp(self):
        self.period = 1
        self.tol = 0.1

    async def test_one_shot(self):
        mock_timeout = AsyncMock()

        timer = Timer(period=self.period, one_shot=True)
        timer.register(Interfaces.TIMEOUT, mock_timeout)

        await timer.trigger(Interfaces.START, {})
        await asyncio.sleep(self.period + self.tol)

        mock_timeout.assert_called()
        req = mock_timeout.call_args[0][0]
        self.assertIn('elapsed_time', req)

        # Round elapsed time for tolerance
        elapsed_time = int(req['elapsed_time'])
        self.assertEqual(elapsed_time, self.period)

    async def test_loop(self):
        mock_timeout = AsyncMock()

        timer = Timer(period=self.period, one_shot=False)
        timer.register(Interfaces.TIMEOUT, mock_timeout)

        await timer.trigger(Interfaces.START, {})
        await asyncio.sleep(self.period + self.tol)

        # First period
        mock_timeout.assert_called()
        req = mock_timeout.call_args[0][0]
        iteration = req["iteration"]
        self.assertEqual(iteration, 1)

        # Second period
        await asyncio.sleep(self.period + self.tol)
        mock_timeout.assert_called()
        req = mock_timeout.call_args[0][0]
        iteration = req["iteration"]
        self.assertEqual(iteration, 2)

    async def test_stop(self):
        mock_timeout = AsyncMock()
        mock_stopped = AsyncMock()

        period = 5
        timer = Timer(period=self.period, one_shot=False)
        timer.register(Interfaces.TIMEOUT, mock_timeout)
        timer.register(Interfaces.STOPPED, mock_stopped)

        await timer.trigger(Interfaces.START, {"period": period})
        self.assertTrue(timer.is_running)

        await timer.trigger(Interfaces.STOP, {})

        await asyncio.sleep(period)
        mock_timeout.assert_not_called()
        self.assertFalse(timer.is_running)
        mock_stopped.assert_called()
