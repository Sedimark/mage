# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.flow.collector import Collector
from fleviden.core.interfaces import Interfaces


class TestCollector(IsolatedAsyncioTestCase):
    async def test_collect_entry(self):
        mock_output = AsyncMock()

        input_entry = "data"
        output_entry = "data"

        collector = Collector(2, input_entry=input_entry, output_entry=output_entry)
        collector.register(Interfaces.OUTPUT, mock_output)
        req1 = {"data": "test data 1"}
        req2 = {"data": "test data 2"}

        await collector.trigger(Interfaces.INPUT, req1)
        mock_output.assert_not_called()

        await collector.trigger(Interfaces.INPUT, req2)
        mock_output.assert_called_once_with({output_entry: [req1[input_entry], req2[input_entry]]})

        self.assertEqual(collector.received, [])

    async def test_collect_full_req(self):
        mock_output = AsyncMock()

        input_entry = None
        output_entry = "data"

        collector = Collector(2, input_entry=input_entry, output_entry=output_entry)
        collector.register(Interfaces.OUTPUT, mock_output)
        req1 = {"data": "test data 1"}
        req2 = {"data": "test data 2"}

        await collector.trigger(Interfaces.INPUT, req1)
        mock_output.assert_not_called()

        await collector.trigger(Interfaces.INPUT, req2)
        mock_output.assert_called_once_with({output_entry: [req1, req2]})

    async def test_output_entry(self):
        mock_output = AsyncMock()

        input_entry = "data"
        output_entry = "collected_data"

        collector = Collector(2, input_entry=input_entry, output_entry=output_entry)
        collector.register(Interfaces.OUTPUT, mock_output)
        req1 = {"data": "test data 1"}
        req2 = {"data": "test data 2"}

        await collector.trigger(Interfaces.INPUT, req1)
        mock_output.assert_not_called()

        await collector.trigger(Interfaces.INPUT, req2)
        mock_output.assert_called_once_with({output_entry: [req1[input_entry], req2[input_entry]]})

    async def test_clear(self):
        mock_output = AsyncMock()
        mock_cleared = AsyncMock()

        input_entry = "data"
        output_entry = "data"

        collector = Collector(2, input_entry=input_entry, output_entry=output_entry)
        collector.register(Interfaces.OUTPUT, mock_output)
        collector.register(Interfaces.CLEARED, mock_cleared)
        req1 = {"data": "test data 1"}
        req2 = {"data": "test data 2"}

        await collector.trigger(Interfaces.INPUT, req1)
        mock_output.assert_not_called()

        await collector.trigger(Interfaces.CLEAR, {})
        mock_cleared.assert_called_once()

        await collector.trigger(Interfaces.INPUT, req2)
        mock_output.assert_not_called()

    async def test_update_count(self):
        mock_output = AsyncMock()
        mock_count_updated = AsyncMock()

        input_entry = "data"
        output_entry = "data"

        collector = Collector(2, input_entry=input_entry, output_entry=output_entry)
        collector.register(Interfaces.OUTPUT, mock_output)
        collector.register(Interfaces.UPDATED_COUNT, mock_count_updated)

        req1 = {"data": "test data 1"}
        req2 = {"data": "test data 2"}
        req3 = {"data": "test data 3"}

        await collector.trigger(Interfaces.INPUT, req1)
        mock_output.assert_not_called()

        await collector.trigger(Interfaces.UPDATE_COUNT, {"count": 3})

        await collector.trigger(Interfaces.INPUT, req2)
        mock_output.assert_not_called()

        await collector.trigger(Interfaces.INPUT, req3)
        mock_output.assert_called_once()

    async def test_manual_output(self):
        mock_output = AsyncMock()

        input_entry = "data"
        output_entry = "data"

        collector = Collector(4, input_entry=input_entry, output_entry=output_entry)
        collector.register(Interfaces.OUTPUT, mock_output)

        req1 = {"data": "test data 1"}
        req2 = {"data": "test data 2"}

        await collector.trigger(Interfaces.INPUT, req1)
        mock_output.assert_not_called()

        await collector.trigger(Interfaces.INPUT, req2)
        mock_output.assert_not_called()

        await collector.trigger(Interfaces.SEND_OUTPUT, {})
        mock_output.assert_called_once()

    async def test_missing_input_key_error(self):
        mock_error = AsyncMock()

        input_entry = "input-key"

        collector = Collector(2, input_entry=input_entry)
        collector.register(Interfaces.ERROR, mock_error)

        req1 = {"not-the-input-key": "test data 1"}

        await collector.trigger(Interfaces.INPUT, req1)
        mock_error.assert_called_once()
