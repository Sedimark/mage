# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, patch

from fleviden.core.flow.repeater import Repeater
from fleviden.core.interfaces import Interfaces


class TestRepeater(IsolatedAsyncioTestCase):
    def setUp(self):
        # Create a Repeater instance for each test
        self.repeater = Repeater(num_times=3, ticking=True)

    async def test_initialization(self):
        # Test if Repeater initializes properly with default values
        repeater = Repeater()
        self.assertIsNone(repeater.num_times)
        self.assertTrue(repeater.ticking)
        self.assertEqual(repeater.repetition, 0)
        self.assertIsNone(repeater.req)

    async def test_initialization_with_parameters(self):
        # Test if Repeater initializes with specific values
        repeater = Repeater(num_times=5, ticking=False)
        self.assertEqual(repeater.num_times, 5)
        self.assertFalse(repeater.ticking)

    @patch.object(Repeater, 'trigger', new_callable=AsyncMock)
    async def test_send_triggers_fire_correct_num_times(self, mock_trigger):
        # Test if _send triggers /fire the correct number of times
        req = {"num_times": 3}
        await self.repeater._send(req)

        # Verify that /fire was triggered 3 times with the request
        self.assertEqual(mock_trigger.call_count, 3)
        mock_trigger.assert_any_call(Interfaces.FIRE, req)

    @patch.object(Repeater, 'trigger', new_callable=AsyncMock)
    async def test_send_with_default_num_times(self, mock_trigger):
        # Test _send when num_times is not provided in the request
        repeater = Repeater(num_times=2)
        req = {}
        await repeater._send(req)

        # Verify that /fire was triggered 2 times
        self.assertEqual(mock_trigger.call_count, 2)
        mock_trigger.assert_any_call(Interfaces.FIRE, req)

    @patch.object(Repeater, 'trigger', new_callable=AsyncMock)
    async def test_tick_triggers_fire_correctly(self, mock_trigger):
        # Test if _tick triggers /fire correctly based on num_times
        req = {"num_times": 2}
        await self.repeater._tick(req)  # First tick
        await self.repeater._tick(req)  # Second tick

        # Verify that /fire was triggered twice
        self.assertEqual(mock_trigger.call_count, 2)
        mock_trigger.assert_any_call(Interfaces.FIRE, req)

        # After 2 ticks, ensure the state is reset
        await self.repeater._tick(req)  # Third tick should reset
        self.assertEqual(self.repeater.repetition, 0)
