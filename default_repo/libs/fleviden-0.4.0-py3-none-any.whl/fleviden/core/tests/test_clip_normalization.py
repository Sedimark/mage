# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

import unittest

import numpy as np
from numpy.testing import assert_array_almost_equal

from fleviden.core.utils.clip_normalization import clip_normalization


class TestClipNormalization(unittest.IsolatedAsyncioTestCase):
    """
    Test class with a set of unit tests for clip normalization.
    """

    def setUp(self):
        np.random.seed(42)

    async def test_avoid_exploding_gradients(self):
        """
        Test that clip normalization avoids exploding gradients.

        Expected Behavior:
        The function should scale down large gradient values appropriately to prevent exploding
        gradients.
        """
        tolerance = np.finfo(float).eps
        num_clients = np.random.randint(1, 10)
        num_gradients = np.random.randint(1, 300)
        gradient_scaler = np.random.randint(1, 100)

        # Create gradients with extremely large values
        gradients = np.random.randn(num_clients, num_gradients) * gradient_scaler

        # Apply clip normalization
        normalized_gradients, _ = clip_normalization(gradients)

        # Calculate the norms before and after normalization
        norms_before = np.linalg.norm(gradients, axis=1)
        norms_after = np.linalg.norm(normalized_gradients, axis=1)
        clip_value = max(np.median(norms_before), np.finfo(float).eps)

        assert np.all(
            norms_after <= clip_value + tolerance
        ), "The gradients were not clipped correctly."

    async def test_only_clipped_gradients(self):
        """
        Test that only the gradients with scaling factors other than 1 are being clipped.

        Expected Behavior:
        The function should only clip gradients that have scaling factors other than 1.
        """
        tolerance = 1e-6
        num_clients = np.random.randint(1, 10)
        num_gradients = np.random.randint(1, 300)
        gradient_scaler = np.random.randint(1, 100)

        # Create gradients with extremely large values
        gradients = np.random.randn(num_clients, num_gradients) * gradient_scaler

        # Calculate the norms and scaling factors before normalization
        norms = np.linalg.norm(gradients, axis=1)
        clip_value = max(np.median(norms), np.finfo(float).eps)
        scaling_factors = np.maximum(1, norms / clip_value).reshape(-1, 1)

        # Apply clip normalization
        normalized_gradients, _ = clip_normalization(gradients)

        for i, scaling_factor in enumerate(scaling_factors):
            if scaling_factor > 1:
                assert np.all(
                    np.abs(normalized_gradients[i]) < np.abs(gradients[i]) + tolerance
                ), "Gradients that should be clipped were not reduced."
            else:
                assert np.all(
                    normalized_gradients[i] == gradients[i]
                ), "Gradients that should not be clipped were modified."

    async def test_edge_case_zero_values(self):
        """
        Test clip normalization with zero values.
        """
        gradients = np.zeros((3, 3))

        normalized_gradients, _ = clip_normalization(gradients)

        assert_array_almost_equal(normalized_gradients, gradients, decimal=6)

    async def test_edge_case_equal_vectors(self):
        """
        Clip normalization test when gradients have all vectors equal.
        """
        gradients = np.array([[1.0, 2.0, 3.0], [1.0, 2.0, 3.0], [1.0, 2.0, 3.0]])
        clipped_gradients, _ = clip_normalization(gradients)

        clipped_gradients_norms = np.linalg.norm(clipped_gradients, axis=1)

        assert np.all(
            clipped_gradients_norms == clipped_gradients_norms[0]
        ), "The gradients were not clipped correctly."
