# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

import numpy as np

from fleviden.core.aggregators.geometric_median_aggregator import GeometricMedianAggregator
from fleviden.core.interfaces.interfaces import Interfaces


class TestGeometricMedianAggregator(IsolatedAsyncioTestCase):
    async def test_aggregate(self):
        mock_aggregated = AsyncMock()

        aggregator = GeometricMedianAggregator(
            input_key="weights", output_key="weights", max_iter=10, tol=1e-5
        )
        aggregator.register(Interfaces.AGGREGATED, mock_aggregated)

        req = {"weights": [[1, 2, 5], [2, 5, 1], [5, 1, 2]]}
        await aggregator.trigger(Interfaces.AGGREGATE, req)

        mock_aggregated.assert_called()
        output = mock_aggregated.call_args.args[0]["weights"]

        np.testing.assert_almost_equal(np.array([2.66, 2.66, 2.66]), output, decimal=2)

    async def test_aggregate_low_tol(self):
        mock_aggregated = AsyncMock()

        aggregator = GeometricMedianAggregator(
            input_key="weights", output_key="weights", max_iter=10, tol=0
        )
        aggregator.register(Interfaces.AGGREGATED, mock_aggregated)

        req = {"weights": [[1, 2, 15], [2, 15, 1], [15, 1, 2]]}
        await aggregator.trigger(Interfaces.AGGREGATE, req)

        mock_aggregated.assert_called()
        output = mock_aggregated.call_args.args[0]["weights"]

        np.testing.assert_almost_equal(np.array([6, 6, 6]), output, decimal=2)

    async def test_error(self):
        mock_aggregated = AsyncMock()
        mock_error = AsyncMock()

        aggregator = GeometricMedianAggregator(input_key="weights", output_key="weights")
        aggregator.register(Interfaces.AGGREGATED, mock_aggregated)
        aggregator.register(Interfaces.ERROR, mock_error)

        req = {"not-weights": [[1, 2, 5], [2, 5, 1], [5, 1, 2]]}
        await aggregator.trigger(Interfaces.AGGREGATE, req)

        mock_aggregated.assert_not_called()
        mock_error.assert_called()
