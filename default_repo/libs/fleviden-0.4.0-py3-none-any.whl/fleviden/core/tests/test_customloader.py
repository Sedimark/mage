# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""


from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.interfaces import Interfaces
from fleviden.core.loaders.custom_loader import CustomLoader


def my_custom_load_function(_req):
    features = [0.1, 0.2, 0.3]
    targets = [0.4, 0.5, 0.6]
    metadata = "This is metadata"
    out = {"features": features, "targets": targets, "metadata": metadata}
    return out


class TestCustomLoader(IsolatedAsyncioTestCase):
    async def test_load(self):
        mock_loaded = AsyncMock()

        pod_loader = CustomLoader(load_fn=my_custom_load_function)
        pod_loader.register(Interfaces.LOADED, mock_loaded)

        await pod_loader.trigger(Interfaces.LOAD, {})

        mock_loaded.assert_called()
        req = mock_loaded.call_args.args[0]

        self.assertIn("features", req)
        self.assertIn("targets", req)

    async def test_metadata(self):
        mock_metadata = AsyncMock()

        pod_loader = CustomLoader(load_fn=my_custom_load_function)
        pod_loader.register(Interfaces.METADATA, mock_metadata)

        await pod_loader.trigger(Interfaces.LOAD, {})

        mock_metadata.assert_called()
        req = mock_metadata.call_args.args[0]

        self.assertIn("metadata", req)

    async def test_load_error(self):
        def my_custom_load_function_error(_req):
            return {"error": "An error occurred"}

        mock_error = AsyncMock()
        mock_loaded = AsyncMock()

        pod_loader = CustomLoader(load_fn=my_custom_load_function_error)
        pod_loader.register(Interfaces.ERROR, mock_error)
        pod_loader.register(Interfaces.LOADED, mock_loaded)

        await pod_loader.trigger(Interfaces.LOAD, {})

        mock_error.assert_called()
        mock_loaded.assert_not_called()
        req = mock_error.call_args.args[0]

    async def test_invalid_output(self):
        mock_error = AsyncMock()
        mock_loaded = AsyncMock()

        def my_custom_load_function_invalid_output(req):
            return "invalid_output"

        pod_loader = CustomLoader(load_fn=my_custom_load_function_invalid_output)
        pod_loader.register(Interfaces.ERROR, mock_error)
        pod_loader.register(Interfaces.LOADED, mock_loaded)

        await pod_loader.trigger(Interfaces.LOAD, {})

        mock_error.assert_called()
        mock_loaded.assert_not_called()
        req = mock_error.call_args.args[0]
        self.assertEqual(req["error"]["name"], "LoadOutputTypeError")
