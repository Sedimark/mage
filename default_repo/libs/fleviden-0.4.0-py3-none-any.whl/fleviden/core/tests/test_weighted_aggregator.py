# pylint: disable=protected-access

import unittest
from unittest.mock import AsyncMock, patch

import numpy as np

from fleviden.core.aggregators.weighted_aggregator import WeightedAggregator
from fleviden.core.interfaces import Interfaces


class TestWeightedAggregator(unittest.IsolatedAsyncioTestCase):
    async def test_initialize(self):
        aggregator = WeightedAggregator(apply_clip_normalization=True)
        initial_weights = np.array([0.1, 0.2, 0.3])
        await aggregator._initialize({"weights": initial_weights})
        np.testing.assert_array_equal(aggregator.previous_weights, initial_weights)

    async def test_aggregate_with_valid_alphas(self):
        aggregator = WeightedAggregator(apply_clip_normalization=False)
        gradients_1 = np.array([0.1, 0.2, 0.3])
        gradients_2 = np.array([0.2, 0.3, 0.4])
        gradients_3 = np.array([0.4, 0.5, 0.6])

        with patch.object(
            aggregator, '_finalize_aggregation', new_callable=AsyncMock
        ) as mock_finalize_aggregation:
            await aggregator._aggregate({"gradients": gradients_1, "alpha": 0.2, 'num_clients': 3})
            self.assertIsNone(aggregator.aggregation)

            await aggregator._aggregate({"gradients": gradients_2, "alpha": 0.3, 'num_clients': 3})
            self.assertIsNone(aggregator.aggregation)

            await aggregator._aggregate({"gradients": gradients_3, "alpha": 0.5, 'num_clients': 3})

            mock_finalize_aggregation.assert_called_once()

    async def test_aggregate_weights(self):
        aggregator = WeightedAggregator(apply_clip_normalization=False)
        weights_1 = np.array([0.1, 0.2, 0.3])
        weights_2 = np.array([0.2, 0.3, 0.4])
        weights_3 = np.array([0.4, 0.5, 0.6])

        with patch.object(
            aggregator, '_finalize_aggregation', new_callable=AsyncMock
        ) as mock_finalize_aggregation:
            await aggregator._aggregate({"weights": weights_1, "alpha": 0.2, 'num_clients': 3})
            self.assertIsNone(aggregator.aggregation)

            await aggregator._aggregate({"weights": weights_2, "alpha": 0.3, 'num_clients': 3})
            self.assertIsNone(aggregator.aggregation)

            await aggregator._aggregate({"weights": weights_3, "alpha": 0.5, 'num_clients': 3})

            mock_finalize_aggregation.assert_called_once()

    async def test_aggregate_with_invalid_alpha(self):
        aggregator = WeightedAggregator(apply_clip_normalization=False)
        with patch.object(aggregator, 'trigger', new_callable=AsyncMock) as mock_trigger:
            await aggregator._aggregate(
                {"gradients": [0.1, 0.2, 0.3], "alpha": 1.1, 'num_clients': 1}
            )
            first_call = mock_trigger.call_args_list[0]
            self.assertEqual(first_call[0][0], Interfaces.ERROR)
            self.assertEqual(first_call[0][1], aggregator._get_alpha_error(1.1))

    async def test_aggregate_with_invalid_sum_alpha(self):
        aggregator = WeightedAggregator(apply_clip_normalization=False)
        with patch.object(aggregator, 'trigger', new_callable=AsyncMock) as mock_trigger:
            await aggregator._aggregate(
                {"gradients": [0.1, 0.2, 0.3], "alpha": 0.5, 'num_clients': 2}
            )
            await aggregator._aggregate(
                {"gradients": [0.2, 0.3, 0.4], "alpha": 0.6, 'num_clients': 2}
            )

            first_call = mock_trigger.call_args_list[0]
            self.assertEqual(first_call[0][0], Interfaces.ERROR)
            self.assertEqual(first_call[0][1], aggregator._get_alpha_sum_error())

    async def test_finalize_aggregation_without_clip_normalization(self):
        aggregator = WeightedAggregator(apply_clip_normalization=False)
        gradients_1 = np.array([0.1, 0.2, 0.3])
        gradients_2 = np.array([0.2, 0.3, 0.4])
        gradients_3 = np.array([0.4, 0.5, 0.6])

        aggregator.all_parameters = [gradients_1, gradients_2, gradients_3]
        aggregator.all_alphas = [0.2, 0.3, 0.5]

        with patch.object(
            aggregator, '_send_aggregation', new_callable=AsyncMock
        ) as mock_send_aggregation:
            await aggregator._finalize_aggregation()
            gradients_matrix = np.array([gradients_1, gradients_2, gradients_3])
            alphas = np.array([0.2, 0.3, 0.5]).reshape(-1, 1)
            expected_aggregation = np.sum(alphas * gradients_matrix, axis=0)

            np.testing.assert_array_almost_equal(aggregator.aggregation, expected_aggregation)
            mock_send_aggregation.assert_called_once()

    async def test_finalize_aggregation_with_clip_normalization(self):
        aggregator = WeightedAggregator(apply_clip_normalization=True)
        gradients_1 = [0.1, 0.2, 0.3]
        gradients_2 = [0.2, 0.3, 0.4]
        gradients_3 = [0.4, 0.5, 0.6]
        clipped_gradients_matrix = np.array([[0.1, 0.1, 0.1], [0.2, 0.2, 0.2], [0.3, 0.3, 0.3]])

        aggregator.all_parameters = [gradients_1, gradients_2, gradients_3]
        aggregator.all_alphas = [0.2, 0.3, 0.5]

        with (
            patch(
                "fleviden.core.aggregators.weighted_aggregator.clip_normalization",
                return_value=(clipped_gradients_matrix, 1.0),
            ) as mock_clip_normalization,
            patch.object(
                aggregator, '_send_aggregation', new_callable=AsyncMock
            ) as mock_send_aggregation,
        ):

            await aggregator._finalize_aggregation()
            mock_send_aggregation.assert_called_once()

            mock_clip_normalization.assert_called()
            self.assertTrue(mock_clip_normalization.called)

            alpha_matrix = np.array([0.2, 0.3, 0.5]).reshape(-1, 1)
            expected_aggregation = np.sum(alpha_matrix * clipped_gradients_matrix, axis=0)

            np.testing.assert_array_almost_equal(aggregator.aggregation, expected_aggregation)

    async def test_send_aggregation_with_complete_no_clip(self):
        initial_weights = [0.1, 0.2, 0.3]
        aggregator = WeightedAggregator(apply_clip_normalization=False)
        aggregator.previous_weights = initial_weights
        aggregator.aggregation = np.array([0.2, 0.3, 0.4])
        aggregator.mode = "weights"

        with patch.object(aggregator, 'trigger', new_callable=AsyncMock) as mock_trigger:
            await aggregator._send_aggregation(completed=True)
            mock_trigger.assert_called_with(
                Interfaces.COMPLETED,
                {"weights": [0.2, 0.3, 0.4], "completed": True},
                info_msg='Sending aggregated weights (completed)',
            )

            # Assert that the aggregation is reset after sending it
            self.assertIsNone(aggregator.aggregation)

    async def test_send_aggregation_without_complete_no_clip(self):
        initial_weights = [0.1, 0.2, 0.3]
        aggregator = WeightedAggregator(apply_clip_normalization=False)
        aggregator.previous_weights = initial_weights
        aggregator.aggregation = np.array([0.2, 0.3, 0.4])
        aggregator.mode = "weights"
        with patch.object(aggregator, 'trigger', new_callable=AsyncMock) as mock_trigger:
            await aggregator._send_aggregation(completed=False)
            mock_trigger.assert_called_with(
                Interfaces.AGGREGATED, {"weights": [0.2, 0.3, 0.4]}, info_msg="Weights aggregated"
            )

            # Assert that the aggregation is reset after sending it
            self.assertIsNone(aggregator.aggregation)

    async def test_get_weighted_aggregator_initialization_error(self):
        aggregator = WeightedAggregator(apply_clip_normalization=True)
        aggregator.previous_weights = None  # Ensure previous_weights is None to trigger the error

        with patch.object(aggregator, 'trigger', new_callable=AsyncMock) as mock_trigger:

            try:
                await aggregator._aggregate(
                    {"weights": [0.1, 0.2, 0.3], "alpha": 1, 'num_clients': 1}
                )
            except Exception:  # pylint: disable=broad-exception-caught
                # This is expected, since even if the error is triggered, the function will continue
                # because the error triggering does not rise an exception.
                pass

            first_call = mock_trigger.call_args_list[0]
            self.assertEqual(first_call[0][0], Interfaces.ERROR)
            self.assertEqual(
                "ClipNormalizationInitializationError", first_call[0][1]["error"]["name"]
            )

    async def test_get_weighted_aggregator_weights_mode_with_clip(self):
        aggregator = WeightedAggregator(apply_clip_normalization=True)
        aggregator.previous_weights = [1, 1, 1]

        with patch.object(aggregator, 'trigger', new_callable=AsyncMock) as mock_trigger:

            try:
                await aggregator._aggregate(
                    {"weights": [0.1, 0.2, 0.3], "alpha": 1, 'num_clients': 1}
                )
            except Exception:  # pylint: disable=broad-exception-caught
                pass

            req = mock_trigger.call_args_list[0][0][1]
            mock_trigger.assert_called_once()
            self.assertIn("weights", req)

    async def test_get_weighted_aggregator_weights_mode_without_clip(self):
        aggregator = WeightedAggregator(apply_clip_normalization=False)
        aggregator.previous_weights = [1, 1, 1]

        with patch.object(aggregator, 'trigger', new_callable=AsyncMock) as mock_trigger:

            try:
                await aggregator._aggregate(
                    {"weights": [0.1, 0.2, 0.3], "alpha": 1, 'num_clients': 1}
                )
            except Exception:  # pylint: disable=broad-exception-caught
                pass

            req = mock_trigger.call_args_list[0][0][1]
            mock_trigger.assert_called_once()
            self.assertIn("weights", req)
            self.assertEqual(req["weights"], [0.1, 0.2, 0.3])

    async def test_accumulate_gradients(self):
        aggregator = WeightedAggregator(accumulate_gradients=True)
        aggregator.mode = "gradients"
        mock_aggregated = AsyncMock()
        mock_completed = AsyncMock()
        gradients = np.array([0.1, 0.2, 0.3])

        aggregator.register(Interfaces.AGGREGATED, mock_aggregated)
        aggregator.register(Interfaces.COMPLETED, mock_completed)

        await aggregator.trigger(Interfaces.AGGREGATE, {"gradients": gradients, "num_clients": 1})
        expected_acc = gradients

        mock_aggregated.assert_called()
        np.testing.assert_array_almost_equal(aggregator.accumulated_gradients, expected_acc)

        await aggregator.trigger(Interfaces.AGGREGATE, {"gradients": gradients, "num_clients": 1})
        expected_acc += gradients

        mock_aggregated.assert_called()
        np.testing.assert_array_almost_equal(aggregator.accumulated_gradients, expected_acc)

        await aggregator.trigger(
            Interfaces.AGGREGATE, {"gradients": gradients, "num_clients": 1, "completed": True}
        )
        expected_acc += gradients

        mock_completed.assert_called()
        req = mock_completed.call_args.args[0]

        self.assertIn("gradients", req)
        np.testing.assert_array_almost_equal(req["gradients"], expected_acc)
