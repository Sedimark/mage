# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2024 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.arch.swarm.agent import Agent
from fleviden.core.interfaces import Interfaces


class TestSwarmAgent(IsolatedAsyncioTestCase):
    def setUp(self):
        self.agent = Agent(
            agent="test-agent1", num_rounds=1, agents={"test-agent2": {}, "test-agent3": {}}
        )

    async def test_sender_pipe(self):
        mock_broadcasted = AsyncMock()
        mock_completed = AsyncMock()

        self.agent.register(Interfaces.BROADCASTED, mock_broadcasted)
        self.agent.register(Interfaces.COMPLETED, mock_completed)

        await self.agent.trigger(Interfaces.BROADCAST, {})
        mock_broadcasted.assert_called()

        await self.agent.trigger(Interfaces.COMPLETE, {})
        mock_completed.assert_called()

    async def test_client_pipe(self):
        mock_complete = AsyncMock()
        self.agent.register(Interfaces.COMPLETE, mock_complete)

        await self.agent.client.trigger(Interfaces.COMPLETED, {})
        mock_complete.assert_called()

    async def test_channel_pipe(self):
        mock_forwarded = AsyncMock()
        self.agent.register(Interfaces.FORWARDED, mock_forwarded)

        await self.agent.trigger(Interfaces.FORWARD, {})
        mock_forwarded.assert_called()

    async def test_pre_train(self):
        mock_train = AsyncMock()
        self.agent.register(Interfaces.TRAIN, mock_train)

        await self.agent.client.trigger(Interfaces.UPDATED, {})
        mock_train.assert_called()

    async def test_aggregation_pipe(self):
        mock_aggregate = AsyncMock()
        self.agent.register(Interfaces.AGGREGATE, mock_aggregate)

        await self.agent.server.trigger(Interfaces.UPDATED, {})
        mock_aggregate.assert_called()

    async def test_post_train(self):
        mock_send_to = AsyncMock()
        self.agent.register("/send-to-1", mock_send_to)

        await self.agent.rotator.trigger("/send-to-1", {})
        mock_send_to.assert_called()
