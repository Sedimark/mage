# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.flow.cache import Cache
from fleviden.core.interfaces import Interfaces


class TestCache(IsolatedAsyncioTestCase):
    async def test_store_retrieve(self):
        mock_stored = AsyncMock()
        mock_retrieved = AsyncMock()

        cache = Cache()
        cache.register(Interfaces.STORED, mock_stored)
        cache.register(Interfaces.RETRIEVED, mock_retrieved)

        req = {"Test": "Data"}

        await cache.trigger(Interfaces.STORE, req)
        mock_stored.assert_called_once()
        self.assertEqual(cache.cache, req)

        await cache.trigger(Interfaces.RETRIEVE, {})
        mock_retrieved.assert_called_once_with(req)

    async def test_clear(self):
        mock_cleared = AsyncMock()

        cache = Cache()
        cache.register(Interfaces.CLEARED, mock_cleared)

        req = {"Test": "Data"}
        cache.cache = req
        self.assertIsNotNone(cache.cache)

        await cache.trigger(Interfaces.CLEAR, {})
        mock_cleared.assert_called_once()
        self.assertIsNone(cache.cache)

    async def test_retrieval_warning(self):
        mock_warning = AsyncMock()

        cache = Cache()
        cache.register(Interfaces.WARNING, mock_warning)
        cache.cache = None

        await cache.trigger(Interfaces.RETRIEVE, {})

        mock_warning.assert_called_once()
        req = mock_warning.call_args.args[0]
        self.assertEqual(req["warning"]["name"], "EmptyCacheWarning")

    async def test_initial_cache(self):
        mock_retrieved = AsyncMock()

        data = {"test": "test-data"}

        cache = Cache(data=data)
        cache.register(Interfaces.RETRIEVED, mock_retrieved)

        await cache.trigger(Interfaces.RETRIEVE, {})

        mock_retrieved.assert_called_with(data)

    async def test_expand_cache(self):
        data = {"test": "test-data"}
        data2 = {"more-test": "more-test-data"}

        cache = Cache(overwrite=False)

        await cache.trigger(Interfaces.STORE, data)
        self.assertDictEqual(cache.cache, data)

        await cache.trigger(Interfaces.STORE, data2)
        self.assertDictEqual(cache.cache, {**data, **data2})
