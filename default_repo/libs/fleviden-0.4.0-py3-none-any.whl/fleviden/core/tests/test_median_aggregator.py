# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.aggregators.median_aggregator import MedianAggregator
from fleviden.core.interfaces.interfaces import Interfaces


class TestMedianAggregator(IsolatedAsyncioTestCase):
    async def test_aggregate(self):
        mock_aggregated = AsyncMock()

        aggregator = MedianAggregator(input_key="weights", output_key="weights")
        aggregator.register(Interfaces.AGGREGATED, mock_aggregated)

        req = {"weights": [[1, 2, 10], [2, 10, 1], [10, 1, 2]]}
        await aggregator.trigger(Interfaces.AGGREGATE, req)

        mock_aggregated.assert_called_with({"weights": [2, 2, 2]})

    async def test_error(self):
        mock_aggregated = AsyncMock()
        mock_error = AsyncMock()

        aggregator = MedianAggregator(input_key="weights", output_key="weights")
        aggregator.register(Interfaces.AGGREGATED, mock_aggregated)
        aggregator.register(Interfaces.ERROR, mock_error)

        req = {"not-weights": [[1, 2, 10], [2, 10, 1], [10, 1, 2]]}
        await aggregator.trigger(Interfaces.AGGREGATE, req)

        mock_aggregated.assert_not_called()
        mock_error.assert_called()
