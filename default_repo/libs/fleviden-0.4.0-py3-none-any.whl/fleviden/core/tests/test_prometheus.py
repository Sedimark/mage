# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

import unittest
from unittest.mock import AsyncMock, patch

from fleviden.core.interfaces import Interfaces
from fleviden.core.services.prometheus_svc import PrometheusClient


class TestPrometheusClient(unittest.IsolatedAsyncioTestCase):
    """
    Unit tests for the PrometheusClient class.
    """

    def setUp(self):
        self.base_url = "http://prometheus_server:9090"
        self.client = PrometheusClient(self.base_url)

        # Mock the trigger method
        self.client.trigger = AsyncMock()

        # Mock the asynchronous HTTP methods
        self.client.http_client.head = AsyncMock()
        self.client.http_client.put = AsyncMock()
        self.client.http_client.delete = AsyncMock()
        self.client.http_client.get = AsyncMock()

    async def test_query_instant(self):
        req = {"query": "cpu_usage", "time": "test-time"}
        await self.client._query_instant(req)

        self.client.trigger.assert_called_once_with(Interfaces.QUERIED, unittest.mock.ANY)

    async def test_query_instant_error(self):
        req = {"not-query": "cpu_usage", "time": "test-time"}
        await self.client._query_instant(req)

        self.client.trigger.assert_called_once_with(Interfaces.ERROR, unittest.mock.ANY)

    async def test_query_range(self):
        req = {
            "query": "cpu_usage",
            "start": "test-start-time",
            "end": "test-end-time",
            "step": "1m",
        }
        await self.client._query_range(req)

        self.client.trigger.assert_called_once_with(Interfaces.QUERIED_RANGE, unittest.mock.ANY)

    async def test_query_range_error(self):
        req = {
            "query": "cpu_usage",
            "not-start": "test-start-time",
            "not-end": "test-end-time",
            "step": "1m",
        }
        await self.client._query_range(req)

        self.client.trigger.assert_called_once_with(Interfaces.ERROR, unittest.mock.ANY)

    async def test_metadata(self):
        req = {"metric": "test-metric"}
        await self.client._get_metadata(req)

        self.client.trigger.assert_called_once_with(Interfaces.GOT_METADATA, unittest.mock.ANY)

    async def test_targets(self):
        await self.client._get_targets({})

        self.client.trigger.assert_called_once_with(Interfaces.GOT_TARGETS, unittest.mock.ANY)

    async def test_alerts(self):
        await self.client._get_alerts({})

        self.client.trigger.assert_called_once_with(Interfaces.GOT_ALERTS, unittest.mock.ANY)

    async def test_rules(self):
        await self.client._get_rules({})

        self.client.trigger.assert_called_once_with(Interfaces.GOT_RULES, unittest.mock.ANY)

    async def test_status_config(self):
        await self.client._get_status_config({})

        self.client.trigger.assert_called_once_with(Interfaces.GOT_STATUS_CONFIG, unittest.mock.ANY)

    async def test_status_flags(self):
        await self.client._get_status_flags({})

        self.client.trigger.assert_called_once_with(Interfaces.GOT_STATUS_FLAGS, unittest.mock.ANY)

    async def test_runtime_info(self):
        await self.client._get_runtime_info({})

        self.client.trigger.assert_called_once_with(Interfaces.GOT_RUNTIME_INFO, unittest.mock.ANY)
