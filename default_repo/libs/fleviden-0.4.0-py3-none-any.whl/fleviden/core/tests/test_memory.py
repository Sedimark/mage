# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.flow.memory import Memory
from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class TestMemory(IsolatedAsyncioTestCase):
    async def test_wait_with_memory(self):
        pod_name = Pod()
        pod_age = Pod()

        mock = AsyncMock()

        pod_memory = Memory(count=2, keep=True, output=Interfaces.FIRE)
        pod_memory.register(Interfaces.FIRE, mock)

        pod_name.register("/name", schema={})
        pod_age.register("/age", schema={})

        pod_name.link("/name", pod_memory, Interfaces.DOCK_0)
        pod_age.link("/age", pod_memory, Interfaces.DOCK_1)

        pod_memory.remember(pod_name, "/name", alias=Interfaces.DOCK_0)

        req_name = {"name": "John Doe"}
        await pod_name.trigger("/name", req_name)
        mock.assert_not_called()

        req_age = {"age": 37}
        await pod_age.trigger("/age", req_age)
        mock.assert_called()

        req = mock.call_args.args[0]
        self.assertEqual(req[Interfaces.DOCK_0], req_name)
        self.assertEqual(req[Interfaces.DOCK_1], req_age)

        req_update = {"age": 42}
        await pod_age.trigger("/age", req_update)
        mock.assert_called()

        req = mock.call_args.args[0]
        self.assertEqual(req[Interfaces.DOCK_0], req_name)
        self.assertEqual(req[Interfaces.DOCK_1], req_update)
