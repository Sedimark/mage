# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, patch

from fleviden.core.flow.ender import Ender
from fleviden.core.interfaces import Interfaces


class TestEnder(IsolatedAsyncioTestCase):
    @patch('fleviden.core.pod.pod.Pod.end', new_callable=AsyncMock)
    async def test_finish_sets_finished_true(self, mock_end):
        ender = Ender()
        self.assertFalse(ender._finished)
        await ender.trigger(Interfaces.FINISH, {})

        self.assertTrue(ender._finished)

        # Check if `Pod.end` was called
        mock_end.assert_called_once()

    async def test_duplicated_finish_warning(self):
        ender = Ender()
        ender._finished = True

        # Mock the trigger method to prevent actual execution and verify the warning call
        ender.trigger = AsyncMock()

        # Call the __finish method, simulating a trigger event
        await ender._Ender__finish(None)

        ender.trigger.assert_called_once_with(Interfaces.WARNING, ender._Ender__get_warning())
