# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

import asyncio
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.interfaces import Interfaces
from fleviden.core.monitoring.health_check import HealthCheck


class TestHealthCheck(IsolatedAsyncioTestCase):
    def setUp(self):
        self.period = 1
        self.tol = 0.85

    async def test_initialize(self):
        mock_updated = AsyncMock()

        req = {"clients": ["client1", "client2"]}
        num_retries = 2
        autostart = False

        healthcheck = HealthCheck(period=self.period, num_retries=num_retries, autostart=autostart)
        healthcheck.register(Interfaces.UPDATED_CLIENTS, mock_updated)

        await healthcheck.trigger(Interfaces.UPDATE_CLIENTS, req)

        mock_updated.assert_awaited_once_with({"client1": 0, "client2": 0})

    async def test_autostart_periodic_ping(self):
        mock_updated = AsyncMock()
        mock_ping = AsyncMock()
        mock_unhealthy = AsyncMock()
        mock_healthy = AsyncMock()

        req = {"clients": ["client1", "client2"]}
        num_retries = 1
        autostart = True

        healthcheck = HealthCheck(period=self.period, num_retries=num_retries, autostart=autostart)
        healthcheck.register(Interfaces.UPDATED_CLIENTS, mock_updated)
        healthcheck.register(Interfaces.PING, mock_ping)
        healthcheck.register(Interfaces.UNHEALTHY, mock_unhealthy)
        healthcheck.register(Interfaces.HEALTHY, mock_healthy)

        await healthcheck.trigger(Interfaces.UPDATE_CLIENTS, req)

        await asyncio.sleep(self.period + self.tol)
        self.assertTrue(healthcheck._running)
        mock_ping.assert_called_with({"clients": ["client1", "client2"]})
        mock_healthy.assert_called()
        req = mock_healthy.call_args[0][0]
        self.assertIn(req, [{"origin": "client1"}, {"origin": "client2"}])
        mock_unhealthy.assert_not_called()

        await asyncio.sleep(self.period + self.tol)
        mock_ping.assert_called_with({"clients": ["client1", "client2"]})
        mock_unhealthy.assert_called()
        req = mock_unhealthy.call_args[0][0]
        self.assertIn(req, [{"origin": "client1"}, {"origin": "client2"}])

    async def test_update_active_clients(self):
        mock_ping = AsyncMock()
        mock_unhealthy = AsyncMock()
        mock_healthy = AsyncMock()
        mock_updated = AsyncMock()

        req = {"clients": ["client1", "client2"]}
        num_retries = 0  # Force unhealthy initialization
        autostart = True

        healthcheck = HealthCheck(period=self.period, num_retries=num_retries, autostart=autostart)
        healthcheck.register(Interfaces.PING, mock_ping)
        healthcheck.register(Interfaces.UNHEALTHY, mock_unhealthy)
        healthcheck.register(Interfaces.HEALTHY, mock_healthy)
        healthcheck.register(Interfaces.UPDATED_CLIENTS, mock_updated)

        await healthcheck.trigger(Interfaces.UPDATE_CLIENTS, req)

        await asyncio.sleep(self.period + self.tol)
        self.assertTrue(healthcheck._running)
        mock_ping.assert_not_called()
        mock_healthy.assert_not_called()
        mock_unhealthy.assert_called()
        req = mock_unhealthy.call_args[0][0]
        self.assertIn(req, [{"origin": "client1"}, {"origin": "client2"}])

        healthcheck.num_retries = 2
        await healthcheck.trigger(Interfaces.UPDATE_CLIENTS, {"clients": ["client1"]})
        mock_updated.assert_called_with({"client1": 0})

        await asyncio.sleep(self.period + self.tol)
        mock_ping.assert_called_with({"clients": ["client1"]})
        mock_healthy.assert_called_with({"origin": "client1"})

        await asyncio.sleep(self.period + self.tol)
        mock_ping.assert_called_with({"clients": ["client1"]})
        mock_healthy.assert_called_with({"origin": "client1"})

    async def test_stop_loop(self):
        mock_ping = AsyncMock()

        req = {"clients": ["client1", "client2"]}
        num_retries = 1
        autostart = True

        healthcheck = HealthCheck(period=self.period, num_retries=num_retries, autostart=autostart)
        healthcheck.register(Interfaces.PING, mock_ping)

        await healthcheck.trigger(Interfaces.UPDATE_CLIENTS, req)

        await asyncio.sleep(self.period + self.tol)
        self.assertTrue(healthcheck._running)
        mock_ping.assert_called()

        await healthcheck.trigger(Interfaces.STOP, {})
        self.assertFalse(healthcheck._running)
        self.assertIsNone(healthcheck.loop)

    async def test_receive_ping(self):
        mock_updated = AsyncMock()
        mock_ping = AsyncMock()
        mock_warning = AsyncMock()
        mock_pong = AsyncMock()

        req = {"clients": ["client1", "client2"]}
        num_retries = 2
        autostart = False

        healthcheck = HealthCheck(period=self.period, num_retries=num_retries, autostart=autostart)
        healthcheck.register(Interfaces.UPDATED_CLIENTS, mock_updated)
        healthcheck.register(Interfaces.PING, mock_ping)
        healthcheck.register(Interfaces.WARNING, mock_warning)
        healthcheck.register(Interfaces.PONG, mock_pong)

        await healthcheck.trigger(Interfaces.UPDATE_CLIENTS, req)
        mock_updated.assert_awaited_once_with({"client1": 0, "client2": 0})

        await healthcheck.trigger(Interfaces.SEND_PING, {})
        mock_ping.assert_called()

        self.assertEqual(healthcheck.clients_ping_count, {"client1": 1, "client2": 1})
        # Receive client1's ping
        req = {"origin": "client1"}
        await healthcheck.trigger(Interfaces.RECEIVE_PING, req)
        self.assertEqual(healthcheck.clients_ping_count, {"client1": 0, "client2": 1})
        mock_pong.assert_called_with({"client": "client1"})

        req = {"origin": "unknown-client"}
        await healthcheck.trigger(Interfaces.RECEIVE_PING, req)
        mock_warning.assert_called()
