# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

import numpy as np

from fleviden.core.interfaces import Interfaces
from fleviden.core.privacy.ss_mask import SecureSumMask


class TestMaskSum(IsolatedAsyncioTestCase):
    async def test_encode(self):
        mock_seed_generated = AsyncMock()
        mock_send_seed = AsyncMock()
        mock_seed_received = AsyncMock()
        mock_encoded = AsyncMock()
        mock_error = AsyncMock()

        client_id = "client_1"
        prev_client = "client_3"
        clients = ["client_1", "client_2", "client_3"]
        mode = "weights"
        params = {mode: [0.1, 0.2, 0.3]}

        pod_mask = SecureSumMask(client_id=client_id, clients=clients)
        pod_mask.register(Interfaces.ENCODED, mock_encoded)
        pod_mask.register(Interfaces.GENERATED_SEED, mock_seed_generated)
        pod_mask.register(Interfaces.SEND_SEED, mock_send_seed)
        pod_mask.register(Interfaces.RECEIVED_SEED, mock_seed_received)
        pod_mask.register(Interfaces.ERROR, mock_error)

        # Generate mask
        await pod_mask.trigger(Interfaces.ENCODE, params)
        mock_seed_generated.assert_called()
        seed = mock_seed_generated.call_args[0][0]["seed"]
        mock_send_seed.assert_called()
        mock_encoded.assert_not_called()

        # Receive mask from previous client
        prev_seed = 42
        expected = list(
            params[mode]
            + pod_mask._generate_random_mask(seed)
            - pod_mask._generate_random_mask(prev_seed)
        )
        await pod_mask.trigger(
            Interfaces.RECEIVE_SEED,
            {"clients": [client_id], "origin": prev_client, "seed": prev_seed},
        )
        mock_seed_received.assert_called()
        mock_encoded.assert_called()
        masked_params = mock_encoded.call_args[0][0][mode]

        np.testing.assert_almost_equal(masked_params, expected)

    async def test_update_clients(self):
        mock_updated = AsyncMock()

        client_id = "client_1"
        clients = ["client_1", "client_2", "client_3"]

        req = {"clients": clients}

        pod_mask = SecureSumMask(client_id=client_id)
        pod_mask.register(Interfaces.UPDATED_CLIENTS, mock_updated)

        self.assertIsNone(pod_mask.clients)

        await pod_mask.trigger(Interfaces.UPDATE_CLIENTS, req)

        mock_updated.assert_called_with(req)
        self.assertEqual(pod_mask.client_id, client_id)

    async def test_update_clients_generate_seed(self):
        mock_updated = AsyncMock()

        client_id = "client_1"
        clients = ["client_1", "client_2", "client_3"]

        req = {"clients": clients}

        pod_mask = SecureSumMask(client_id=client_id)
        pod_mask.register(Interfaces.UPDATED_CLIENTS, mock_updated)

        await pod_mask.trigger(Interfaces.GENERATE_SEED, req)
        mock_updated.assert_called_with(req)

    async def test_receive_parameters_error(self):
        mock_error = AsyncMock()
        mock_params_rcv = AsyncMock()

        client_id = "client_1"

        pod_mask = SecureSumMask(client_id=client_id)
        pod_mask.register(Interfaces.ERROR, mock_error)
        pod_mask.register(Interfaces.RECEIVED_PARAMETERS, mock_params_rcv)

        req = {"not-params": [0.1, 0.2, 0.3]}
        await pod_mask.trigger(Interfaces.ENCODE, req)

        mock_error.assert_called()
        out_req = mock_error.call_args[0][0]
        self.assertEqual(out_req["error"]["name"], "NoWeightsGradientsError")
        mock_params_rcv.assert_not_called()

    async def test_receive_seed_errors(self):
        mock_error = AsyncMock()
        mock_seed_received = AsyncMock()

        client_id = "client_1"
        prev_client = "client_3"
        clients = ["client_1", "client_2", "client_3"]

        pod_mask = SecureSumMask(client_id=client_id, clients=clients)
        pod_mask.register(Interfaces.ERROR, mock_error)
        pod_mask.register(Interfaces.RECEIVED_SEED, mock_seed_received)

        # From expected client but without seed
        await pod_mask.trigger(
            Interfaces.RECEIVE_SEED, {"clients": [client_id], "origin": prev_client, "not-seed": 0}
        )
        mock_seed_received.assert_not_called()
        mock_error.assert_called()
        error = mock_error.call_args[0][0]
        self.assertEqual(error["error"]["name"], "NoRandomSeedError")

        # From unknown client
        await pod_mask.trigger(
            Interfaces.RECEIVE_SEED,
            {"clients": [client_id], "origin": "unknown-client", "seed": 42},
        )
        mock_seed_received.assert_not_called()
        mock_error.assert_called()
        error = mock_error.call_args[0][0]
        self.assertEqual(error["error"]["name"], "ClientIdxError")
