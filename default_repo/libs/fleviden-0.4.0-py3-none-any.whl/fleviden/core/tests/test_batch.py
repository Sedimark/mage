# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, patch

from fleviden.core.flow.batch import Batch
from fleviden.core.interfaces import Interfaces


class TestBatch(IsolatedAsyncioTestCase):

    def setUp(self):
        # Create a Batch instance for each test
        self.entries = {'data': 3}  # Batch size of 3 for 'data'
        self.batch = Batch(entries=self.entries)

    def test_initialization(self):
        # Test if Batch initializes with correct entries
        self.assertEqual(self.batch.entries, self.entries)
        self.assertIsNone(self.batch.status)
        self.assertIsNone(self.batch.req)

    async def test_send(self):
        req = {'data': [1, 2, 3, 4, 5, 6, 7]}
        mock_fire = AsyncMock()
        self.batch.register(Interfaces.FIRE, mock_fire)
        await self.batch.trigger(Interfaces.SEND, req)

        mock_fire.assert_called()
        self.assertEqual(mock_fire.call_count, 3)

    @patch.object(Batch, 'trigger', new_callable=AsyncMock)
    async def test_tick_sends_batches(self, mock_trigger):
        # Test if _tick sends batches correctly over multiple ticks
        req = {'data': [10, 20, 30, 40, 50, 60]}

        # First tick
        await self.batch._tick(req)
        mock_trigger.assert_called_once()
        mock_trigger.assert_called_with(
            Interfaces.FIRE, {'status': {'data': {'current': 1, 'total': 2}}, 'data': [10, 20, 30]}
        )

        # Second tick
        await self.batch._tick(req)
        self.assertEqual(mock_trigger.call_count, 2)
        mock_trigger.assert_called_with(
            Interfaces.FIRE, {'status': {'data': {'current': 2, 'total': 2}}, 'data': [40, 50, 60]}
        )

    @patch.object(Batch, 'trigger', new_callable=AsyncMock)
    async def test_recv_combines_batches(self, mock_trigger):
        # Test if _recv correctly combines batches
        req1 = {'data': [1, 2, 3], 'status': {'data': {'current': 1, 'total': 2}}}
        req2 = {'data': [4, 5, 6], 'status': {'data': {'current': 2, 'total': 2}}}

        # First receive call
        await self.batch._recv(req1)

        # Second receive call
        await self.batch._recv(req2)

        # Check that the trigger was called with the combined request
        combined_req = {'data': [1, 2, 3, 4, 5, 6], 'status': {'data': {'current': 1, 'total': 2}}}
        mock_trigger.assert_called_once_with(Interfaces.FIRE, combined_req)

    async def test_get_entries_from_request(self):
        # Test __get_entries retrieves entries from request
        req = {'entries': {'data': 5}}
        entries = self.batch._Batch__get_entries(req)
        self.assertEqual(entries, {'data': 5})

    async def test_get_status(self):
        # Test __get_status calculates the correct status
        req = {'data': [1, 2, 3, 4, 5, 6, 7]}
        status = self.batch._Batch__get_status(self.entries, req)
        expected_status = {'data': {'current': 0, 'total': 3}}
        self.assertEqual(status, expected_status)

    async def test_is_completed(self):
        # Test __is_completed returns correct completion status
        status = {'data': {'current': 2, 'total': 2}}
        self.assertTrue(self.batch._Batch__is_completed(status))

        status = {'data': {'current': 1, 'total': 2}}
        self.assertFalse(self.batch._Batch__is_completed(status))
