# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

import json
import logging
import os
import tempfile
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, patch

from fleviden.core.debug.logger import Logger


class TestLogger(IsolatedAsyncioTestCase):
    async def test_send_debug(self):
        logger = Logger(level="debug")
        msg = "Debug message"
        with patch.object(logger.logger, "debug") as mock_debug:
            await logger.debug(msg)
            mock_debug.assert_called_once_with(json.dumps(msg))

    async def test_send_info(self):
        logger = Logger(level="info")
        msg = "Info message"
        with patch.object(logger.logger, "info") as mock_info:
            await logger.info(msg)
            mock_info.assert_called_once_with(json.dumps(msg))

    async def test_send_warning(self):
        logger = Logger(level="warning")
        msg = "Warning message"
        with patch.object(logger.logger, "warning") as mock_warning:
            await logger.warning(msg)
            mock_warning.assert_called_once_with(json.dumps(msg))

    async def test_send_error(self):
        logger = Logger(level="error")
        msg = "Error message"
        with patch.object(logger.logger, "error") as mock_error:
            await logger.error(msg)
            mock_error.assert_called_once_with(json.dumps(msg))

    async def test_send_critical(self):
        logger = Logger(level="critical")
        msg = "Critical message"
        with patch.object(logger.logger, "critical") as mock_critical:
            await logger.critical(msg)
            mock_critical.assert_called_once_with(json.dumps(msg))

    async def test_log_path(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            log_file = os.path.join(temp_dir, "test.log")
            logger = Logger(level="debug", console=False, path=log_file)

            self.assertTrue(os.path.exists(log_file))

    async def test_init(self):
        logger = Logger(level="debug", console=True)
        self.assertEqual(logger.level, logging.DEBUG)
        self.assertEqual(logger.logger.propagate, False)
        self.assertTrue(logger.logger.hasHandlers())

        console_handler = logger.logger.handlers[0]
        self.assertEqual(console_handler.level, logging.DEBUG)
        self.assertIsInstance(console_handler, logging.StreamHandler)

    async def test_indentation(self):
        logger = Logger(level="debug", indent=4)
        msg = {"key": "value"}
        expected_output = json.dumps(msg, indent=4)

        with patch.object(logger.logger, "debug") as mock_debug:
            await logger.debug(msg)
            mock_debug.assert_called_once_with(expected_output)
