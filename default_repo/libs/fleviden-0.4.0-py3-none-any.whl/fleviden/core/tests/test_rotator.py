# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.flow.rotator import Rotator
from fleviden.core.interfaces import Interfaces


class TestRotator(IsolatedAsyncioTestCase):
    async def test_send(self):
        mock_send_zero = AsyncMock()
        mock_send_one = AsyncMock()
        mock_send_two = AsyncMock()

        rotator = Rotator(num_wires=3)

        rotator.register('/send-to-0', mock_send_zero)
        rotator.register('/send-to-1', mock_send_one)
        rotator.register('/send-to-2', mock_send_two)

        self.assertEqual(rotator.round, -1)

        await rotator.trigger(Interfaces.SEND, {})
        mock_send_zero.assert_called_once()
        mock_send_one.assert_not_called()
        mock_send_two.assert_not_called()
        self.assertEqual(rotator.round, 0)

        await rotator.trigger(Interfaces.SEND, {})
        mock_send_one.assert_called_once()
        mock_send_two.assert_not_called()
        self.assertEqual(rotator.round, 1)

        await rotator.trigger(Interfaces.SEND, {})
        mock_send_two.assert_called_once()
        self.assertEqual(rotator.round, 2)

        await rotator.trigger(Interfaces.SEND, {})
        mock_send_zero.assert_called()
        self.assertEqual(rotator.round, 0)
