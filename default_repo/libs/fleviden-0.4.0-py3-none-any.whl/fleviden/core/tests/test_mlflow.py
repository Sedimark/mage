# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2024 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, patch

from fleviden.core.interfaces import Interfaces
from fleviden.core.services.mlflow_svc import MLflowClient


class TestMLflowClient(IsolatedAsyncioTestCase):
    def setUp(self):
        self.base_url = "http://mlflow:5000"
        self.client = MLflowClient(self.base_url)
        self.client.http_client.get = AsyncMock()
        self.client.http_client.post = AsyncMock()
        self.client.trigger = AsyncMock()

    async def test_create_experiment(self):
        # Arrange
        req = {"experiment_name": "test-experiment", "artifact_location": "artifacts/test"}
        mock_response = {"experiment_id": "123"}
        self.client.http_client.post.return_value = mock_response

        # Act
        await self.client.create_experiment(req)

        # Assert
        self.client.http_client.post.assert_called_once_with(
            '/api/2.0/mlflow/experiments/create',
            json={"name": "test-experiment", "artifact_location": "artifacts/test"},
        )
        self.client.trigger.assert_called_once_with(
            Interfaces.CREATED_EXPERIMENT,
            mock_response,
            info_msg="Created MLflow experiment with name test-experiment and ID 123.",
        )

    async def test_get_experiment_by_name(self):
        # Arrange
        req = {"experiment_name": "test-experiment"}
        mock_response = {"experiment": {"experiment_id": "123", "name": "test-experiment"}}
        self.client.http_client.get.return_value = mock_response

        # Act
        result = await self.client.get_experiment_by_name(req)

        # Assert
        self.client.http_client.get.assert_called_once_with(
            '/api/2.0/mlflow/experiments/get-by-name', params={"experiment_name": "test-experiment"}
        )
        self.client.trigger.assert_called_once_with(
            Interfaces.GOT_EXPERIMENT_BY_NAME,
            mock_response,
            info_msg="Retrieved MLflow experiment with name test-experiment.",
        )
        self.assertEqual(result, mock_response)

    async def test_create_experiment_already_exists(self):
        self.client.get_experiment_by_name = AsyncMock(
            return_value={"experiment": {"experiment_id": "1234"}}
        )

        # Simulate the 'post' response indicating the experiment already exists
        self.client.http_client.post.return_value = {
            "error": {"details": {"error_code": "RESOURCE_ALREADY_EXISTS"}}
        }

        # Create the request payload
        req = {"experiment_name": "existing_experiment", "artifact_location": "artifacts/path"}

        # Call the create_experiment method
        await self.client.create_experiment(req)

        # Assert that get_experiment_by_name was called
        self.client.get_experiment_by_name.assert_called_once_with(req)

        # Assert that the experiment ID was set correctly
        assert self.client._experiment_id == "1234"

    async def test_create_run(self):
        # Arrange
        req = {"experiment_id": "123", "run_name": "test-run"}
        mock_response = {"run": {"info": {"run_id": "run-123"}}}
        self.client.http_client.post.return_value = mock_response

        # Act
        await self.client.create_run(req)

        # Assert
        self.client.http_client.post.assert_called_once_with(
            '/api/2.0/mlflow/runs/create', json={"experiment_id": "123", "run_name": "test-run"}
        )
        self.client.trigger.assert_called_once_with(
            Interfaces.CREATED_RUN,
            mock_response,
            info_msg="Created MLflow run with name test-run and ID run-123.",
        )

    async def test_log_param_no_parameters_to_log(self):
        req = {}

        await self.client.log_param(req)

        self.client.http_client.post.assert_not_called()
        self.client.trigger.assert_not_called()

    async def test_log_param_single_parameter(self):
        req = {"run_id": "test-run-id", "param1": "value1"}

        await self.client.log_param(req)

        self.client.http_client.post.assert_awaited_once_with(
            "/api/2.0/mlflow/runs/log-parameter",
            json={"run_id": "test-run-id", "key": "param1", "value": "value1"},
        )

    async def test_log_param_batch(self):
        # Arrange
        req = {"run_id": "run-123", "param1": "value1", "param2": "value2"}
        mock_response = {}
        self.client.http_client.post.return_value = mock_response

        # Act
        await self.client.log_param(req)

        # Assert
        self.client.http_client.post.assert_called_once_with(
            '/api/2.0/mlflow/runs/log-batch',
            json={
                'run_id': 'run-123',
                'params': [
                    {'key': 'param1', 'value': 'value1'},
                    {'key': 'param2', 'value': 'value2'},
                ],
            },
        )
        self.client.trigger.assert_called_once_with(
            Interfaces.LOGGED_PARAM,
            {
                "run_id": "run-123",
                'params': [
                    {'key': 'param1', 'value': 'value1'},
                    {'key': 'param2', 'value': 'value2'},
                ],
            },
            info_msg="Logged parameters: {'run_id': 'run-123', 'params': [{'key': 'param1', 'value': 'value1'}, {'key': 'param2', 'value': 'value2'}]}",
        )

    # ---------- Error Tests ----------

    async def test_create_experiment_error(self):
        self.client.http_client.post.side_effect = Exception("Failed to create experiment")

        request = {"experiment_name": "test_experiment"}
        await self.client.create_experiment(request)

        self.client.trigger.assert_called_with(
            Interfaces.ERROR,
            self.client._get_error(
                "MLflowError", "Error creating experiment.", "Failed to create experiment"
            ),
        )

    async def test_get_experiment_by_name_error(self):
        self.client.http_client.get.side_effect = Exception("Experiment not found")

        request = {"experiment_name": "non_existent_experiment"}
        await self.client.get_experiment_by_name(request)

        self.client.trigger.assert_called_with(
            Interfaces.ERROR,
            self.client._get_error(
                "MLflowError", "Error getting experiment by name.", "Experiment not found"
            ),
        )

    async def test_create_run_error(self):
        self.client.http_client.post.side_effect = Exception("Failed to create run")

        request = {"experiment_id": "123", "run_name": "test_run"}
        await self.client.create_run(request)

        self.client.trigger.assert_called_with(
            Interfaces.ERROR,
            self.client._get_error("MLflowError", "Error creating run.", "Failed to create run"),
        )

    async def test_log_model_error(self):
        self.client.http_client.post.side_effect = Exception("Failed to log model")

        request = {"run_id": "123", "model_json": {"name": "test_model", "version": "1.0"}}
        await self.client.log_model(request)

        self.client.trigger.assert_called_with(
            Interfaces.ERROR,
            self.client._get_error("MLflowError", "Error logging model.", "Failed to log model"),
        )

    async def test_log_batch_error(self):
        self.client.http_client.post.side_effect = Exception("Failed to log batch")

        request = {
            "run_id": "123",
            "metrics": [{"key": "metric1", "value": 0.5, "step": 0, "timestamp": 1234567890}],
            "params": [{"key": "param1", "value": "value1"}],
            "tags": [{"key": "tag1", "value": "tag_value"}],
        }
        await self.client.log_batch(request)

        self.client.trigger.assert_called_with(
            Interfaces.ERROR,
            self.client._get_error("MLflowError", "Error logging batch.", "Failed to log batch"),
        )

    # ---------- Warning Tests ----------

    async def test_log_param_warning_non_string_values(self):
        self.client.http_client.post.return_value = None  # Mock a successful POST

        request = {
            "run_id": "123",
            "param1": 0.5,
            "param2": True,
            "invalid_param": {"key": "value"},
        }
        await self.client.log_param(request)

        self.client.trigger.assert_any_call(
            Interfaces.WARNING,
            self.client._get_warning(
                "MLflowWarning",
                "Some values were not logged as parameters.",
                "Values for keys ['invalid_param'] were not logged.",
            ),
        )

    async def test_log_metric_warning_non_numeric_values(self):
        self.client.http_client.post.return_value = None  # Mock a successful POST

        request = {"run_id": "123", "metric1": 0.5, "invalid_metric": "non-numeric"}
        await self.client.log_metric(request)

        self.client.trigger.assert_any_call(
            Interfaces.WARNING,
            self.client._get_warning(
                "MLflowWarning",
                "Some values were not logged as metrics.",
                "Values for keys ['invalid_metric'] were not logged.",
            ),
        )
