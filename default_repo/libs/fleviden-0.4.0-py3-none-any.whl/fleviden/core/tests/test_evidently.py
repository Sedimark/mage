# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

import tempfile
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, Mock, patch

import numpy as np
import pandas as pd
from evidently.metrics import DatasetSummaryMetric

from fleviden.core.interfaces import Interfaces
from fleviden.core.monitoring.evidently import EvidentlyMonitor


def create_and_save_data_file(filepath):
    features_data = np.random.rand(100, 100)
    target_data = np.random.randint(0, 2, size=100)
    prediction_data = np.random.randint(0, 2, size=100)

    df = pd.DataFrame(features_data, columns=[f"feature_{i}" for i in range(1, 101)])
    df['target'] = target_data
    df['prediction'] = prediction_data

    df.to_csv(filepath, index=False)


class TestEvidently(IsolatedAsyncioTestCase):
    """
    Unit tests for the EvidentlyMonitor class.
    """

    def setUp(self):
        self.temp_ref_file = tempfile.NamedTemporaryFile(suffix='.csv', delete=True)
        self.temp_cur_file = tempfile.NamedTemporaryFile(suffix='.csv', delete=True)
        create_and_save_data_file(self.temp_ref_file.name)
        create_and_save_data_file(self.temp_cur_file.name)

    def tearDown(self):
        self.temp_ref_file.close()
        self.temp_cur_file.close()

    async def test_metric_report(self):
        mock_reported = AsyncMock()

        evidently_pod = EvidentlyMonitor(
            self.temp_ref_file.name, self.temp_cur_file.name, metrics=[DatasetSummaryMetric()]
        )
        evidently_pod.register(Interfaces.REPORTED, mock_reported)

        await evidently_pod.trigger(Interfaces.REPORT, {})

        mock_reported.assert_called()

    async def test_metric_report_warning(self):
        mock_warning = AsyncMock()
        mock_class = Mock()
        mock_class.__name__ = "mock"

        evidently_pod = EvidentlyMonitor(
            self.temp_ref_file.name, self.temp_cur_file.name, metrics=[mock_class]
        )
        evidently_pod.register(Interfaces.WARNING, mock_warning)

        await evidently_pod.trigger(Interfaces.REPORT, {})

        mock_warning.assert_called()
        req = mock_warning.call_args.args[0]
        self.assertEqual(req["warning"]["name"], "EvidentlyMetricWarning")

    async def test_no_metric_warning(self):
        mock_warning = AsyncMock()

        evidently_pod = EvidentlyMonitor(self.temp_ref_file.name, self.temp_cur_file.name)
        evidently_pod.register(Interfaces.WARNING, mock_warning)

        await evidently_pod.trigger(Interfaces.REPORT, {})

        mock_warning.assert_called()
        req = mock_warning.call_args.args[0]
        self.assertEqual(req["warning"]["name"], "EvidentlyNoMetricsWarning")

    async def test_report_presets(self):
        mock_data_quality = AsyncMock()
        mock_data_drift = AsyncMock()
        mock_target_drift = AsyncMock()
        mock_classification = AsyncMock()
        mock_regression = AsyncMock()

        evidently_pod = EvidentlyMonitor(self.temp_ref_file.name, self.temp_cur_file.name)
        evidently_pod.register(Interfaces.REPORTED_DATA_QUALITY, mock_data_quality)
        evidently_pod.register(Interfaces.REPORTED_DATA_DRIFT, mock_data_drift)
        evidently_pod.register(Interfaces.REPORTED_TARGET_DRIFT, mock_target_drift)
        evidently_pod.register(Interfaces.REPORTED_CLASSIFICATION, mock_classification)
        evidently_pod.register(Interfaces.REPORTED_REGRESSION, mock_regression)

        await evidently_pod.trigger(Interfaces.REPORT_DATA_QUALITY, {})
        mock_data_quality.assert_called()

        await evidently_pod.trigger(Interfaces.REPORT_DATA_DRIFT, {})
        mock_data_drift.assert_called()

        await evidently_pod.trigger(Interfaces.REPORT_TARGET_DRIFT, {})
        mock_target_drift.assert_called()

        await evidently_pod.trigger(Interfaces.REPORT_CLASSIFICATION, {})
        mock_classification.assert_called()

        await evidently_pod.trigger(Interfaces.REPORT_REGRESSION, {})
        mock_regression.assert_called()

    async def test_file_warning(self):
        mock_warning = AsyncMock()

        evidently_pod = EvidentlyMonitor(
            "./file.csv", self.temp_cur_file.name, metrics=[DatasetSummaryMetric()]
        )
        evidently_pod.register(Interfaces.WARNING, mock_warning)

        await evidently_pod.trigger(Interfaces.REPORT, {})

        mock_warning.assert_called()
        req = mock_warning.call_args.args[0]
        self.assertEqual(req["warning"]["name"], "EvidentlyFileWarning")

    async def test_detect_data_drift(self):
        mock_drift = AsyncMock()

        evidently_pod = EvidentlyMonitor()
        evidently_pod.register(Interfaces.DETECTED_DATA_DRIFT, mock_drift)

        req = {'current_data': {"col": [1, 2, 3, 4]}, 'reference_data': {"col": [1, 2, 3, 4]}}
        await evidently_pod.trigger(Interfaces.DETECT_DATA_DRIFT, req)

        mock_drift.assert_not_called()

        req = {'current_data': {"col": [50, 60, 70, 80]}, 'reference_data': {"col": [1, 2, 3, 4]}}
        await evidently_pod.trigger(Interfaces.DETECT_DATA_DRIFT, req)

        mock_drift.assert_called()

    async def test_detect_data_drift_warnings(self):
        mock_warning = AsyncMock()

        evidently_pod = EvidentlyMonitor()
        evidently_pod.register(Interfaces.WARNING, mock_warning)

        req = {'reference_data': {"col": [1, 2, 3, 4]}}
        await evidently_pod.trigger(Interfaces.DETECT_DATA_DRIFT, req)

        mock_warning.assert_called()
        req = mock_warning.call_args.args[0]
        self.assertEqual(req["warning"]["name"], "EvidentlyCurrentDataWarning")

        req = {'current_data': {"col": [1, 2, 3, 4]}}
        await evidently_pod.trigger(Interfaces.DETECT_DATA_DRIFT, req)

        mock_warning.assert_called()
        req = mock_warning.call_args.args[0]
        self.assertEqual(req["warning"]["name"], "EvidentlyReferenceDataWarning")
