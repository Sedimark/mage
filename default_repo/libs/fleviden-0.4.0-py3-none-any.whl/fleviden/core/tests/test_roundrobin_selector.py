# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

import numpy as np

from fleviden.core.interfaces import Interfaces
from fleviden.core.selectors.roundrobin_selector import RoundRobinSelector


class TestRoundRobinSelector(IsolatedAsyncioTestCase):
    async def test_select_batch(self):
        mock_selected = AsyncMock()

        selector = RoundRobinSelector(input_entry="clients", size=2, forward_input=True)
        selector.register(Interfaces.SELECTED, mock_selected)

        req = {"clients": ["Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Helen"]}

        await selector.trigger(Interfaces.SELECT_BATCH, req)

        mock_selected.assert_called()
        req = mock_selected.call_args[0][0]
        self.assertEqual(len(req["clients"]), 2)
        self.assertEqual(req["clients"], ["Alice", "Bob"])

    async def test_select_one(self):
        mock_selected = AsyncMock()

        selector = RoundRobinSelector(input_entry="clients", size=2, forward_input=True)
        selector.register(Interfaces.SELECTED, mock_selected)

        req = {"clients": ["Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Helen"]}

        await selector.trigger(Interfaces.SELECT_ONE, req)

        mock_selected.assert_called()
        req = mock_selected.call_args[0][0]
        self.assertEqual(len(req["clients"]), 1)
        self.assertEqual(req["clients"], ["Alice"])

    async def test_percentage_size(self):
        selector = RoundRobinSelector(input_entry="clients", size=0.5, forward_input=True)

        req = {"clients": ["Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Helen"]}

        await selector.trigger(Interfaces.INITIALIZE, req)
        self.assertEqual(selector.size, 4)

    async def test_select_numpy(self):
        mock_selected = AsyncMock()

        selector = RoundRobinSelector(input_entry="clients", size=2, forward_input=True)
        selector.register(Interfaces.SELECTED, mock_selected)

        req = {"clients": np.array(["Alice", "Bob", "Charlie"])}

        await selector.trigger(Interfaces.SELECT_ONE, req)

        mock_selected.assert_called()
        req = mock_selected.call_args[0][0]
        self.assertEqual(len(req["clients"]), 1)
        self.assertEqual(req["clients"], ["Alice"])

    async def test_round_completed(self):
        mock_selected = AsyncMock()
        mock_completed = AsyncMock()

        selector = RoundRobinSelector(input_entry="clients", size=2, forward_input=True)
        selector.register(Interfaces.SELECTED, mock_selected)
        selector.register(Interfaces.COMPLETED_ROUND, mock_completed)

        req = {"clients": ["Alice", "Bob", "Charlie"]}

        await selector.trigger(Interfaces.SELECT_BATCH, req)
        mock_selected.assert_called()
        mock_completed.assert_not_called()
        req = mock_selected.call_args[0][0]
        self.assertEqual(req["clients"], ["Alice", "Bob"])

        await selector.trigger(Interfaces.SELECT_BATCH, req)
        mock_selected.assert_called()
        mock_completed.assert_called()
        req = mock_selected.call_args[0][0]
        self.assertEqual(req["clients"], ["Charlie", "Alice"])

    async def test_not_a_list_error(self):
        mock_selected = AsyncMock()
        mock_error = AsyncMock()

        selector = RoundRobinSelector(input_entry="clients", size=2, forward_input=True)
        selector.register(Interfaces.SELECTED, mock_selected)
        selector.register(Interfaces.ERROR, mock_error)

        req = {"clients": "not-a-list"}

        await selector.trigger(Interfaces.SELECT_ONE, req)

        mock_error.assert_called()
        mock_selected.assert_not_called()

    async def test_size_exceeds_input_length(self):
        mock_warning = AsyncMock()

        selector = RoundRobinSelector(input_entry="clients", size=10)
        selector.register(Interfaces.WARNING, mock_warning)

        req = {"clients": ["Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Helen"]}

        await selector.trigger(Interfaces.INITIALIZE, req)

        mock_warning.assert_called()
        req = mock_warning.call_args[0][0]
        self.assertEqual(req["warning"]["name"], "RoundRobinSelectorSizeWarning")

    async def test_foward_input(self):
        mock_selected = AsyncMock()

        selector = RoundRobinSelector(input_entry="clients", size=2, forward_input=False)
        selector.register(Interfaces.SELECTED, mock_selected)

        req = {
            "clients": ["Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Helen"],
            "not-foward": "test",
        }

        await selector.trigger(Interfaces.SELECT_ONE, req)

        mock_selected.assert_called_once_with({"clients": ["Alice"]})
