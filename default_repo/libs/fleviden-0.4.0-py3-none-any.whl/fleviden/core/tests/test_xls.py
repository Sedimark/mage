# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, patch

import pandas as pd

from fleviden.core.interfaces import Interfaces
from fleviden.core.loaders.xls import XLS


class TestXLS(IsolatedAsyncioTestCase):

    @patch("pandas.read_excel")
    async def test_load(self, mock_read_excel):
        mock_loaded = AsyncMock()
        mock_data = pd.DataFrame({"Column1": [1, 2, 3], "Column2": ["A", "B", "C"]})

        xls_loader = XLS("dummy.xls", pd_args={}, output_key="dataframe")
        xls_loader.register(Interfaces.LOADED, mock_loaded)

        mock_read_excel.return_value = mock_data

        await xls_loader.trigger(Interfaces.LOAD, {})

        mock_loaded.assert_called()
        mock_read_excel.assert_called_once_with("dummy.xls")
        loaded_data = xls_loader.dataframe
        self.assertIsNotNone(loaded_data)
        pd.testing.assert_frame_equal(xls_loader.dataframe, mock_data)

    async def test_clear(self):
        mock_cleared = AsyncMock()
        xls_loader = XLS("dummy.xls", pd_args={}, output_key="dataframe")
        mock_data = pd.DataFrame({"Column1": [1, 2, 3], "Column2": ["A", "B", "C"]})

        xls_loader.dataframe = mock_data
        xls_loader.register(Interfaces.CLEARED, mock_cleared)

        await xls_loader.trigger(Interfaces.CLEAR, {})

        mock_cleared.assert_called()
        self.assertIsNone(xls_loader.dataframe)
