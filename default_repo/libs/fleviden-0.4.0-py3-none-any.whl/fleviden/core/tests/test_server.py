# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.arch.cen.server import Server
from fleviden.core.interfaces import Interfaces


class TestServer(IsolatedAsyncioTestCase):
    async def test_update(self):
        mock_updated = AsyncMock()

        server = Server(num_rounds=None, clients={"client": {}})
        server.register(Interfaces.UPDATED, mock_updated)

        req = {"origin": "client", "weights": [0.1, 0.2, 0.3]}

        await server.trigger(Interfaces.UPDATE, req)

        mock_updated.assert_called()
        req = mock_updated.call_args.args[0]

    async def test_partial_update(self):
        mock_updated = AsyncMock()

        server = Server(num_rounds=None, clients={"client": {}, "other-client": {}})
        server.register(Interfaces.UPDATED, mock_updated)

        req = {"origin": "client", "weights": [0.1, 0.2, 0.3]}

        await server.trigger(Interfaces.UPDATE, req)

        mock_updated.assert_called()
        req = mock_updated.call_args.args[0]

    async def test_broadcast(self):
        mock_broadcasted = AsyncMock()

        server = Server(num_rounds=None, clients={"client": {}})
        server.register(Interfaces.BROADCASTED, mock_broadcasted)

        req = {"origin": "client", "weights": [0.1, 0.2, 0.3]}

        await server.trigger(Interfaces.BROADCAST, req)

        mock_broadcasted.assert_called()
        req = mock_broadcasted.call_args.args[0]

    async def test_subscribe(self):
        mock_subscribed = AsyncMock()
        mock_start_training = AsyncMock()

        server = Server(num_rounds=2, min_clients=2)
        server.unsubscribe = ["client-id"]
        server.register(Interfaces.SUBSCRIBED, mock_subscribed)
        server.register(Interfaces.START_TRAINING, mock_start_training)

        await server.trigger(Interfaces.SUBSCRIBE, {"client": "client-id"})

        self.assertIn("client-id", server.subscribe)
        self.assertNotIn("client-id", server.unsubscribe)
        mock_subscribed.assert_called()
        mock_start_training.assert_not_called()

    async def test_unsubscribe(self):
        mock_unsubscribed = AsyncMock()

        server = Server(num_rounds=2, min_clients=2)
        server.clients = {"client-id": {}}
        server.subscribe = ["client-id"]
        server.register(Interfaces.UNSUBSCRIBED, mock_unsubscribed)

        await server.trigger(Interfaces.UNSUBSCRIBE, {"client": "client-id"})
        self.assertIn("client-id", server.unsubscribe)
        self.assertNotIn("client-id", server.subscribe)
        mock_unsubscribed.assert_called()

    async def test_start_training(self):
        mock_subscribed = AsyncMock()
        mock_start_training = AsyncMock()

        server = Server(num_rounds=2, min_clients=1)
        server.register(Interfaces.SUBSCRIBED, mock_subscribed)
        server.register(Interfaces.START_TRAINING, mock_start_training)

        await server.trigger(Interfaces.SUBSCRIBE, {"client": "client-id"})

        self.assertIn("client-id", server.subscribe)
        mock_start_training.assert_called()
        mock_subscribed.assert_called()

    async def test_update_num_clients(self):
        mock_updated = AsyncMock()

        server = Server(num_rounds=None, clients={"client": {}})
        server.register(Interfaces.UPDATED_NUM_CLIENTS, mock_updated)

        self.assertEqual(server.num_active_clients, 1)
        clients = {"client-two": {}, "client-three": {}}

        await server.trigger(Interfaces.UPDATE_NUM_CLIENTS, {"clients": clients})

        mock_updated.assert_called()
        self.assertEqual(server.num_active_clients, 2)

    async def test_update_subscriptions(self):
        server = Server(num_rounds=None)
        clients = {"client-id": {}}
        to_subscribe = ["other-client-id"]
        to_unsubscribe = ["client-id"]

        server.clients = clients
        server.subscribe = to_subscribe
        server.unsubscribe = to_unsubscribe

        await server._update_subscribed_clients({})

        self.assertEqual(server.clients, {"other-client-id": {}})
        self.assertEqual(server.subscribe, [])
        self.assertEqual(server.unsubscribe, [])

    async def test_duplicated_sub_error(self):
        mock_error = AsyncMock()

        server = Server(num_rounds=None)
        server.clients = {"client-id": {}}
        server.subscribe = ["client-id"]
        server.register(Interfaces.ERROR, mock_error)

        await server.trigger(Interfaces.SUBSCRIBE, {"client": "client-id"})

        mock_error.assert_called()
        req = mock_error.call_args.args[0]
        self.assertEqual(req["error"]["name"], "SubscribeError")

    async def test_unsubscribed_error(self):
        mock_error = AsyncMock()

        server = Server(num_rounds=None)
        server.clients = {"client-id": {}}
        server.register(Interfaces.ERROR, mock_error)

        await server.trigger(Interfaces.UNSUBSCRIBE, {"client": "other-client-id"})

        mock_error.assert_called()
        req = mock_error.call_args.args[0]
        self.assertEqual(req["error"]["name"], "UnsubscribeError")

    async def test_duplicated_weights_error(self):
        mock_error = AsyncMock()

        server = Server(num_rounds=None)
        server.clients = {"client-id": {}}
        server.updates = ["client-id"]
        server.register(Interfaces.ERROR, mock_error)

        await server.trigger(Interfaces.UPDATE, {"origin": "client-id"})

        mock_error.assert_called()
        req = mock_error.call_args.args[0]
        self.assertEqual(req["error"]["name"], "DuplicatedWeights")

    async def test_unregistered_client_error(self):
        mock_error = AsyncMock()

        server = Server(num_rounds=None)
        server.clients = {"client-id": {}}
        server.register(Interfaces.ERROR, mock_error)

        await server.trigger(Interfaces.UPDATE, {"origin": "other-client-id"})

        mock_error.assert_called()
        req = mock_error.call_args.args[0]
        self.assertEqual(req["error"]["name"], "UnregisteredClient")

    async def test_completed_broadcast(self):
        mock_stop_training = AsyncMock()

        server = Server(num_rounds=1, clients={"client": {}})
        server.register(Interfaces.STOP_TRAINING, mock_stop_training)

        # Initial broadcast
        await server.trigger(Interfaces.BROADCAST, {"weights": [0.1, 0.2, 0.3]})
        # First broadcast after updates
        await server.trigger(Interfaces.BROADCAST, {"weights": [0.1, 0.2, 0.3]})

        mock_stop_training.assert_called()
        req = mock_stop_training.call_args.args[0]
        self.assertIn("completed", req)
        self.assertTrue(req["completed"])

    async def test_completed_update(self):
        mock_stop_training = AsyncMock()

        server = Server(num_rounds=1, clients={"client": {}})
        server.register(Interfaces.STOP_TRAINING, mock_stop_training)

        # Initial update
        await server.trigger(Interfaces.UPDATE, {"origin": "client", "weights": [0.1, 0.2, 0.3]})
        # First update after updates
        await server.trigger(Interfaces.UPDATE, {"origin": "client", "weights": [0.1, 0.2, 0.3]})

        mock_stop_training.assert_called()
        req = mock_stop_training.call_args.args[0]
        self.assertIn("completed", req)
        self.assertTrue(req["completed"])
