# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, patch

from jsonschema import validate

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class TestPod(IsolatedAsyncioTestCase):
    async def test_match_route(self):
        pod = Pod()
        self.assertTrue(pod.is_match("/route/test", "/route/test"))

    async def test_do_not_match_route(self):
        pod = Pod()
        self.assertFalse(pod.is_match("/route/test", "/route/dev"))

    async def test_valid_has_errors(self):
        pod = Pod()
        instance = {"name": "John Doe", "age": 41}
        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
        }
        self.assertFalse(pod.has_errors(instance, schema))

    async def test_invalid_has_errors(self):
        pod = Pod()
        instance = {"name": "john doe", "age": "unknown"}
        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
        }
        expect = {
            "type": "string",
        }
        validate(pod.has_errors(instance, schema), expect)

    async def test_register_output(self):
        route = "/route/new"
        schema = {}
        expect = {
            "type": "object",
            "properties": {
                "matcher": {"type": "string"},
                "schema": {"type": "object"},
                "handlers": {
                    "type": "array",
                    "maxItems": 0,
                },
            },
        }

        pod = Pod()
        num_wires = len(pod._Pod__wires)
        pod.register(route, schema=schema)

        self.assertEqual(len(pod._Pod__wires), num_wires + 1)
        validate(pod._Pod__wires[-1], expect)

    async def test_register_output_handler(self):
        route = "/route/new"
        schema = {}
        expect = {
            "type": "object",
            "properties": {
                "matcher": {"type": "string"},
                "schema": {"type": "object"},
                "handlers": {
                    "type": "array",
                    "minItems": 1,
                },
            },
        }

        pod = Pod()
        num_wires = len(pod._Pod__wires)
        pod.register(route, schema=schema)
        pod.register(route, lambda req: req, schema=schema)

        self.assertEqual(len(pod._Pod__wires), num_wires + 1)
        validate(pod._Pod__wires[-1], expect)

    async def test_register_input(self):
        mock_handler = AsyncMock()
        route = "/route/new"
        schema = {}
        expect = {
            "type": "object",
            "properties": {
                "matcher": {"type": "string"},
                "schema": {"type": "object"},
                "handlers": {
                    "type": "array",
                    "minItems": 1,
                },
            },
        }

        pod = Pod()
        num_wires = len(pod._Pod__wires)
        pod.register(route, mock_handler, schema=schema)

        self.assertEqual(len(pod._Pod__wires), num_wires + 1)
        validate(pod._Pod__wires[-1], expect)

    async def test_register_input_multiple(self):
        mock_handler = AsyncMock()
        route = "/route/new"
        schema = {}
        expect = {
            "type": "object",
            "properties": {
                "matcher": {"type": "string"},
                "schema": {"type": "object"},
                "handlers": {
                    "type": "array",
                    "minItems": 2,
                },
            },
        }

        pod = Pod()
        num_wires = len(pod._Pod__wires)
        pod.register(route, mock_handler, mock_handler, schema=schema)

        self.assertEqual(len(pod._Pod__wires), num_wires + 1)
        validate(pod._Pod__wires[-1], expect)

    async def test_trigger_match(self):
        mock_handler = AsyncMock()
        route = "/route/new"
        schema = {}

        pod = Pod()
        pod.register(route, mock_handler, schema=schema)

        with patch.object(pod, 'is_match', wraps=pod.is_match) as is_match:
            await pod.trigger(route, {})
            is_match.assert_called_with(route, route)

    async def test_trigger_with_no_errors(self):
        mock_handler = AsyncMock()
        route = "/route/new"
        schema = {}

        pod = Pod()
        pod.register(route, mock_handler, schema=schema)

        with patch.object(pod, 'has_errors', wraps=pod.has_errors) as has_errors:
            await pod.trigger(route, {})
            has_errors.assert_called_with({}, {})

    async def test_trigger_with_valid_empty_schema(self):
        mock_handler = AsyncMock()
        route = "/route/new"
        schema = {}

        pod = Pod()
        pod.register(route, mock_handler, schema=schema)

        await pod.trigger(route, {})
        mock_handler.assert_called_with({})

    async def test_trigger_with_valid_schema(self):
        mock_handler = AsyncMock()
        route = "/route/new"
        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
        }
        info = {"name": "John Doe", "age": 57}

        pod = Pod()
        pod.register(route, mock_handler, schema=schema)

        await pod.trigger(route, info)
        mock_handler.assert_called_with(info)

    async def test_trigger_with_invalid_schema(self):
        mock_handler = AsyncMock()
        route = "/route/new"
        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
        }
        info = {"name": "John Doe", "age": 57.8}

        pod = Pod()
        pod.register(route, mock_handler, schema=schema)

        await pod.trigger(route, info)
        mock_handler.assert_not_called()

    async def test_trigger_warning(self):
        mock_handler = AsyncMock()
        mock_error = AsyncMock()
        route = "/route/new"
        schema = {
            "type": "object",
            "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
        }
        info = {"name": "John Doe", "age": 57.8}

        pod = Pod()
        pod.register(route, mock_handler, schema=schema)
        pod.register(Interfaces.ERROR, mock_error)

        await pod.trigger(route, info)
        mock_error.assert_called_once()

    async def test_link_all(self):
        pod_one = Pod()

        pod_one.register(Interfaces.ROUTE)
        Pod.link_all(Interfaces.DEBUG, pod_one, Interfaces.ROUTE, debuggeable=False)

    async def test_debug_mode_switch(self):
        Pod.debug_mode(False)
        self.assertFalse(Pod._Pod__debug)

        Pod.debug_mode(True)
        self.assertTrue(Pod._Pod__debug)

    async def test_debug_mode_trigger_verbose_zero(self):
        mock_debug = AsyncMock()
        pod = Pod()
        Pod.debug_mode(True, verbose=0)

        pod.register(Interfaces.DEBUG, mock_debug)
        pod.register(Interfaces.ROUTE)
        req = {"name": "John Doe", "age": 57, "nested": {"key": "value"}}

        await pod.trigger(Interfaces.ROUTE, req)

        mock_debug.assert_called()
        req = mock_debug.call_args.args[0]
        self.assertIn("req_keys", req)
        self.assertNotIn("req_summary", req)
        self.assertNotIn("req_trace", req)
        self.assertEqual(req["req_keys"], ["name", "age", "nested"])

    async def test_debug_mode_trigger_verbose_one(self):
        mock_debug = AsyncMock()
        pod = Pod()
        Pod.debug_mode(True, verbose=1)

        pod.register(Interfaces.DEBUG, mock_debug)
        pod.register(Interfaces.ROUTE)
        req = {"name": "John Doe", "age": 57, "nested": {"key": "value"}}

        await pod.trigger(Interfaces.ROUTE, req)

        mock_debug.assert_called()
        req = mock_debug.call_args.args[0]
        self.assertNotIn("req_keys", req)
        self.assertIn("req_summary", req)
        self.assertIn("comment", req)
        self.assertNotIn("req_trace", req)

    async def test_debug_mode_trigger_verbose_two(self):
        mock_debug = AsyncMock()
        pod = Pod()
        Pod.debug_mode(True, verbose=2)

        pod.register(Interfaces.DEBUG, mock_debug)
        pod.register(Interfaces.ROUTE)
        req = {"name": "John Doe", "age": 57, "nested": {"key": "value"}}

        await pod.trigger(Interfaces.ROUTE, req)

        mock_debug.assert_called()
        req = mock_debug.call_args.args[0]
        self.assertNotIn("req_keys", req)
        self.assertIn("req_summary", req)
        self.assertIn("req_trace", req)
        self.assertIn("req_id", req)

    async def test_debug_link(self):
        mock_debug = AsyncMock()
        pod_one = Pod()
        pod_two = Pod()
        Pod.debug_mode(True)

        pod_two.register(Interfaces.DEBUG, mock_debug)
        pod_one.register(Interfaces.ROUTE)
        pod_two.register(Interfaces.ROUTE)
        pod_one.link(Interfaces.ROUTE, pod_two, Interfaces.ROUTE)

        await pod_one.trigger(Interfaces.ROUTE, {"name": "John Doe", "age": 57})

        mock_debug.assert_called()
