# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.custom_pod import CustomPod


def my_test_fn(req: dict):
    output = {
        "error": {"name": "test-error"},
        "warning": {"name": "test-warning"},
        "info": {"name": "test-info"},
        "debug": {"name": "test-debug"},
        **req,
    }
    return output


def my_test_error_fn(_req: dict):
    output = "not-a-dict"
    return output


class TestCustomPod(IsolatedAsyncioTestCase):
    async def test_trigger_fn(self):
        mock_out = AsyncMock()
        mock_error = AsyncMock()
        mock_warning = AsyncMock()
        mock_info = AsyncMock()
        mock_debug = AsyncMock()

        custom_pod = CustomPod(fn=my_test_fn)
        custom_pod.register(Interfaces.OUT, mock_out)
        custom_pod.register(Interfaces.ERROR, mock_error)
        custom_pod.register(Interfaces.WARNING, mock_warning)
        custom_pod.register(Interfaces.INFO, mock_info)
        custom_pod.register(Interfaces.DEBUG, mock_debug)

        req = {"test": "test"}

        await custom_pod.trigger(Interfaces.IN, req)

        mock_error.assert_called_once_with({"name": "test-error"})
        mock_warning.assert_called_once_with({"name": "test-warning"})
        mock_info.assert_called_once_with({"name": "test-info"})
        mock_debug.assert_called_once_with({"name": "test-debug"})
        mock_out.assert_called()

    async def test_return_type_error(self):
        mock_out = AsyncMock()
        mock_error = AsyncMock()

        custom_pod = CustomPod(fn=my_test_error_fn)
        custom_pod.register(Interfaces.OUT, mock_out)
        custom_pod.register(Interfaces.ERROR, mock_error)

        req = {"test": "test"}

        await custom_pod.trigger(Interfaces.IN, req)

        mock_error.assert_called()
        req = mock_error.call_args[0][0]
        self.assertEqual(req["error"]["name"], "OutputTypeError")
        mock_out.assert_not_called()
