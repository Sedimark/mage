# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

import pickle
import tempfile
import warnings
from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, patch

import numpy as np
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LinearRegression
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC

from fleviden.core.interfaces import Interfaces
from fleviden.core.trainers.scikitlearn import ScikitLearn


def create_and_save_model(filepath, model_type="mlp"):
    # Create a simple classification dataset
    X = np.random.random((100, 20))
    y = np.random.randint(2, size=(100, 1)).ravel()

    # Define the MLPClassifier model
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=ConvergenceWarning)
        if model_type == "mlp":
            model = MLPClassifier(hidden_layer_sizes=(10,), max_iter=1000, random_state=42)
            model.fit(X, y)
        elif model_type == "linear":
            model = LinearRegression()
            model.fit(X, y)
        elif model_type == "svm":
            model = SVC()
            model.fit(X, y)

    # Save the model to a file
    with open(filepath, 'wb') as f:
        pickle.dump(model, f)


class TestScikitLearn(IsolatedAsyncioTestCase):
    def setUp(self):
        self.temp_model_file = tempfile.NamedTemporaryFile(suffix='.pkl', delete=True)
        create_and_save_model(self.temp_model_file.name)

        self.temp_reg_model_file = tempfile.NamedTemporaryFile(suffix='.pkl', delete=True)
        create_and_save_model(self.temp_reg_model_file.name, model_type="linear")

        self.temp_svm_model_file = tempfile.NamedTemporaryFile(suffix='.pkl', delete=True)
        create_and_save_model(self.temp_svm_model_file.name, model_type="svm")

        self.temp_model_save_file = tempfile.NamedTemporaryFile(suffix='.pkl', delete=True)

    def tearDown(self):
        # Clean up the temporary model file
        self.temp_model_file.close()
        self.temp_reg_model_file.close()
        self.temp_svm_model_file.close()

    async def test_load_model(self):
        # Load the model
        mock_loaded = AsyncMock()

        pod_scikitlearn = ScikitLearn(load_model_filepath=self.temp_model_file.name)

        pod_scikitlearn.register(Interfaces.LOADED_MODEL, mock_loaded)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {})

        mock_loaded.assert_called()
        req = mock_loaded.call_args[0][0]
        self.assertIn('weights', req)

    async def test_load_filepath_model(self):
        # Load the model
        mock_loaded = AsyncMock()
        filepath = self.temp_model_file.name

        pod_scikitlearn = ScikitLearn(load_model_filepath="not-a-filepath")

        pod_scikitlearn.register(Interfaces.LOADED_MODEL, mock_loaded)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {'filepath': filepath})

        mock_loaded.assert_called()
        req = mock_loaded.call_args[0][0]
        self.assertIn('weights', req)

    async def test_load_invalid_model(self):
        # Load the model
        mock_loaded = AsyncMock()
        mock_error = AsyncMock()
        filepath = self.temp_svm_model_file.name

        pod_scikitlearn = ScikitLearn(load_model_filepath=filepath)

        pod_scikitlearn.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_scikitlearn.register(Interfaces.ERROR, mock_error)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {'filepath': filepath})

        mock_error.assert_called()
        mock_loaded.assert_not_called()

    async def test_invalid_metrics(self):
        # Load the model
        mock_loaded = AsyncMock()
        mock_warning = AsyncMock()

        pod_scikitlearn = ScikitLearn(
            load_model_filepath=self.temp_model_file.name, metrics=["not-a-metric"]
        )

        pod_scikitlearn.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_scikitlearn.register(Interfaces.WARNING, mock_warning)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {})

        mock_warning.assert_called()
        mock_loaded.assert_called()
        req = mock_warning.call_args[0][0]
        self.assertIn('warning', req)

    async def test_train_model_weights(self):
        # Train the model
        mock_trained = AsyncMock()
        mock_loaded = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        epochs = 1
        batch_size = 32
        req = {'features': features, 'targets': targets, 'epochs': epochs, 'batch_size': batch_size}

        pod_scikitlearn = ScikitLearn(
            load_model_filepath=self.temp_model_file.name, send_gradients=False
        )
        pod_scikitlearn.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_scikitlearn.register(Interfaces.TRAINED, mock_trained)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=ConvergenceWarning)
            await pod_scikitlearn.trigger(Interfaces.TRAIN, {**req, **req_load})

        mock_trained.assert_called()
        req = mock_trained.call_args[0][0]
        self.assertIn('weights', req)

    async def test_train_model_gradients(self):
        # Train the model
        mock_trained = AsyncMock()
        mock_loaded = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        epochs = 1
        batch_size = 32
        req = {'features': features, 'targets': targets, 'epochs': epochs, 'batch_size': batch_size}

        pod_scikitlearn = ScikitLearn(
            load_model_filepath=self.temp_model_file.name, send_gradients=True
        )
        pod_scikitlearn.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_scikitlearn.register(Interfaces.TRAINED, mock_trained)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=ConvergenceWarning)
            await pod_scikitlearn.trigger(Interfaces.TRAIN, {**req, **req_load})

        mock_trained.assert_called()
        req = mock_trained.call_args[0][0]
        self.assertIn('gradients', req)

    async def test_evaluate_model(self):
        # Train the model
        mock_evaluated = AsyncMock()
        mock_loaded = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        completed = True

        req = {'features': features, 'targets': targets, 'completed': completed}

        pod_scikitlearn = ScikitLearn(
            load_model_filepath=self.temp_model_file.name, metrics=["accuracy"]
        )
        pod_scikitlearn.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_scikitlearn.register(Interfaces.EVALUATED, mock_evaluated)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_scikitlearn.trigger(Interfaces.EVALUATE, {**req, **req_load})

        mock_evaluated.assert_called()
        req = mock_evaluated.call_args[0][0]

    async def test_train_reg_model_weights(self):
        # Train the model
        mock_trained = AsyncMock()
        mock_loaded = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        epochs = 1
        batch_size = 32
        req = {'features': features, 'targets': targets, 'epochs': epochs, 'batch_size': batch_size}

        pod_scikitlearn = ScikitLearn(
            load_model_filepath=self.temp_reg_model_file.name, send_gradients=False
        )
        pod_scikitlearn.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_scikitlearn.register(Interfaces.TRAINED, mock_trained)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_scikitlearn.trigger(Interfaces.TRAIN, {**req, **req_load})

        mock_trained.assert_called()
        req = mock_trained.call_args[0][0]
        self.assertIn('weights', req)

    async def test_train_reg_model_gradients(self):
        # Train the model
        mock_trained = AsyncMock()
        mock_loaded = AsyncMock()

        features = np.random.random((100, 20))
        targets = np.random.randint(2, size=(100, 1))
        epochs = 1
        batch_size = 32
        req = {'features': features, 'targets': targets, 'epochs': epochs, 'batch_size': batch_size}

        pod_scikitlearn = ScikitLearn(
            load_model_filepath=self.temp_reg_model_file.name, send_gradients=True
        )
        pod_scikitlearn.register(Interfaces.LOADED_MODEL, mock_loaded)
        pod_scikitlearn.register(Interfaces.TRAINED, mock_trained)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {})
        req_load = mock_loaded.call_args[0][0]

        await pod_scikitlearn.trigger(Interfaces.TRAIN, {**req, **req_load})

        mock_trained.assert_called()
        req = mock_trained.call_args[0][0]
        self.assertIn('gradients', req)

    async def test_update_weights_with_gradients(self):
        mock_updated = AsyncMock()

        pod_scikitlearn = ScikitLearn(load_model_filepath=self.temp_reg_model_file.name)
        pod_scikitlearn.register(Interfaces.UPDATED_WEIGHTS, mock_updated)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {})

        grads = np.random.random(np.array(pod_scikitlearn.weights).shape).tolist()
        expected_weights = np.array(pod_scikitlearn.weights) - np.array(grads)

        await pod_scikitlearn.trigger(Interfaces.UPDATE_WEIGHTS, {'gradients': grads})

        mock_updated.assert_called()

        np.testing.assert_array_equal(pod_scikitlearn.weights, expected_weights)

    async def test_update_weights_with_weights(self):
        mock_updated = AsyncMock()

        pod_scikitlearn = ScikitLearn(load_model_filepath=self.temp_reg_model_file.name)
        pod_scikitlearn.register(Interfaces.UPDATED_WEIGHTS, mock_updated)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {})

        new_weights = np.random.random(np.array(pod_scikitlearn.weights).shape).tolist()

        await pod_scikitlearn.trigger(Interfaces.UPDATE_WEIGHTS, {'weights': new_weights})

        mock_updated.assert_called()
        np.testing.assert_array_equal(pod_scikitlearn.weights, new_weights)

    async def test_update_weights_warning(self):
        mock_updated = AsyncMock()
        mock_error = AsyncMock()

        pod_scikitlearn = ScikitLearn(load_model_filepath=self.temp_reg_model_file.name)
        pod_scikitlearn.register(Interfaces.UPDATED_WEIGHTS, mock_updated)
        pod_scikitlearn.register(Interfaces.ERROR, mock_error)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {})
        await pod_scikitlearn.trigger(Interfaces.UPDATE_WEIGHTS, {})

        mock_error.assert_called()
        req = mock_error.call_args[0][0]
        self.assertIn('error', req)
        self.assertEqual(req['error']['name'], 'NoWeights')

    async def test_save_model(self):
        mock_saved = AsyncMock()

        pod_scikitlearn = ScikitLearn(
            load_model_filepath=self.temp_model_file.name,
            save_model_filepath=self.temp_model_save_file.name,
        )
        pod_scikitlearn.register(Interfaces.SAVED_MODEL, mock_saved)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {})
        await pod_scikitlearn.trigger(Interfaces.SAVE_MODEL, {})

        mock_saved.assert_called()
        req = mock_saved.call_args[0][0]
        self.assertIn('filepath', req)
        self.assertEqual(req['filepath'], self.temp_model_save_file.name)

    async def test_save_model_error(self):
        mock_saved = AsyncMock()
        mock_error = AsyncMock()

        pod_scikitlearn = ScikitLearn(
            load_model_filepath=self.temp_model_file.name, save_model_filepath=None
        )
        pod_scikitlearn.register(Interfaces.SAVED_MODEL, mock_saved)
        pod_scikitlearn.register(Interfaces.ERROR, mock_error)

        await pod_scikitlearn.trigger(Interfaces.LOAD_MODEL, {})
        await pod_scikitlearn.trigger(Interfaces.SAVE_MODEL, {})

        mock_saved.assert_not_called()
        mock_error.assert_called()
        req = mock_error.call_args[0][0]
        self.assertIn('error', req)
        self.assertEqual(req['error']['name'], 'Scikit-LearnModelSavingError')
