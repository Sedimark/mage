# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

import numpy as np

from fleviden.core.interfaces import Interfaces
from fleviden.core.selectors.random_selector import RandomSelector


class TestRandomSelector(IsolatedAsyncioTestCase):
    async def test_random_replace(self):
        mock_selected = AsyncMock()

        selector = RandomSelector(size=0.5, input_entry="clients")

        selector.register(Interfaces.SELECTED, mock_selected)

        req = {"clients": ["Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Helen"]}

        await selector.trigger(Interfaces.SELECT, req)

        mock_selected.assert_called()
        req = mock_selected.call_args[0][0]
        self.assertEqual(len(req["clients"]), 4)
        self.assertNotIn("selection", req)

    async def test_fixed_size(self):
        mock_selected = AsyncMock()

        size = 3
        selector = RandomSelector(size=size, input_entry="clients")

        selector.register(Interfaces.SELECTED, mock_selected)

        req = {"clients": ["Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Helen"]}

        await selector.trigger(Interfaces.SELECT, req)

        mock_selected.assert_called()
        req = mock_selected.call_args[0][0]
        self.assertEqual(len(req["clients"]), size)

    async def test_random_no_replace(self):
        mock_selected = AsyncMock()

        selector = RandomSelector(
            size=0.5, input_entry="clients", output_entry="selection", forward_input=True
        )

        selector.register(Interfaces.SELECTED, mock_selected)

        req = {"clients": ["Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Helen"]}

        await selector.trigger(Interfaces.SELECT, req)

        mock_selected.assert_called()
        req = mock_selected.call_args[0][0]
        self.assertEqual(len(req["selection"]), 4)
        self.assertEqual(len(req["clients"]), 8)

    async def test_numpy_array(self):
        mock_selected = AsyncMock()

        selector = RandomSelector(size=0.5, input_entry="clients")

        selector.register(Interfaces.SELECTED, mock_selected)
        clients = np.array(["Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Helen"])

        req = {"clients": clients}

        await selector.trigger(Interfaces.SELECT, req)

        mock_selected.assert_called()
        req = mock_selected.call_args[0][0]
        self.assertEqual(len(req["clients"]), 4)
        self.assertNotIn("selection", req)

    async def test_not_list_error(self):
        mock_selected = AsyncMock()
        mock_error = AsyncMock()

        selector = RandomSelector(size=0.5, input_entry="clients")

        selector.register(Interfaces.SELECTED, mock_selected)
        selector.register(Interfaces.ERROR, mock_error)

        req = {"clients": "not-a-list"}

        await selector.trigger(Interfaces.SELECT, req)

        mock_selected.assert_not_called()
        mock_error.assert_called()
        req = mock_error.call_args[0][0]
        self.assertEqual(req["error"]["name"], "RandomSelectorTypeError")

    async def test_size_exceeding_length_warning(self):
        mock_selected = AsyncMock()
        mock_warning = AsyncMock()

        selector = RandomSelector(size=10, input_entry="clients")
        selector.register(Interfaces.SELECTED, mock_selected)
        selector.register(Interfaces.WARNING, mock_warning)

        req = {"clients": ["Alice", "Bob", "Charlie", "David", "Eve", "Frank", "Grace", "Helen"]}

        await selector.trigger(Interfaces.SELECT, req)

        mock_warning.assert_called()
        warning = mock_warning.call_args[0][0]
        self.assertEqual(warning["warning"]["name"], "RandomSelectorSizeWarning")

        mock_selected.assert_called()
        output = mock_selected.call_args[0][0]["clients"]
        self.assertEqual(len(output), len(req["clients"]))
