# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

import numpy as np
from BitVector import BitVector

from fleviden.core.encoders.elias import Elias
from fleviden.core.interfaces import Interfaces


class TestElias(IsolatedAsyncioTestCase):
    async def test_encode(self):
        mock_encoded = AsyncMock()

        weights = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])
        expected_encoded = BitVector(
            bitstring="010011010100010101010110010111011100001110010"
        )  # Concatenation of 1 to 9

        elias = Elias(entries=["weights"], replace=True)
        elias.register(Interfaces.ENCODED, mock_encoded)

        await elias.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        output = req["weights"]

        self.assertEqual(expected_encoded, output)

    async def test_decode(self):
        mock_decoded = AsyncMock()

        weights = BitVector(bitstring="010011010100010101010110010111011100001110010")
        expected_decoded = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])

        elias = Elias(entries=["weights"], replace=True)
        elias.register(Interfaces.DECODED, mock_decoded)

        await elias.trigger(Interfaces.DECODE, {"weights": weights})

        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        output = req["weights"]

        np.testing.assert_array_equal(expected_decoded, output)

    async def test_encode_no_replace(self):
        mock_encoded = AsyncMock()
        expected_key = "weights_elias_encoded"

        weights = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])

        elias = Elias(entries=["weights"], replace=False)
        elias.register(Interfaces.ENCODED, mock_encoded)

        await elias.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        self.assertTrue(expected_key in req)
        self.assertGreater(len(req), 1)

    async def test_decode_no_replace(self):
        mock_decoded = AsyncMock()
        expected_key = "weights_elias_decoded"

        weights = BitVector(bitstring="010011010100010101010110010111011100001110010")

        elias = Elias(entries=["weights"], replace=False)
        elias.register(Interfaces.DECODED, mock_decoded)

        await elias.trigger(Interfaces.DECODE, {"weights": weights})

        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        self.assertTrue(expected_key in req)
        self.assertGreater(len(req), 1)

    async def test_encode_invalid_entry(self):
        mock_warning = AsyncMock()

        weights = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])

        elias = Elias(entries=["this entry is not in the req"], replace=True)
        elias.register(Interfaces.WARNING, mock_warning)

        await elias.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_warning.assert_called()
        req = mock_warning.call_args.args[0]
        self.assertEqual(req["warning"]["name"], "MissingKey")

    async def test_decode_invalid_entry(self):
        mock_warning = AsyncMock()

        weights = weights = BitVector(bitstring="010011010100010101010110010111011100001110010")

        elias = Elias(entries=["this entry is not in the req"], replace=True)
        elias.register(Interfaces.WARNING, mock_warning)

        await elias.trigger(Interfaces.DECODE, {"weights": weights})

        mock_warning.assert_called()
        req = mock_warning.call_args.args[0]
        self.assertEqual(req["warning"]["name"], "MissingKey")

    async def test_encode_invalid_input_negative(self):
        mock_error = AsyncMock()

        weights = np.array([-1, -2, -3])

        elias = Elias(entries=["weights"], replace=True)
        elias.register(Interfaces.ERROR, mock_error)

        await elias.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_error.assert_called()
        req = mock_error.call_args.args[0]
        self.assertEqual(req["error"]["name"], "ValueError")

    async def test_encode_invalid_input_float(self):
        mock_error = AsyncMock()

        weights = np.array([1.5, 2.5, 3.5])

        elias = Elias(entries=["weights"], replace=True)
        elias.register(Interfaces.ERROR, mock_error)

        await elias.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_error.assert_called()
        req = mock_error.call_args.args[0]
        self.assertEqual(req["error"]["name"], "ValueError")

    async def test_encode_multiple_entries(self):
        mock_encoded = AsyncMock()

        weights1 = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])
        weights2 = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])
        expected_encoded = BitVector(bitstring="010011010100010101010110010111011100001110010")

        elias = Elias(entries=["weights1", "weights2"], replace=True)
        elias.register(Interfaces.ENCODED, mock_encoded)

        await elias.trigger(Interfaces.ENCODE, {"weights1": weights1, "weights2": weights2})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        output1 = req["weights1"]
        output2 = req["weights2"]

        self.assertEqual(expected_encoded, output1)
        self.assertEqual(expected_encoded, output2)

    async def test_encode_multiple_invalid_entries(self):
        mock_error = AsyncMock()

        weights1 = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])
        weights2 = np.array([-1, -2, 3, 4, 5, 6, 7, 8, -9])
        expected_encoded = BitVector(bitstring="010011010100010101010110010111011100001110010")

        elias = Elias(entries=["weights1", "weights2"], replace=True)
        elias.register(Interfaces.ERROR, mock_error)

        await elias.trigger(Interfaces.ENCODE, {"weights1": weights1, "weights2": weights2})

        mock_error.assert_called()
        req = mock_error.call_args.args[0]

        output1 = req["weights1"]

        self.assertEqual(expected_encoded, output1)
        self.assertEqual(req["error"]["name"], "ValueError")

    async def test_encode_decode(self):
        mock_encoded = AsyncMock()
        mock_decoded = AsyncMock()

        input_vector = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])
        weights = input_vector

        elias = Elias(entries=["weights"], replace=True)
        elias.register(Interfaces.ENCODED, mock_encoded)
        elias.register(Interfaces.DECODED, mock_decoded)

        await elias.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        await elias.trigger(Interfaces.DECODE, req)

        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        output_vector = req["weights"]

        np.testing.assert_array_equal(input_vector, output_vector)
