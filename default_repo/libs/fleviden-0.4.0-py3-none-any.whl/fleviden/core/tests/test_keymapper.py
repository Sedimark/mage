# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.flow.key_mapper import KeyMapper
from fleviden.core.interfaces import Interfaces


class TestKeyMapper(IsolatedAsyncioTestCase):
    """
    Unit tests for the KeyMapper class.
    """

    async def test_mapping(self):
        mock_out = AsyncMock()
        req = {"in": 0}

        keymapper_pod = KeyMapper(input_key="in", output_key="out")
        keymapper_pod.register(Interfaces.OUT, mock_out)

        await keymapper_pod.trigger(Interfaces.IN, req)

        mock_out.assert_called()
        req = mock_out.call_args.args[0]
        self.assertEqual(req["out"], 0)
        self.assertNotIn("in", req)

    async def test_mapping_warning(self):
        mock_warning = AsyncMock()
        mock_out = AsyncMock()
        req = {"out": 0}

        keymapper_pod = KeyMapper(input_key="in", output_key="out")
        keymapper_pod.register(Interfaces.WARNING, mock_warning)
        keymapper_pod.register(Interfaces.OUT, mock_out)

        await keymapper_pod.trigger(Interfaces.IN, req)

        mock_warning.assert_called()
        req = mock_warning.call_args.args[0]
        self.assertEqual(req["warning"]["name"], "KeyMapperInputKeyWarning")
        mock_out.assert_called()
        req = mock_out.call_args.args[0]
        self.assertIn("out", req)
