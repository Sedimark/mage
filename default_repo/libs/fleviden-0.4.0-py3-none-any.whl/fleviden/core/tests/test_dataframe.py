# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, patch

import pandas as pd

from fleviden.core.interfaces import Interfaces
from fleviden.core.loaders.dataframe import DataframeLoader


class TestDataframeLoader(IsolatedAsyncioTestCase):

    async def test_load(self):
        mock_loaded = AsyncMock()
        mock_data = pd.DataFrame({"x": [1, 2, 3], "y": ["A", "B", "C"]})

        dataframe_loader = DataframeLoader(
            features=["x"], targets=["y"], input_key="dataframe", shuffle=True
        )
        dataframe_loader.register(Interfaces.LOADED, mock_loaded)

        req = {"dataframe": mock_data}

        await dataframe_loader.trigger(Interfaces.LOAD, req)
        mock_loaded.assert_called()
        out = mock_loaded.call_args[0][0]
        self.assertIn("features", out)
        self.assertIn("targets", out)

    async def test_load_errpr(self):
        mock_loaded = AsyncMock()
        mock_error = AsyncMock()

        dataframe_loader = DataframeLoader(features=["x"], targets=["y"], input_key="dataframe")
        dataframe_loader.register(Interfaces.LOADED, mock_loaded)
        dataframe_loader.register(Interfaces.ERROR, mock_error)

        req = {"not-dataframe": "not-data"}

        await dataframe_loader.trigger(Interfaces.LOAD, req)
        mock_loaded.assert_not_called()
        mock_error.assert_called()
