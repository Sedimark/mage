# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock, patch

from fleviden.core.flow.starter import Starter


class TestStarter(IsolatedAsyncioTestCase):
    async def test_initialization(self):
        # Test if Starter initializes properly with wires and payloads
        wires = ["/wire1", "/wire2"]
        payloads = [{"data": 1}, {"data": 2}]
        starter = Starter(wires, payloads)

        # Verify that the internal attributes are set correctly
        self.assertEqual(starter._Starter__wires, wires)
        self.assertEqual(starter._Starter__payloads, payloads)

    @patch.object(Starter, 'trigger', new_callable=AsyncMock)
    async def test_on_run_triggers_correct_wires(self, mock_trigger):
        # Test if on_run triggers the correct wires with the corresponding payloads
        wires = ["/wire1", "/wire2"]
        payloads = [{"data": 1}, {"data": 2}]
        starter = Starter(wires, payloads)

        # Call on_run
        await starter.on_run()

        # Verify that the trigger method was called with the correct arguments
        mock_trigger.assert_any_call("/wire1", {"data": 1})
        mock_trigger.assert_any_call("/wire2", {"data": 2})
        self.assertEqual(mock_trigger.call_count, 2)

    @patch.object(Starter, 'trigger', new_callable=AsyncMock)
    async def test_on_run_with_no_wires(self, mock_trigger):
        # Test if on_run handles the case when no wires are provided
        wires = []
        starter = Starter(wires)

        # Call on_run
        await starter.on_run()

        # Ensure trigger was never called since there are no wires
        mock_trigger.assert_not_called()
