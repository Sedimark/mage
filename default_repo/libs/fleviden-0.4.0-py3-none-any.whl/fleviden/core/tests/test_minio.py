# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2024 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

import unittest
from unittest.mock import AsyncMock, patch

from fleviden.core.interfaces import Interfaces
from fleviden.core.services.minio_svc import MinIOClient


class TestMinIOClient(unittest.IsolatedAsyncioTestCase):
    """
    Unit tests for the MinIOClient class.
    """

    def setUp(self):
        self.base_url = "http://localhost:9000"
        self.access_key = "test_access_key"
        self.secret_key = "test_secret_key"
        self.client = MinIOClient(self.base_url, self.access_key, self.secret_key)

        # Mock the trigger method
        self.client.trigger = AsyncMock()

        # Mock the asynchronous HTTP methods
        self.client.http_client.head = AsyncMock()
        self.client.http_client.put = AsyncMock()
        self.client.http_client.delete = AsyncMock()
        self.client.http_client.get = AsyncMock()

    async def test_initialize_with_valid_data(self):
        """Test initialization with valid data."""
        req = {
            "bucket_name": "test-bucket",
            "object_name": "test-object",
            "filepath": "/path/to/file",
        }
        await self.client._initialize(req)

        self.client.trigger.assert_called_once_with(
            Interfaces.INITIALIZED, req, info_msg=f"MinIO client initialized with {req}."
        )

    async def test_initialize_with_missing_data(self):
        """Test initialization with missing data leading to an error."""
        req = {}
        await self.client._initialize(req)

        self.client.trigger.assert_called_once()
        self.assertIn(Interfaces.ERROR, self.client.trigger.call_args[0])

    async def test_create_bucket_when_bucket_exists(self):
        """Test creating a bucket that already exists."""
        req = {"bucket_name": "existing-bucket"}
        self.client.http_client.head.return_value = {}

        await self.client._create_bucket(req)

        self.client.http_client.head.assert_called_once()
        self.client.trigger.assert_called_once_with(
            Interfaces.WARNING, {}, info_msg="MinIO bucket existing-bucket already exists."
        )

    async def test_create_bucket_successfully(self):
        """Test creating a bucket successfully when it does not exist."""
        req = {"bucket_name": "new-bucket"}
        self.client.http_client.head.return_value = {"error": "NotFound"}
        self.client.http_client.put.return_value = {}

        await self.client._create_bucket(req)

        self.client.http_client.put.assert_called_once()
        self.client.trigger.assert_called_with(
            Interfaces.CREATED_BUCKET, {}, info_msg="MinIO bucket new-bucket created."
        )

    async def test_create_bucket_with_error(self):
        """Test error handling during bucket creation."""
        req = {"bucket_name": "error-bucket"}
        self.client.http_client.head.return_value = {"error": "NotFound"}
        self.client.http_client.put.side_effect = Exception("Server error")

        await self.client._create_bucket(req)

        self.client.trigger.assert_called_with(
            Interfaces.ERROR,
            {
                'error': {
                    'name': 'MinIOError',
                    'description': 'Error creating bucket.',
                    'details': 'Server error',
                }
            },
        )

    async def test_delete_bucket_when_bucket_does_not_exist(self):
        """Test deleting a bucket that does not exist."""
        req = {"bucket_name": "nonexistent-bucket"}
        self.client.http_client.head.return_value = {"error": "NotFound"}

        await self.client._delete_bucket(req)

        self.client.trigger.assert_called_with(
            Interfaces.WARNING,
            {"error": "NotFound"},
            info_msg="MinIO bucket to delete nonexistent-bucket does not exist.",
        )

    async def test_upload_object_with_file(self):
        """Test uploading an object with a file path."""
        with patch("builtins.open", unittest.mock.mock_open(read_data=b"file content")):
            req = {
                "bucket_name": "test-bucket",
                "object_name": "test-object",
                "filepath": "/path/to/file",
            }
            self.client.http_client.put.return_value = {}

            await self.client._upload_object(req)

            self.client.http_client.put.assert_called_once()
            self.client.trigger.assert_called_with(
                Interfaces.UPLOADED_OBJECT, {}, info_msg="MinIO: Object test-object uploaded."
            )

    async def test_delete_object_successfully(self):
        """Test deleting an object successfully."""
        req = {"bucket_name": "test-bucket", "object_name": "test-object"}
        self.client.http_client.delete.return_value = {}

        await self.client._delete_object(req)

        self.client.http_client.delete.assert_called_once()
        self.client.trigger.assert_called_with(
            Interfaces.DELETED_OBJECT, {}, info_msg="MinIO: Object test-object deleted."
        )

    async def test_download_object_successfully(self):
        """Test downloading an object successfully."""
        with patch("builtins.open", unittest.mock.mock_open()) as mock_file:
            req = {
                "bucket_name": "test-bucket",
                "object_name": "test-object",
                "filepath": "/path/to/download",
            }
            self.client.http_client.get.return_value = b"file content"

            await self.client._download_object(req)

            mock_file.assert_called_with("/path/to/download", "wb")
            mock_file().write.assert_called_once_with(b"file content")
            self.client.trigger.assert_called_with(
                Interfaces.DOWNLOADED_OBJECT,
                {},
                info_msg="Object test-object downloaded to /path/to/download.",
            )

    async def test_delete_bucket_successful(self):
        """Test bucket deletion when the bucket exists and is deleted successfully."""
        req = {"bucket_name": "test-bucket"}
        self.client.http_client.head.return_value = {}  # Simulate bucket exists
        self.client.http_client.delete.return_value = {}  # Simulate successful deletion

        await self.client._delete_bucket(req)

        self.client.http_client.head.assert_awaited_once_with(
            "/test-bucket", headers=unittest.mock.ANY
        )
        self.client.http_client.delete.assert_awaited_once_with(
            "/test-bucket", headers=unittest.mock.ANY
        )
        self.client.trigger.assert_awaited_with(
            Interfaces.DELETED_BUCKET, {}, info_msg="MinIO bucket test-bucket deleted."
        )

    async def test_delete_bucket_not_exists(self):
        """Test bucket deletion when the bucket does not exist."""
        req = {"bucket_name": "nonexistent-bucket"}
        self.client.http_client.head.return_value = {
            "error": "BucketNotFound"
        }  # Simulate bucket does not exist

        await self.client._delete_bucket(req)

        self.client.http_client.head.assert_awaited_once_with(
            "/nonexistent-bucket", headers=unittest.mock.ANY
        )
        self.client.trigger.assert_awaited_with(
            Interfaces.WARNING,
            {"error": "BucketNotFound"},
            info_msg="MinIO bucket to delete nonexistent-bucket does not exist.",
        )

    async def test_delete_bucket_deletion_error(self):
        """Test error during bucket deletion."""
        req = {"bucket_name": "error-bucket"}
        self.client.http_client.head.return_value = {}  # Simulate bucket exists
        self.client.http_client.delete.return_value = {
            "error": "DeletionError"
        }  # Simulate error during deletion

        await self.client._delete_bucket(req)

        self.client.http_client.head.assert_awaited_once_with(
            "/error-bucket", headers=unittest.mock.ANY
        )
        self.client.http_client.delete.assert_awaited_once_with(
            "/error-bucket", headers=unittest.mock.ANY
        )
        self.client.trigger.assert_awaited_with(Interfaces.ERROR, {"error": "DeletionError"})

    async def test_delete_bucket_check_existence_error(self):
        """Test error when checking if the bucket exists."""
        req = {"bucket_name": "check-error-bucket"}
        self.client.http_client.head.side_effect = Exception(
            "NetworkError"
        )  # Simulate error during HEAD request

        await self.client._delete_bucket(req)

        self.client.http_client.head.assert_awaited_once_with(
            "/check-error-bucket", headers=unittest.mock.ANY
        )
        self.client.trigger.assert_awaited_with(Interfaces.ERROR, unittest.mock.ANY)
