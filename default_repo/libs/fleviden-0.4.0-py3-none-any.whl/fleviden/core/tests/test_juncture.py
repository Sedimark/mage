# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

"""
Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
redistribution, modification, or use of this software, in source or binary form,
is strictly prohibited without the prior written consent of Eviden SAS.
"""

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from fleviden.core.flow.juncture import Juncture
from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class TestJuncture(IsolatedAsyncioTestCase):
    async def test_fire(self):
        pod_one = Pod()
        pod_two = Pod()

        mock = AsyncMock()

        pod_juncture = Juncture(count=2, output=Interfaces.FIRE)
        pod_juncture.register(Interfaces.FIRE, mock)

        pod_one.register("/one", schema={})
        pod_two.register("/two", schema={})

        pod_one.link("/one", pod_juncture, Interfaces.DOCK_0)
        pod_two.link("/two", pod_juncture, Interfaces.DOCK_1)

        await pod_one.trigger("/one", {})
        mock.assert_not_called()

        await pod_two.trigger("/two", {})
        mock.assert_called()

    async def test_fire_prefix(self):
        pod_one = Pod()
        pod_two = Pod()

        mock = AsyncMock()

        pod_juncture = Juncture(count=2, prefix="/prefixed", output=Interfaces.FIRE)
        pod_juncture.register(Interfaces.FIRE, mock)

        pod_one.register("/one", schema={})
        pod_two.register("/two", schema={})

        pod_one.link("/one", pod_juncture, "/prefixed-0")
        pod_two.link("/two", pod_juncture, "/prefixed-1")

        await pod_one.trigger("/one", {})
        mock.assert_not_called()

        await pod_two.trigger("/two", {})
        mock.assert_called()

    async def test_keep_reqs(self):
        pod_one = Pod()
        pod_two = Pod()

        mock = AsyncMock()

        pod_juncture = Juncture(count=2, keep=True, combine=False, output=Interfaces.FIRE)
        pod_juncture.register(Interfaces.FIRE, mock)

        pod_one.register("/one", schema={})
        pod_two.register("/two", schema={})

        pod_one.link("/one", pod_juncture, Interfaces.DOCK_0)
        pod_two.link("/two", pod_juncture, Interfaces.DOCK_1)

        req_name = {"name": "John"}
        req_age = {"age": 20}

        await pod_one.trigger("/one", req_name)
        mock.assert_not_called()
        await pod_two.trigger("/two", req_age)
        mock.assert_called()

        req = mock.call_args.args[0]
        self.assertEqual(req[Interfaces.DOCK_0], req_name)
        self.assertEqual(req[Interfaces.DOCK_1], req_age)

    async def test_keep_reqs_combine(self):
        pod_one = Pod()
        pod_two = Pod()

        mock = AsyncMock()

        pod_juncture = Juncture(count=2, keep=True, combine=True, output=Interfaces.FIRE)
        pod_juncture.register(Interfaces.FIRE, mock)

        pod_one.register("/one", schema={})
        pod_two.register("/two", schema={})

        pod_one.link("/one", pod_juncture, Interfaces.DOCK_0)
        pod_two.link("/two", pod_juncture, Interfaces.DOCK_1)

        req_name = {"name": "John"}
        req_age = {"age": 20}

        await pod_one.trigger("/one", req_name)
        mock.assert_not_called()
        await pod_two.trigger("/two", req_age)
        mock.assert_called()

        req = mock.call_args.args[0]
        self.assertEqual(req["name"], "John")
        self.assertEqual(req["age"], 20)
