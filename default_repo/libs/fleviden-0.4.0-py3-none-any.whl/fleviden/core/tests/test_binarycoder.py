# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring

# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

from unittest import IsolatedAsyncioTestCase
from unittest.mock import AsyncMock

from BitVector import BitVector

from fleviden.core.encoders.binarycoder import BinaryCoder
from fleviden.core.interfaces import Interfaces


class TestBinaryCoder(IsolatedAsyncioTestCase):
    async def test_encode(self):
        mock_encoded = AsyncMock()

        weights = [0.1, 0.2, 0.3, 0.4, 0.5]
        b64_data = (
            "KLUv/SA3jQEAZAKhZ3dlaWdodHOF+z+5mZr7P8mZmvs/0zP7P9mZmvs/4AAAAAAAAAQQAEFOm2YpAQ=="
        )

        binarycoder = BinaryCoder(coder="cbor2", compressor="zstd")
        binarycoder.register(Interfaces.ENCODED, mock_encoded)

        await binarycoder.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        assert str(req["data"]) == b64_data
        # print(req)

    async def test_decode(self):
        mock_decoded = AsyncMock()

        weights = [0.1, 0.2, 0.3, 0.4, 0.5]
        b64_data = (
            "KLUv/SA3jQEAZAKhZ3dlaWdodHOF+z+5mZr7P8mZmvs/0zP7P9mZmvs/4AAAAAAAAAQQAEFOm2YpAQ=="
        )
        req = {"data": b64_data}

        binarycoder = BinaryCoder(coder="cbor2", compressor="zstd")
        binarycoder.register(Interfaces.DECODED, mock_decoded)

        # Decode
        await binarycoder.trigger(Interfaces.DECODE, req)
        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        assert req['weights'] == weights
        # print(req)

    async def test_encode_decode_cbor2(self):
        mock_encoded = AsyncMock()
        mock_decoded = AsyncMock()

        weights = [0.1, 0.2, 0.3, 0.4, 0.5]

        binarycoder = BinaryCoder(coder="cbor2", compressor="zstd")
        binarycoder.register(Interfaces.ENCODED, mock_encoded)
        binarycoder.register(Interfaces.DECODED, mock_decoded)

        # Encode
        await binarycoder.trigger(Interfaces.ENCODE, {"weights": weights})
        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        # Decode
        await binarycoder.trigger(Interfaces.DECODE, req)
        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        assert req['weights'] == weights

    async def test_encode_decode_msgpack(self):
        mock_encoded = AsyncMock()
        mock_decoded = AsyncMock()

        weights = [0.1, 0.2, 0.3, 0.4, 0.5]

        binarycoder = BinaryCoder(coder="msgpack", compressor="zstd")
        binarycoder.register(Interfaces.ENCODED, mock_encoded)
        binarycoder.register(Interfaces.DECODED, mock_decoded)

        # Encode
        await binarycoder.trigger(Interfaces.ENCODE, {"weights": weights})
        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        # Decode
        await binarycoder.trigger(Interfaces.DECODE, req)
        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        assert req['weights'] == weights
        # print(req)

    async def test_encode_decode_json(self):
        mock_encoded = AsyncMock()
        mock_decoded = AsyncMock()

        weights = [0.1, 0.2, 0.3, 0.4, 0.5]

        binarycoder = BinaryCoder(coder="json", compressor="zstd")
        binarycoder.register(Interfaces.ENCODED, mock_encoded)
        binarycoder.register(Interfaces.DECODED, mock_decoded)

        # Encode
        await binarycoder.trigger(Interfaces.ENCODE, {"weights": weights})
        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        # Decode
        await binarycoder.trigger(Interfaces.DECODE, req)
        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        assert req['weights'] == weights
        # print(req)

    async def test_encode_decode_lzma(self):
        mock_encoded = AsyncMock()
        mock_decoded = AsyncMock()

        weights = [0.1, 0.2, 0.3, 0.4, 0.5]

        binarycoder = BinaryCoder(coder="cbor2", compressor="lzma")
        binarycoder.register(Interfaces.ENCODED, mock_encoded)
        binarycoder.register(Interfaces.DECODED, mock_decoded)

        # Encode
        await binarycoder.trigger(Interfaces.ENCODE, {"weights": weights})
        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        # Decode
        await binarycoder.trigger(Interfaces.DECODE, req)
        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        assert req['weights'] == weights
        # print(req)

    async def test_encode_decode_zstd(self):
        mock_encoded = AsyncMock()
        mock_decoded = AsyncMock()

        weights = [0.1, 0.2, 0.3, 0.4, 0.5]

        binarycoder = BinaryCoder(coder="cbor2", compressor="zstd")
        binarycoder.register(Interfaces.ENCODED, mock_encoded)
        binarycoder.register(Interfaces.DECODED, mock_decoded)

        # Encode
        await binarycoder.trigger(Interfaces.ENCODE, {"weights": weights})
        mock_encoded.assert_called()
        req = mock_encoded.call_args.args[0]

        # Decode
        await binarycoder.trigger(Interfaces.DECODE, req)
        mock_decoded.assert_called()
        req = mock_decoded.call_args.args[0]

        assert req['weights'] == weights
        # print(req)

    async def test_invalid_coder(self):
        mock_warning = AsyncMock()
        mock_encoded = AsyncMock()

        weights = [0.1, 0.2, 0.3, 0.4, 0.5]

        not_coder = "this is not a supported coder"

        binarycoder = BinaryCoder(coder=not_coder)
        binarycoder.register(Interfaces.WARNING, mock_warning)
        binarycoder.register(Interfaces.ENCODED, mock_encoded)

        # Encode
        await binarycoder.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_warning.assert_called()
        mock_encoded.assert_called()

    async def test_invalid_compressor(self):
        mock_warning = AsyncMock()
        mock_encoded = AsyncMock()

        weights = [0.1, 0.2, 0.3, 0.4, 0.5]

        not_compressor = "this is not a supported compressor"

        binarycoder = BinaryCoder(compressor=not_compressor)
        binarycoder.register(Interfaces.WARNING, mock_warning)
        binarycoder.register(Interfaces.ENCODED, mock_encoded)

        # Encode
        await binarycoder.trigger(Interfaces.ENCODE, {"weights": weights})

        mock_warning.assert_called()
        mock_encoded.assert_called()

    async def test_decode_error(self):
        mock_error = AsyncMock()
        mock_decoded = AsyncMock()

        binarycoder = BinaryCoder(coder="cbor2", compressor="zstd", entry="data")
        binarycoder.register(Interfaces.ERROR, mock_error)
        binarycoder.register(Interfaces.DECODED, mock_decoded)

        # Decode
        await binarycoder.trigger(
            Interfaces.DECODE, {"not-data": "The entry to decode is not here."}
        )

        mock_error.assert_called()
        mock_decoded.assert_not_called()

        req = mock_error.call_args.args[0]
        self.assertEqual(req["error"]["name"], "EntryNotFoundError")
