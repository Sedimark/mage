# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a customizable generic pod.
"""

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class CustomPod(Pod):
    """
    Creates a CustomPod pod that executes a user-defined function when triggered.

    The user-defined function takes input request message (dict), and returns a dictionary
    with the output response message. The output response message can contain the keys
    "error", "warning", "debug", and "info" to trigger the corresponding output wires. The
    rest of the message will be sent through the /out wire.
    """

    def __init__(self, fn: callable = None):
        """
        Creates a CustomPod pod.

        Parameters
        ----------
            fn : callable
                Function to be executed when triggering the /in wire.

        Inputs
        ------
            Interfaces.IN (/in)
                Input wire associated with the user-defined function.

        Outputs
        -------
            Interfaces.OUT (/out)
                Output wire triggered after the user-defined function is executed.

            Interfaces.ERROR (/error)
                Triggered if the output of the user-defined function contains an "error" key.

            Interfaces.WARNING (/warning)
                Triggered if the output of the user-defined function contains a "warning" key.

            Interfaces.DEBUG (/debug)
                Triggered if the output of the user-defined function contains a "debug" key.

            Interfaces.INFO (/info)
                Triggered if the output of the user-defined function contains an "info" key.
        """
        super().__init__()

        self.fn = fn

        self.register(Interfaces.IN, self._input_handler)
        self.register(Interfaces.OUT)

    async def _input_handler(self, req: dict):
        """
        Parameters
        ----------
            req : dict
                Input request message.
        """

        # Call the user-defined function
        res = self.fn(req)

        # Check if the output of the function is a dictionary
        if not isinstance(res, dict):
            error = super()._get_error(
                "OutputTypeError",
                "The output of the function must be a dictionary.",
                ValueError("The output of the function must be a dictionary."),
            )
            await self.trigger(Interfaces.ERROR, error)
            return

        # Trigger common output wires (error, warning, debug, info)
        # Error
        error = res.pop('error', None)
        if error is not None:
            await self.trigger(Interfaces.ERROR, error)
        # Warning
        warning = res.pop('warning', None)
        if warning is not None:
            await self.trigger(Interfaces.WARNING, warning)
        # Debug
        debug = res.pop('debug', None)
        if debug is not None:
            await self.trigger(Interfaces.DEBUG, debug)
        # Info
        info = res.pop('info', None)
        if info is not None:
            await self.trigger(Interfaces.INFO, info)

        # Trigger the output
        await self.trigger(Interfaces.OUT, res)
