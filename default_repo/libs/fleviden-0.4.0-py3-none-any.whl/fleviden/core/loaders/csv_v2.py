# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a CSV loader based on the pandas library.
"""

import pandas

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class CSV(Pod):
    """
    A CSV loader pod to load a dataframe from a .csv file using the pandas library.

    Internally it will make use of the pandas.read_csv() method to read the data with the
    arguments provided in the pd_args dictionary. The documentation for this method can be
    found at:
    https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.read_csv.html

    For example:

    Create the CSV loader:
        >>> csv_loader = CSV("dummy_path.csv", output_key="dataframe")

    Load the data:
        >>> await csv_loader.trigger(Interfaces.LOAD, {})

    The output at Interfaces.LOADED will contain the dataframe under the key specified in the
    'output_key' argument.
        >>> output = {"dataframe": <dataframe>}
    """

    def __init__(self, filepath: str, pd_args: dict = {}, output_key: str = "dataframe"):
        """
        Creates a CSV loader pod.

        Parameters
        ----------
            filepath : str
                Path to the csv file.

            pd_args : dict
                Dictionary containing the arguments for the pandas.read_csv() method.

            output_key : str
                Key under which the dataframe will be output. By default, "dataframe", so the
                output will be: req = {"dataframe": dataframe}

        Inputs
        ------
            Interfaces.LOAD (/load)
                A request to load the data from the csv file.

            Interfaces.CLEAR (/clear)
                A request to clear the loaded data.

            Interfaces.RELOAD (/reload)
                Clears the cache and reloads the data from the csv file.

        Outputs
        -------
            Interfaces.LOADED (/loaded)
                A trigger that sends the loaded dataframe

            Interfaces.CLEARED (/cleared)
                Triggered to notify that the cached data has been cleared.
        """
        super().__init__()

        self.filepath = filepath
        self.pd_args = pd_args
        self.output_key = output_key

        self.dataframe = None

        self.register(Interfaces.LOAD, self._load)
        self.register(Interfaces.LOADED)

        self.register(Interfaces.CLEAR, self._clear)
        self.register(Interfaces.CLEARED)

        self.register(Interfaces.RELOAD, self._clear, self._load)

    async def _load(self, req: dict) -> None:
        """Given a path to a csv file, loads a pandas dataframe with the method "pd.read_csv()".
        The arguments for this method can be provided as a dictionary  under 'pd_args'.
        """
        # Load dataframe if it is not stored in cache
        if self.dataframe is None:
            filepath = req.get('filepath', self.filepath)
            pd_args = req.get('pd_args', self.pd_args)
            self.dataframe = pandas.read_csv(filepath, **pd_args)

        await self.trigger(Interfaces.LOADED, {self.output_key: self.dataframe})

    async def _clear(self, _req) -> None:
        """Clears loaded data."""
        self.dataframe = None

        await self.trigger(Interfaces.CLEARED, {})
