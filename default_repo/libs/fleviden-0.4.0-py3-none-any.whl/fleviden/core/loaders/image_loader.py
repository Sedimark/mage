# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a generic loader for image datasets.

"""
import os
import random
from typing import List, Tuple

import numpy as np
from PIL import Image
from sklearn.preprocessing import LabelEncoder, OneHotEncoder

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod
from fleviden.core.validation.loaders.imageloader_validation import ImageLoaderValidation as val


class ImageLoader(Pod):
    """
    A generic loader for image datasets. It is assumed that the dataset
    is in a folder containing two subfolders: one for the images and one
    for the annotations.

    For example:

    >>> ├── dataset
    >>> │   ├── images
    >>> │   │   ├── img1.png
    >>> │   │   ├── img2.png
    >>> │   │   └── ...
    >>> │   ├── labels
    >>> │   │   ├── label1.txt
    >>> │   │   ├── label2.txt
    >>> │   │   └── ...
    """

    def __init__(
        self,
        dataset_dir: str,
        images_dir: str = "images",
        labels_dir: str = "labels",
        image_size: Tuple[int, int] = (128, 128),
        grayscale: bool = True,
        class_names: List[str] = None,
        one_hot: bool = True,
        shuffle: bool = True,
        channels_first: bool = True,
    ) -> None:
        """
        Creates an ImageLoader pod.

        Parameters
        ----------
            dataset_dir : str
                Path to the dataset folder.

            images_dir : str
                Path to the images subfolder.

            labels_dir : str
                Path to the labels subfolder.

            image_size : Tuple[int, int]
                Size of the images.

            grayscale : bool
                If True, images are transformed to
                grayscale.

            class_names : List[str]
                Class names in the labels.

            one_hot : bool
                If True, labels are one-hot encoded.
                Else, the labels are integer encoded.

            shuffle : bool
                If True, the data is shuffled.

            channels_first : bool
                Format of the images in terms of channels. If True, the output format
                is "channels_first" ([c, h, w]), as used in Pytorch. If False, the output
                format is "channels_last" ([h, w, c]), as in Keras.


        Inputs
        ------
            Interfaces.LOAD (/load)
                Loads the images and labels from the dataset.

            Interfaces.CLEAR (/clear)
                A request to clear the loaded data.

            Interfaces.RELOAD (/reload)
                Clears the loaded data and reloads the data.

        Outputs
        -------
            Interfaces.LOADED (/loaded)
                Triggered when the images and labels are loaded.

            Interfaces.CLEARED (/cleared)
                Triggered to notify that the cached data has been cleared.

            Interfaces.METADATA (/metadata)
                A trigger with metadata information about the dataset.
        """

        super().__init__()
        self.dataset_dir = dataset_dir
        self.images_dir = images_dir
        self.labels_dir = labels_dir
        self.image_size = image_size
        self.grayscale = grayscale
        self.class_names = class_names
        self.one_hot = one_hot
        self.channels_first = channels_first

        self.shuffle = shuffle

        self.loaded_features = None
        self.loaded_targets = None
        self.loaded_metadata = None

        self.register(Interfaces.LOAD, self._load, schema=val.Load)
        self.register(Interfaces.LOADED)

        self.register(Interfaces.CLEAR, self._clear)
        self.register(Interfaces.CLEARED)

        self.register(Interfaces.RELOAD, self._clear, self._load, schema=val.Load)

        self.register(Interfaces.METADATA)

    async def _load(self, req: dict) -> None:
        """
        Given the paths to the dataset, loads the images
        and labels as Python lists.

        If no paths are provided, it defaults to the ones
        specified in the pod constructor.

        For the sake of consistency within Fleviden, images
        are called "features" and labels are "targets".
        """

        try:
            # Load data if it is not stored
            if self.loaded_features is None or self.loaded_targets is None:
                dataset_dir = req.get('dataset_dir', self.dataset_dir)
                images_dir = req.get('images_dir', self.images_dir)
                labels_dir = req.get('labels_dir', self.labels_dir)

                images_path = os.path.join(dataset_dir, images_dir)
                labels_path = os.path.join(dataset_dir, labels_dir)

                features = self._load_images(images_path)
                targets = await self._load_labels(labels_path)

                if self.channels_first:
                    features = np.transpose(features, (0, 3, 1, 2))

                self.loaded_features = features
                self.loaded_targets = targets
                self.loaded_metadata = self._get_metadata(features, targets)

            # Shuffle data
            if self.shuffle:
                self.loaded_features, self.loaded_targets = self._shuffle(
                    self.loaded_features, self.loaded_targets
                )

            # Triggers
            await self.trigger(
                Interfaces.LOADED,
                {"features": self.loaded_features, "targets": self.loaded_targets},
                info_msg="Image dataset loaded",
            )
            await self.trigger(Interfaces.METADATA, {"metadata": self.loaded_metadata})

        except OSError as error:
            error = super()._get_error(
                "ImageDataLoadingError",
                "An error occurred when loading the image dataset",
                str(error),
            )
            await self.trigger(Interfaces.ERROR, error)

    async def _clear(self, _req) -> None:
        """Clears loaded data."""
        self.loaded_features = None
        self.loaded_targets = None
        self.loaded_metadata = None

        await self.trigger(Interfaces.CLEARED, {})

    def _load_images(self, images_path: str) -> np.ndarray:
        """
        Loads the images in a folder, in .jpg
        or .png.

        Parameters
        ----------
            images_path : str
                Path to the folder with the images.

        Returns
        -------
            images : list
                List of loaded images.
        """
        images = []
        # Load images
        for filename in sorted(os.listdir(images_path)):
            if filename.endswith('.png') or filename.endswith('.jpg'):
                image_path = os.path.join(images_path, filename)
                image = Image.open(image_path)

                # Resize image
                if self.image_size is not None:
                    image = image.resize(self.image_size)

                if self.grayscale:
                    image = image.convert('L')

                # Convert image to numpy array
                image_array = np.array(image)

                if self.grayscale:
                    image_array = np.expand_dims(image_array, axis=-1)

                # Normalize pixel values
                image_array = image_array.astype(np.float32) / 255.0
                images.append(image_array)

        return np.array(images)

    async def _load_labels(self, labels_path: str) -> np.ndarray:
        """
        Load the labels according to the file extension.

        Parameters
        ----------
            labels_path : str
                Path to the labels.

        Returns
        -------
            labels : array
                One-hot encoded labels.
        """
        labels = []

        # Check file format
        try:
            filename = os.listdir(labels_path)[0]
            if filename.endswith('.txt'):
                labels = await self._read_from_txt(labels_path)
            else:
                raise ValueError(f"Unsupported label file format: {filename}")
        except IndexError as e:
            error = super()._get_error(
                "LabelFileNotFoundError", f"No label files found in {labels_path}", str(e)
            )
            await self.trigger(Interfaces.ERROR, error)
            return np.array(labels)

        # Label encoding
        if self.class_names or self.one_hot:
            labels = self._encode_labels(labels, self.class_names, self.one_hot)

        return labels

    async def _read_from_txt(self, filepath: str) -> np.ndarray:
        """
        Reads either one or several .txt files
        with the annotations.

        Parameters
        ----------
            filepath : str
                Path to the folder with the files.

        Returns
        -------
            items : list
                Lines of the .txt file(s).
        """
        if not os.path.exists(filepath):
            return np.array([])

        files = sorted(os.listdir(filepath))
        items = []

        for filename in files:
            file_path = os.path.join(filepath, filename)
            try:
                with open(file_path, 'r') as file:
                    for line in file:
                        item = line.strip()
                        try:
                            item = int(item)
                        except ValueError:
                            pass
                        items.append(item)
            except Exception as e:
                error = super()._get_error(
                    "FileReadError", f"An error occurred when reading a file {file_path}", str(e)
                )
                await self.trigger(Interfaces.ERROR, error)

        return np.array(items)

    def _encode_labels(
        self, labels: List[str], class_names: List[str], one_hot: bool
    ) -> np.ndarray:
        """
        Encoding of the labels.

        Parameters
        ----------
            labels : List[str]
                Labels as strings.

            class_names : List[str]
                Class names in the dataset.

            one_hot : bool
                If True, labels are one-hot encoded,
                instead of just integer encoded.

        Returns
        --------
            [encoding]_labels : np.ndarray
                Encoded labels in either integer or
                one-hot format.
        """

        # To integer
        try:
            label_encoder = LabelEncoder()
            label_encoder.fit(class_names)
            integer_labels = label_encoder.transform(labels)
        except ValueError:  # They are already integer
            integer_labels = labels

        # To one-hot
        if one_hot:
            onehot_encoder = OneHotEncoder(
                sparse_output=False, categories=[range(len(class_names))]
            )
            onehot_labels = onehot_encoder.fit_transform(integer_labels.reshape(-1, 1))
            return onehot_labels

        return integer_labels

    def _shuffle(self, features: np.ndarray, targets: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Randomly shuffles features and targets.

        Parameters
        ----------
            features : np.ndarray
                Images sorted by filename.

            targets : np.ndarray
                Labels sorted by filename.

        Returns
        -------
            features : np.ndarray
                Images in random order.

            targets : np.ndarray
                Labels in random order.
        """

        feats_and_targets = list(zip(features, targets))
        random.shuffle(feats_and_targets)

        features, targets = zip(*feats_and_targets)

        return np.array(features), np.array(targets)

    def _get_metadata(self, features, targets):
        """
        Metadata information about the dataset.

        This metadata comprises: number of samples, number of features and targets,
        data types for features and targets.

        Parameters
        ----------
            features : np.ndarray
                The images.

            targets : np.ndarray
                The labels.

        Returns
        -------
            metadata : dict
                A dictionary containing metadata information.
        """
        metadata = {}

        # Number of samples
        metadata["num_samples"] = features.shape[0]

        # Number of features and targets
        metadata["num_features"] = features.shape[1:]
        metadata["num_targets"] = targets.shape[1:]

        # Data types of features and targets
        metadata["feature_types"] = features.dtype
        metadata["target_types"] = targets.dtype

        return metadata
