# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a dataframe loader to retrieve the list of features and targets from
a dataframe.
"""

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class DataframeLoader(Pod):
    """
    A dataframe loader that takes a pandas dataframe as input and returns columns in features
    and targets as specified.

    The loader also supports the option for shuffling the dataframe.

    For example, can be used with the XLS pod to retrieve features and targets from a .xls file:

    Create the pods:
        >>> xls_loader = XLS("data.xls", output_key="data")
        >>> df_loader = DataframeLoader(features=["x1", "x2"], targets=["y"], input_key="data")

    Link the output of the XLS loader with the input of the DataframeLoader:
        >>> xls_loader.link(Interfaces.LOADED, df_loader, Interfaces.LOAD)

    Trigger the pipeline:
        >>> await xls_loader.trigger(Interfaces.LOAD, {})

    The features and targets will be output through the Interfaces.LOADED wire.
    """

    def __init__(
        self, features: list, targets: list, input_key: str = "dataframe", shuffle: bool = True
    ):
        """
        Creates a DataframeLoader pod.

        Parameters
        ----------
            input_key: str
                Key under which the dataframe is provided. For example, "dataframe" for a request
                such as req = {"dataframe": my_dataframe}

            features : list
                Feature names.

            targets : list
                Target names.

            shuffle : bool
                Shuffle the data if True.

        Inputs
        ------
            Interfaces.LOAD (/load)
                A request to load features and targets from a dataframe.

        Outputs
        -------
            Interfaces.LOADED (/loaded)
                A trigger that sends the loaded features and targets.
        """
        super().__init__()
        self.input_key = input_key
        self.features = features
        self.targets = targets
        self.shuffle = shuffle

        self.register(Interfaces.LOAD, self._load)
        self.register(Interfaces.LOADED)

    async def _load(self, req: dict) -> None:
        """Given a dataframe, loads the columns specified for 'features' and 'targets'."""
        dataframe = req.get(self.input_key, None)

        if dataframe is not None:
            # Shuffle the data
            if self.shuffle:
                dataframe = dataframe.sample(frac=1)

            # Get features and targets
            features_names = req.get('features', self.features)
            targets_names = req.get('targets', self.targets)
            features = dataframe[features_names]
            targets = dataframe[targets_names]

            await self.trigger(Interfaces.LOADED, {"features": features, "targets": targets})
        else:
            error = super()._get_error(
                "DataframeNotFoundError",
                "No data was found under the specified key",
                {"input_key": self.input_key, "req_keys": list(req.keys())},
            )
            await self.trigger(Interfaces.ERROR, error)
