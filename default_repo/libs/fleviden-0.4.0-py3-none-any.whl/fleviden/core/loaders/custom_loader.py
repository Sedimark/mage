# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a customizable pod for loading data.
"""

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class CustomLoader(Pod):
    """A custom loader pod that loads data from a custom function defined by the user.

    Customizing a pod is equivalent to implementing the functions that are executed when
    triggering the pod's wires, in this case, the /load wire.

    The user must provide a function that takes a request message (a dictionary)
    as input and returns the loaded data as a dictionary. It is recommended that the
    output dictionary contains the keys "features" and "targets". If the output contains a key
    "metadata", its value will be sent through the /metadata interface instead.

    Example:

    Define a custom load function
        >>> def my_custom_load_fn(req: dict) -> dict:
        >>>     features, targets = # Load the data
        >>>     metadata = # Get metadata
        >>>     return = {"features": features, "targets": targets, "metadata": metadata}

    Create a CustomLoader pod
        >>> pod_loader = CustomLoader(load_fn=my_custom_load_fn)

    Load the data
        >>> pod_loader.trigger(Interfaces.LOAD, {})

    An example of CustomLoader that provides the same functionality as a CSV pod:
        >>> def load_csv(req: dict) -> dict:
        >>>    try:
        >>>        filepath = req["filepath"]
        >>>        features = req.get("features", None)
        >>>        targets = req.get("targets", None)
        >>>        pd_args = req.get("pd_args", {})
        >>>        df = pandas.read_csv(filepath, **pd_args)
        >>>        features = df[features]
        >>>        targets = df[targets]
        >>>        return {"features": features, "targets": targets}
        >>>    except OSError as error:
        >>>        return {"error": error}

    And then create the CustomLoader pod as follows:
        >>> pod_loader = CustomLoader(load=load_csv)
    """

    def __init__(
        self,
        load_fn: callable,
    ):
        """Creates a Custom Loader pod.

        Parameters
        ----------
            load_fn : callable
                Function to be executed when triggering the /load wire.
                This function should take a request message (dict) as input
                and return the loaded data also as dictionary.
                The output will be sent through the /loaded interface. If the
                output contains a key "metadata", its value will be sent through the
                /metadata interface instead.

        Inputs
        ------
            Interfaces.LOAD (/load)
                A request to load the data.

        Outputs
        -------
            Interfaces.LOADED (/loaded)
                A trigger that sends the loaded features and targets.

            Interfaces.METADATA (/metadata)
                A trigger that sends the metadata information about the loaded data.
        """
        super().__init__()

        self.load_fn = load_fn

        self.register(Interfaces.LOAD, self._load)
        self.register(Interfaces.LOADED)
        self.register(Interfaces.METADATA)

    async def _load(self, req: dict) -> None:
        """Given a request message, loads the data from the custom function
        and triggers the output interface."""

        res = self.load_fn(req)

        if not isinstance(res, dict):
            error = super()._get_error(
                "LoadOutputTypeError",
                "An error occurred when loading the dataset",
                ValueError("The output of the load function must be a dictionary."),
            )
            await self.trigger(Interfaces.ERROR, error)
            return

        error = res.get('error', None)
        if error is not None:
            await self.trigger(Interfaces.ERROR, error)
        else:
            metadata = res.pop('metadata', None)
            if metadata is not None:
                await self.trigger(Interfaces.METADATA, metadata)
            await self.trigger(Interfaces.LOADED, res)
