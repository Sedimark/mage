# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a CSV loader based on the pandas library.
"""

import pandas

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod
from fleviden.core.validation.loaders.csv_validation import CSVValidation as val


class CSV(Pod):
    """
    A CSV loader pod loads data from a csv file using the pandas library.
    """

    def __init__(
        self, filepath: str, features: list, targets: list, pd_args: dict, shuffle: bool = True
    ):
        """
        Creates a CSV loader pod.

        Parameters
        ----------
            filepath : str
                Path to the csv file.

            features : list
                Feature names.

            targets : list
                Target names.

            pd_args : dict
                A dictionary representing the args for the method "pd.read_csv()".

            shuffle : bool
                Shuffle the data if True.

        Inputs
        ------
            Interfaces.LOAD (/load)
                A request to load the data from the csv file.

            Interfaces.CLEAR (/clear)
                A request to clear the loaded data.

            Interfaces.RELOAD (/reload)
                Clears the loaded data and reloads the data from the csv file.

        Outputs
        -------
            Interfaces.LOADED (/loaded)
                A trigger that sends the loaded features and targets.

            Interfaces.CLEARED (/cleared)
                Triggered to notify that the cached data has been cleared.

            Interfaces.METADATA (/metadata)
                A trigger that sends metadata information about the dataframe.
        """
        super().__init__()

        self.filepath = filepath
        self.features = features
        self.targets = targets
        self.pd_args = pd_args

        self.shuffle = shuffle

        self.loaded_dataframe = None

        self.register(Interfaces.LOAD, self._load, schema=val.Load)
        self.register(Interfaces.LOADED)

        self.register(Interfaces.CLEAR, self._clear)
        self.register(Interfaces.CLEARED)

        self.register(Interfaces.RELOAD, self._clear, self._load, schema=val.Load)

        self.register(Interfaces.METADATA)

    async def _load(self, req: dict) -> None:
        """Given a path to a csv file, loads the features and targets
        into Python lists using the method "pd.read_csv()".
        A dict named "pd_args" stores the args for the method "pd.read_csv()".

        If features, targets, or pd_args are not provided,
        they default to the values specified in the constructor.
        """
        try:
            # Load dataframe if it is not stored in cache
            if self.loaded_dataframe is None:
                filepath = req.get('filepath', self.filepath)
                pd_args = req.get('pd_args', self.pd_args)
                self.loaded_dataframe = pandas.read_csv(filepath, **pd_args)

            # Shuffle the data
            if self.shuffle:
                self.loaded_dataframe = self.loaded_dataframe.sample(frac=1)

            # Get features and targets
            features_names = req.get('features', self.features)
            targets_names = req.get('targets', self.targets)
            features = self.loaded_dataframe[features_names]
            targets = self.loaded_dataframe[targets_names]

            # Get metadata with current features and targets
            metadata = self._get_metadata(self.loaded_dataframe, features_names, targets_names)

            # Triggers
            await self.trigger(Interfaces.LOADED, {"features": features, "targets": targets})
            await self.trigger(Interfaces.METADATA, {"metadata": metadata})

        except OSError as error:
            error = self._get_error(str(error))
            await self.trigger(Interfaces.ERROR, error)

    async def _clear(self, _req) -> None:
        """Clears loaded data."""
        self.loaded_dataframe = None

        await self.trigger(Interfaces.CLEARED, {})

    def _get_metadata(self, df, features_names, targets_names):
        """
        Metadata information about the dataframe.

        This metadata comprises: number of samples, number of features and targets,
        data types for features and targets.

        Parameters
        ----------
            df : pd.DataFrame
                The dataframe containing the data.

            features_names : list
                A list of feature column names.

            targets_names : list
                A list of target column names.

        Returns
        -------
            metadata : dict
                A dictionary containing metadata information.
        """
        metadata = {}

        # Number of samples
        metadata['num_samples'] = df.shape[0]

        # Number of features and targets
        metadata['num_features'] = len(features_names)
        metadata['num_targets'] = len(targets_names)

        # Data types of features and targets
        metadata['feature_types'] = df[features_names].dtypes.to_dict()
        metadata['target_types'] = df[targets_names].dtypes.to_dict()

        return metadata

    def _get_error(self, error) -> dict:
        name = "CSVLoadingError"
        description = "An error occurred when reading the csv file"
        details = error
        return super()._get_error(name, description, details)
