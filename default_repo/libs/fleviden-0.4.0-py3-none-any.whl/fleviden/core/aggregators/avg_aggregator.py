# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a generic weighted average aggregator.
"""

from typing import Optional

import numpy as np

from fleviden.core.interfaces.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class WeightedAvgAggregator(Pod):
    """
    A pod that aggregates a matrix of vectors using a weighted average.

    The aggregation is performed by calculating the weighted average of the input matrix of vectors
    using the specified alphas.

    The aggregation can be triggered by sending a request to the
    Interfaces.AGGREGATE interface. In the request, the matrix of parameters should be provided under the
    key specified by the 'input_key' attribute or under 'weights' or 'gradients'.

    If no 'alphas' are provided in the request, the alphas are set to
    1/num_parameters, where num_parameters is the number of vectors in the input matrix.

    The aggregated result is sent to the Interfaces.AGGREGATED interface, with the key specified by the
    'output_key' attribute, or the same key as the input if 'output_key' is not specified.
    """

    def __init__(self, input_key: Optional[str] = None, output_key: Optional[str] = None):
        """
        Creates a WeightedAvgAggregator pod.

        Parameters
        ----------
            input_key : str, optional
                The key to use to access the input matrix of vectors in the request.
                If not specified, 'weights' or 'gradients' keys will be used automatically.

            output_key : str, optional
                The key to use to send the aggregated result.
                If not specified, the same key as the input will be used automatically.

        Inputs
        ------
            Interfaces.AGGREGATE (/aggregate)
                A request to perform the weighted average of the matrix of parameters provided
                under the 'input_key'. The weights for each entry can be provided as a list under
                the key 'alpha'. If none is provided, all contributions are equal.

        Outputs
        -------
            Interfaces.AGGREGATED (/aggregated)
                Triggered with the output of the aggregation.
        """
        super().__init__()

        self.input_key = input_key
        self.output_key = output_key

        self.aggregation = None

        self.register(Interfaces.AGGREGATE, self._aggregate)
        self.register(Interfaces.AGGREGATED)

    def _get_parameters(self, req: dict) -> None:
        """Get the weights, gradients or the specified input_key key from the request."""
        if self.input_key in req:
            return np.array(req.get(self.input_key))
        elif "weights" in req:
            self.input_key = "weights"
            return np.array(req.get("weights"))
        elif "gradients" in req:
            self.input_key = "gradients"
            return np.array(req.get("gradients"))
        else:
            error = super()._get_error(
                "InvalidKeyError",
                f"No 'weights', 'gradients' or '{self.input_key}' in the req",
                list(req.keys()),
            )
            return error

    def _get_alphas(self, req: dict, num_parameters) -> None:
        """Get the alphas from the request or set them to 1/num_parameters."""
        alphas = req.get("alphas", None)
        if alphas is not None:
            if sum(alphas) != 1:
                error = super()._get_error(
                    "InvalidAlphas",
                    "The sum of alphas must be equal to 1",
                    alphas,
                )
                return error

        if alphas is None:
            alphas = [1 / num_parameters] * num_parameters

        return np.array(alphas).reshape(-1, 1)

    async def _aggregate(self, req: dict) -> None:
        """Aggregate the weights or gradients."""
        # Weights or gradients
        parameters = self._get_parameters(req)
        if isinstance(parameters, dict):
            await self.trigger(Interfaces.ERROR, parameters)
            return

        # Alphas (weighting factor)
        num_parameters = len(parameters)
        alphas = self._get_alphas(req, num_parameters)
        if isinstance(alphas, dict):
            await self.trigger(Interfaces.ERROR, alphas)
            return

        # Average
        self.aggregation = np.sum(alphas * parameters, axis=0).tolist()

        # Send aggregation
        self.output_key = self.input_key if self.output_key is None else self.output_key

        await self.trigger(
            Interfaces.AGGREGATED,
            {self.output_key: self.aggregation},
            info_msg=f"{self.output_key.capitalize()} aggregated",
        )
