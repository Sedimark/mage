# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a geometric median aggregator.
"""

import numpy as np

from fleviden.core.interfaces.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class GeometricMedianAggregator(Pod):
    """
    A pod to compute the geometric median of a NxM matrix of local updates, where N is the number
    of models and M is the model length.

    The geometric median is the point in the subset that minimizes the sum of Euclidean distances to
    all points. It is calculated iteratively, adjusting the median until the difference between
    steps is lower than a tolerance value, or a maximum number of iterations is reached.

    This aggregation method presents more robustness against adversarial clients, by
    minimizing the effect of outliers, with respect to other approaches such as the mean.

    For example:

    Create a GeometricMedianAggregator pod:
        >>> geomedian_aggr = GeometricMedianAggregator(input_key="weights", max_iter=10, tol=1e-5)

    Aggregate the models:
        >>> req = {"weights": [[1, 2, 5], [2, 5, 1], [5, 1, 2]]}
        >>> geomedian_aggr.trigger(Interfaces.AGGREGATE, req)

    The output, sent through Interfaces.AGGREGATED, will be:
        >>> output = {"weights": [2.66, 2.66, 2.66]}
    """

    def __init__(
        self, input_key: str = "weights", output_key: str = "weights", max_iter: int = 10, tol=1e-5
    ):
        """
        Creates a GeometricMedianAggregator pod.

        Parameters
        ----------
            input_key : str
                Key in the input request containing the matrix of models.

            output_key : str
                Key in the output request where the aggregation result is stored.

            max_iter : int
                Maximum number of iterations to compute the geometric median.

            tol : float
                Relative min distance difference between the median in the previous and current
                iteration to stop the loop.

        Inputs
        ------
            Interfaces.AGGREGATE (/aggregate)
                A request to compute the median of the models.

        Outputs
        -------
            Interfaces.AGGREGATED (/aggregated)
                Triggered with the output of the aggregation.
        """
        super().__init__()

        self.input_key = input_key
        self.output_key = output_key
        self.max_iter = max_iter
        self.tol = tol

        self.register(Interfaces.AGGREGATE, self._aggregate)
        self.register(Interfaces.AGGREGATED)

    async def _aggregate(self, req: dict) -> None:
        """Computes the geometric median of the specified entry in the request."""
        if not self.input_key in req:
            error = super()._get_error(
                "KeyNotFoundError",
                "The specified key for the aggregation is not present in the req.",
                {"input_key": self.input_key, "req_keys": str(req.keys())},
            )
            await self.trigger(Interfaces.ERROR, error)
            return

        parameters = np.array(req.get(self.input_key))

        median = np.mean(parameters, axis=0)  # Initial estimate with the mean

        for _ in range(self.max_iter):
            distances = np.linalg.norm(parameters - median, axis=1) + 1e-9

            # Move the median towards the furthest models
            weights = 1 / distances
            weights = weights / weights.sum()
            new_median = np.sum(weights[:, np.newaxis] * parameters, axis=0)

            if np.linalg.norm(new_median - median) < self.tol:
                break
            median = new_median

        await self.trigger(Interfaces.AGGREGATED, {self.output_key: median.tolist()})
