# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a median aggregator.
"""

import numpy as np

from fleviden.core.interfaces.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class MedianAggregator(Pod):
    """
    A pod that aggregates a matrix of NxM local updates as the coordinate-wise median, where
    N is the number of models and M is the model length.

    A median aggregator is more robust against outliers than the mean aggregator, but can present
    some shifts in the optimization trajectory. It is recommended to defend against adversarial
    clients.

    For example:

    Create a MedianAggregator pod:
        >>> median_aggr = MedianAggregator(input_key="weights", output_key="weights")

    Aggregate the models:
        >>> req = {"weights": [[1, 2, 10], [2, 10, 1], [10, 1, 2]]}
        >>> median_aggr.trigger(Interfaces.AGGREGATE, req)

    The output will be:
        >>> out = {"weights": [2, 2, 2]}
    """

    def __init__(self, input_key: str = "weights", output_key: str = "weights"):
        """
        Creates a MedianAggregator pod.

        Parameters
        ----------
            input_key : str
                Key in the input request containing the matrix of models.

            output_key : str
                Key in the output request where the aggregation result is stored.

        Inputs
        ------
            Interfaces.AGGREGATE (/aggregate)
                A request to compute the median of the models.

        Outputs
        -------
            Interfaces.AGGREGATED (/aggregated)
                Triggered with the output of the aggregation.
        """
        super().__init__()

        self.input_key = input_key
        self.output_key = output_key

        self.register(Interfaces.AGGREGATE, self._aggregate)
        self.register(Interfaces.AGGREGATED)

    async def _aggregate(self, req: dict) -> None:
        """Computes the median of the specified entry in the request."""
        if not self.input_key in req:
            error = super()._get_error(
                "KeyNotFoundError",
                "The specified key for the aggregation is not present in the req.",
                {"input_key": self.input_key, "req_keys": str(req.keys())},
            )
            await self.trigger(Interfaces.ERROR, error)
            return

        parameters = np.array(req.get(self.input_key))
        aggregation = np.median(parameters, axis=0)

        await self.trigger(Interfaces.AGGREGATED, {self.output_key: list(aggregation)})
