# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a Weighted Aggregation for Federated Learning functionality.

Reference:

[1] Kamp, M., Adilova, L., Sicking, J., Hüger, F., Schlicht, P., Wirtz, T., & Wrobel, S. (2019).
Efficient decentralized deep learning by dynamic model averaging. In Machine Learning and Knowledge
Discovery in Databases: European Conference, ECML PKDD 2018, Dublin, Ireland, September 10–14, 2018,
Proceedings, Part I 18 (pp. 393-409). Springer International Publishing.
"""

import numpy as np

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod
from fleviden.core.utils.clip_normalization import clip_normalization
from fleviden.core.validation.aggregators.weighted_aggregator_validation import (
    WeightedAggrValidation as val,
)


class WeightedAggregator(Pod):
    """A weighted aggregator implementation.

    This Pod implements the logic to aggregate gradients or weights and to apply clip
    normalization for the prevention of exploding gradients.

    For the clip norm to work in
    weights mode (when clients send weights), the pod must be initialized with the initial
    model parameters. This is done by linking the output of another pod (such as trainer/loaded),
    to the initialize wire of the aggregator pod.

    When dealing with gradients, a learning rate can be provided to apply a step of SGD
    to the gradients before aggregation.
    """

    def __init__(
        self,
        apply_clip_normalization: bool = False,
        learning_rate: float = 1.0,
        accumulate_gradients: bool = False,
    ):
        """
        Initializes the WeightedAggregator Pod.

        Parameters
        ----------
            apply_clip_normalization : bool, optional
                Whether to apply clip normalization. Defaults to False.

            learning_rate : float, optional
                The learning rate to be used in the SGD step. Defaults to 1.0.

            accumulate_gradients : bool, optional
                Whether to accumulate all aggregated gradients from several rounds.
                Defaults to False. This is useful in hierarchical topologies when, for cross-silo
                aggregation, central servers need to send all intra-silo updates at once.
                Thus, set to True in intermediate servers in Hierarchical.
                Only in gradients mode. Will be sent instead of the last aggregation in the final
                intra-silo round, through the /completed wire.

        Inputs
        ------
            Interfaces.AGGREGATE (/aggregate)
                A request to aggregate a vector with a given parameter.

            Interfaces.INITIALIZE (/initialize)
                A request to initialize the aggregator with the initial weights.

            Interfaces.UPDATE_WEIGHTS (/update-weights)
                Updates the stored weights.

        Outputs
        -------
            Interfaces.AGGREGATED (/aggregated)
                A notification that the aggregation is completed.

            Interfaces.COMPLETED (/completed)
                A notification that the aggregation is completed and
                that the federated process is finished.

            Interfaces.UPDATED_WEIGHTS (/updated-weights)
                A notification that the weights have been updated.
        """
        super().__init__()
        self.apply_clip_normalization = apply_clip_normalization
        self.learning_rate = learning_rate
        self.aggregation: np.ndarray | None = None

        # For clip norm with weights
        self.previous_weights: np.ndarray | None = None
        self.is_initialized = False

        self.all_parameters: list = []
        self.all_alphas: list[float] = []
        self.sum_alphas: float = 0.0
        self.output_req = {}
        self.mode = "gradients"

        # For gradient accumulation
        self.accumulate_gradients = accumulate_gradients
        self.accumulated_gradients: np.ndarray | None = None

        self.register(Interfaces.INITIALIZE, self._initialize, schema=val.Initialize)
        self.register(Interfaces.AGGREGATE, self._aggregate, schema=val.Aggregate)
        self.register(Interfaces.AGGREGATED)
        self.register(Interfaces.COMPLETED)

        self.register(Interfaces.UPDATE_WEIGHTS, self._update_weights)

    async def _initialize(self, req: dict):
        """
        Initializes the weighted aggregator by setting the initial state of the weights
        if clip normalization is enabled.
        Parameters
        ----------
            req : dict
                The request containing the weights to be used as the previous aggregation.
        Notes
        -----
            This method is only necessary when clip normalization is enabled
            (apply_clip_normalization=True). In this case, it is essential to link a pod
            to send the initial weights to the initialize wire of the aggregator pod.
            This ensures that the initial weights are set correctly for subsequent
            normalization processes.
        """
        if not self.is_initialized and self.apply_clip_normalization:
            self.previous_weights = req.get('weights')
            self.is_initialized = True

    async def _update_weights(self, req: dict):
        """
        Updates the stored weights with the new weights.
        Parameters
        ----------
            req : dict
                The request containing the weights to be used as the previous aggregation.
        """
        if self.apply_clip_normalization:
            self.previous_weights = req.get('weights')

    async def _aggregate(self, req: dict):
        """
        Stores and aggregates vectors of float numbers.
        Accumulates the received vectors using a provided
        parameter between zero and one.

        When the sum of the parameters is one it triggers
        the `/aggregated` wire with the result. If the req
        contains the "completed" flag set to True, the
        aggregator triggers the `/completed` interface instead.

        Parameters
        ----------
            req : dict
                The request containing the parameters and the weighting factor alpha.

        Raises
        ------
            ParamError
                If the received alpha is out of the range (0, 1].

            ParamSumError
                If the sum of the alphas exceeds one.
        """

        if "weights" in req:
            parameters = req.get("weights")
            self.mode = "weights"
        elif "gradients" in req:
            parameters = req.get("gradients")
            self.mode = "gradients"

        alpha = self._get_alpha(req)

        if alpha <= 0 or alpha > 1:
            await self.trigger(Interfaces.ERROR, self._get_alpha_error(alpha))

        self.sum_alphas += alpha
        if self.sum_alphas > 1:
            await self.trigger(Interfaces.ERROR, self._get_alpha_sum_error())

        if parameters is not None:
            self.all_parameters.append(parameters)
        self.all_alphas.append(alpha)

        if len(self.all_alphas) == req["num_clients"] and self.sum_alphas == 1:
            self.output_req["num_clients"] = req["num_clients"]
            await self._finalize_aggregation(req.get('completed', False))

    async def _finalize_aggregation(self, completed: bool = False):
        """
        Finalizes the aggregation process after all expected vectors have been received.

        Parameters
        ----------
            completed : bool, optional
                Whether the aggregation process is completed.
        """
        parameters_matrix = np.array(self.all_parameters)
        alphas_matrix = np.array(self.all_alphas).reshape(-1, 1)

        # In gradients mode, apply clip norm and SGD step
        if self.mode == "gradients":
            if self.apply_clip_normalization:
                parameters_matrix, clip_value = clip_normalization(parameters_matrix)
                self.output_req["clip_value"] = clip_value

            adjusted_parameters = self._sgd_step(parameters_matrix, self.learning_rate)

        # In weights mode, apply clip norm after calculating the gradients from previous weights
        elif self.mode == "weights":
            if self.apply_clip_normalization:
                if self.previous_weights is not None:
                    clipped_gradients = np.array(self.previous_weights) - np.array(
                        parameters_matrix
                    )
                    clipped_gradients, clip_value = clip_normalization(clipped_gradients)
                    self.output_req["clip_value"] = clip_value
                    clipped_gradients = self._sgd_step(clipped_gradients, self.learning_rate)
                    adjusted_parameters = np.array(self.previous_weights) - clipped_gradients
                    self.previous_weights = adjusted_parameters
                else:
                    await self.trigger(
                        Interfaces.ERROR, self._get_clip_normalization_initialization_error()
                    )
                    adjusted_parameters = parameters_matrix
            else:
                adjusted_parameters = parameters_matrix

        # Average
        self.aggregation = np.sum(alphas_matrix * adjusted_parameters, axis=0)

        # Send aggregation and reset state
        await self._send_aggregation(completed)

    def _sgd_step(self, gradients: np.ndarray, learning_rate: float) -> np.ndarray:
        """
        Weights down the gradients by the learning rate.

        Parameters
        ----------
            gradients : np.ndarray
                The gradients.

            learning_rate : float
                The learning rate.

        Returns
        -------
            np.ndarray
                Gradients multiplied by the learning rate.
        """

        return learning_rate * gradients

    def _get_alpha(self, req: dict) -> float:
        """
        Helper function to obtain the alpha used in the aggregation.
        """
        num_clients = req.get("num_clients", None)
        return float(req.get('alpha', 1.0 / num_clients if num_clients is not None else 0))

    async def _send_aggregation(self, completed: bool = False) -> None:
        """
        Handles the global parameters transmission.

        Sends the aggregated weights or gradients and resets the aggregation state.

        Parameters
        ----------
            completed : bool, optional
                Whether the aggregation process is completed. Defaults to False.
        """
        # Gradient accumulation
        if self.accumulate_gradients and self.mode == "gradients":
            if self.accumulated_gradients is None:
                self.accumulated_gradients = self.aggregation
            else:
                self.accumulated_gradients += self.aggregation

        result = self.aggregation.tolist()
        self.aggregation = None
        self.sum_alphas = 0.0
        self.all_parameters = []
        self.all_alphas = []

        if completed:
            acc_mode = ""
            # Send accumulated gradients only in completed state
            if self.accumulated_gradients is not None and self.accumulate_gradients:
                result = self.accumulated_gradients.tolist()
                self.accumulated_gradients = None
                acc_mode = "(accumulated) "

            await self.trigger(
                Interfaces.COMPLETED,
                {self.mode: result, "completed": True, **self.output_req},
                info_msg=f"Sending {acc_mode}aggregated {self.mode} (completed)",
            )
        else:
            await self.trigger(
                Interfaces.AGGREGATED,
                {self.mode: result, **self.output_req},
                info_msg=f"{self.mode.capitalize()} aggregated",
            )

        self.output_req = {}

    def _get_alpha_error(self, alpha: float) -> dict:
        """
        Creates an error message for invalid parameters.
        """
        name = "ParamError"
        description = (
            " The received parameter to be used in the aggregation of vectors is not between zero"
            " and one which is not correct."
        )
        details = {"alpha": alpha}
        return super()._get_error(name, description, details)

    def _get_alpha_sum_error(self) -> dict:
        """
        Creates an error message for parameters that sum to more than one.
        """
        name = "ParamSumError"
        description = (
            " The received parameters to be used in the aggregation of vectors sum more than one"
            " which is not correct."
        )
        details = {"sum": self.all_alphas}
        return super()._get_error(name, description, details)

    def _get_clip_normalization_initialization_error(self) -> dict:
        """
        Creates an error message if the Pod has not been initialized correctly to apply clip
        normalization.
        """
        name = "ClipNormalizationInitializationError"
        description = (
            " The Pod has not been initialized correctly. Previous aggregation state is required"
            " for applying clip normalization. Ensure that the initial weights are linked from"
            " another pod to the initialize wire of the aggregator pod."
        )
        details = {"previous_weights": self.previous_weights}
        return super()._get_error(name, description, details)
