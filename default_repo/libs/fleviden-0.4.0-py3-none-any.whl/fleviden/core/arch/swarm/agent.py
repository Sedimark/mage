# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

""" This module implements a swarm agent pod. Swarm learning is a protocol in which
several agents that have private data train a global model rotating the role of the
central server.
"""

import copy

from fleviden.core.arch.cen.client import Client
from fleviden.core.arch.cen.server import Server
from fleviden.core.flow.rotator import Rotator
from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Agent(Pod):
    """This class implements a swarm learning agent that can coordinate with other
    agents to train a global model in a federated learning fashion.

    The agents involved in the protocol assume a given index as their identities
    from zero to the number of agents. This index is used to take over the role of
    the central server in charge of aggregating the local models from the other
    agents.

    This initial class does not implement any complex protocol to determine which agent
    is in charge of acting as a server. Instead, the agent who acts as a server is
    selected in a round robin fashion based on its index.

    In addition, this class does not implement any failure resilient protocol. Hence,
    if an agent fails, the entire training pipeline fails as well.
    """

    def __init__(self, agent: str, num_rounds: int, agents: dict):
        """Creates a new swarm agent pod.

        Parameters
        ----------
            num_rounds : int
                Number of rounds.

            agents : dict
                Dictionary of swarm agents that will participate in the training process.

        Inputs
        ------
            Interfaces.UPDATE_SERVER (/update-server)
                A request to update the the server's model parameters.

            Interfaces.UPDATE_CLIENT (/update-client)
                A request to update the client's model parameters.

            Interfaces.BROADCAST (/broadcast)
                A request to broadcast the server's model parameters to all agents.

            Interfaces.AGGREGATE (/aggregate)
                A request to aggregate the model parameters.

            Interfaces.TRAIN (/train)
                A request to train the model parameters.

            Interfaces.FORWARD (/forward)
                A request to forward the model parameters to the next agent.

        Outputs
        -------
            Interfaces.BROADCASTED (/broadcasted)
                A notification that the model parameters have been broadcasted.

            Interfaces.FORWARDED (/forwarded)
                A notification that the model parameters have been forwarded to the next agent.

            Interfaces.TRAINED (/trained)
                A notification that the model has been trained.

            Interfaces.COMPLETED (/completed)
                A notification that the training process has been completed.
        """
        super().__init__()
        self.agents = agents
        self.num_agents = len(agents)
        self.server = Server(num_rounds=num_rounds, clients=agents)
        self.client = Client(client_id=agent, num_rounds=num_rounds)
        self.rotator = Rotator(self.num_agents)
        self._completed = False
        self._register_sender_pipe()
        self._register_server_pipe()
        self._register_client_pipe()

    def _register_sender_pipe(self):
        """This method registers the wires responsible for broadcasting the global weights
        to all agents when this agent acts as a server.
        """
        self.register(Interfaces.BROADCAST, self._broadcast)
        self.register(Interfaces.BROADCASTED)
        self.register(Interfaces.COMPLETE, self._complete)
        self.register(Interfaces.COMPLETED)

    def _register_server_pipe(self):
        """This method registers the wires responible for receiving the global model
        weights for all agents, aggregating them and forwarding the result to the next
        selected agent who will act as server in the next round.
        """
        self._register_aggregation_pipe()
        self._register_channel_pipe()

    def _register_client_pipe(self):
        """This method registers the wires responible for receiving the global model
        from the server, starting to train it and sending it back to the server.
        """
        self._register_pre_train()
        self._register_post_train()
        self.client.link(Interfaces.COMPLETED, self, Interfaces.COMPLETE)

    def _register_aggregation_pipe(self):
        self.register(Interfaces.UPDATE_SERVER)
        self.link(Interfaces.UPDATE_SERVER, self.server, Interfaces.UPDATE)
        self.server.link(Interfaces.UPDATED, self, Interfaces.AGGREGATE)
        self.register(Interfaces.AGGREGATE)

    def _register_channel_pipe(self):
        self.register(Interfaces.FORWARD, self._forward)
        self.register(Interfaces.FORWARDED)
        self.server.link(Interfaces.BROADCASTED, self, Interfaces.FORWARDED)

    def _register_pre_train(self):
        self.register(Interfaces.UPDATE_CLIENT)
        self.link(Interfaces.UPDATE_CLIENT, self.client, Interfaces.UPDATE)
        self.client.link(Interfaces.UPDATED, self, Interfaces.TRAIN)
        self.register(Interfaces.TRAIN)

    def _register_post_train(self):
        self.register(Interfaces.TRAINED)
        self.link(Interfaces.TRAINED, self.client, Interfaces.FORWARD)
        self.client.link(Interfaces.FORWARDED, self.rotator, Interfaces.SEND)
        for i in range(self.num_agents):
            self.rotator.link(f"/send-to-{i}", self, f"/send-to-{i}")
            self.register(f"/send-to-{i}")

    async def _forward(self, req):
        """This method triggers the self.server/broadcast wire. It is only triggered if
        the agent has not completed all its rounds.
        """
        if not self._completed:
            await self.server.trigger(Interfaces.BROADCAST, req)

    async def _broadcast(self, req):
        """This method ensures the /broadcasted wire is only triggered if the agent has
        not completed all its rounds.
        """
        if not self._completed:
            req['clients'] = list(self.agents.keys())
            await self.trigger(Interfaces.BROADCASTED, req)

    async def _complete(self, req):
        """This method triggers the /completed wire"""
        self._completed = True

        await self.trigger(Interfaces.COMPLETED, req)
