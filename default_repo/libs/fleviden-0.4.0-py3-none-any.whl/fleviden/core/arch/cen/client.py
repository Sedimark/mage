# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""This module implements a Federated Learning client-side functionality
corresponding to central server aggregation.

This implementation is based on the concept discussed in:Li L, Fan Y, Tse M, Lin KY.
A review of applications in federated learning. Computers & Industrial Engineering.
2020 Nov 1;149:106854.
"""

from typing import Optional

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod
from fleviden.core.validation.arch.cen.client_validation import ClientValidation as val


class Client(Pod):
    """A client-side implementation for federated learning central server aggregation."""

    def __init__(
        self, client_id: str, server_id: Optional[str] = None, num_rounds: Optional[int] = None
    ):
        """The constructor of the Client Pod.

        Parameters
        ----------
            client_id : str
                A client identity object. Must contain at least an id attribute
                that corresponds to a client identity.

            server_id : str
                A server identity object. Must contain at least an id attribute
                that corresponds to a server identity. If None, the client won't verify the origin
                of the server.

            num_rounds : int
                The number of rounds this client must serve. After receiving
                the specified number of rounds, the pod triggers a `/completed` interface
                indicating the end of the training process. Default None indicates an infinite
                number of rounds and hence the `/completed` interface is never triggered.

        Inputs
        ------
            Interfaces.UPDATE (/update)
                A request to update the global model parameters.

            Interfaces.FORWARD (/forward)
                A request to forward the global model parameters to the next client.

        Outputs
        -------
            Interfaces.UPDATED (/updated)
                A notification that the global model parameters have been updated.

            Interfaces.FORWARDED (/forwarded)
                A notification that the global model parameters have been forwarded to the next
                client.

            Interfaces.COMPLETED (/completed)
                A notification that the training process has been completed.
        """
        super().__init__()
        self.__check(server_id, num_rounds)
        self.__client_id = client_id
        self.__server_id = server_id
        self.__num_rounds = num_rounds
        self.__round = 0

        self.register(Interfaces.UPDATE, self.__update, schema=val.Update)
        self.register(Interfaces.UPDATED)
        self.register(Interfaces.FORWARD, self._forward)
        self.register(Interfaces.FORWARDED)
        self.register(Interfaces.SUBSCRIBE, self._subscribe)
        self.register(Interfaces.SUBSCRIBED)
        self.register(Interfaces.UNSUBSCRIBE, self._unsubscribe)
        self.register(Interfaces.UNSUBSCRIBED)
        self.register(Interfaces.COMPLETED)

    def __check(self, server_id: Optional[str] = None, num_rounds: Optional[int] = None) -> None:
        assert server_id is None or isinstance(server_id, str)
        if num_rounds is not None:
            assert isinstance(num_rounds, int) and num_rounds > 0

    def _should_complete(self) -> bool:
        return self.__num_rounds is not None

    def _is_completed(self) -> bool:
        if self._should_complete():
            return self.__round == 2 * self.__num_rounds
        return False

    async def _complete(self, _req: dict, info_msg: Optional[str] = "") -> None:
        """Completes the process, reseting the round count and
        triggering the /completed interface.

        Parameters
        ----------
            _req: dict
                The request message. (not used)
            info_msg: str
                An optional information message to be included in the /completed interface
        """
        self.__round = 0
        await self.trigger(
            Interfaces.COMPLETED,
            {"num_rounds": self.__num_rounds},
            info_msg=info_msg + " (completed)",
        )

    async def __update(self, req: dict) -> None:
        """Handles the incoming model parameters received from the specified server.

        Parameters
        ----------
            req: an object containing information on the client and the server global model
            parameters that are to be further optimized.
        """
        mode = self._get_mode(req)

        info_msg = f"Received {mode} from {req['origin']}..."
        if self.__server_id is None or req["origin"] == self.__server_id:
            self.__round += 1
            if self._is_completed():
                await self._complete(req, info_msg)
            else:
                # Active clients
                if self.__client_id in req['clients']:
                    await self.trigger(Interfaces.UPDATED, req, info_msg=info_msg)
                # Idle clients (forward round increase)
                else:
                    self.__round += 1
                    if self._is_completed():
                        await self._complete(req, info_msg)
        else:
            await self.trigger(
                Interfaces.ERROR, mandatory=False, req=self.__get_unregistered_error(req)
            )

    async def _forward(self, req: dict) -> None:
        mode = self._get_mode(req)
        if self.__server_id is not None:
            info_msg = f"Forwarding {mode} to {self.__server_id}..."
        else:
            info_msg = ""
        self.__round += 1
        req.pop('completed', None)
        await self.trigger(Interfaces.FORWARDED, req, info_msg=info_msg)
        if self._is_completed():
            await self._complete(req, info_msg)

    async def _subscribe(self, req):
        req['client'] = self.__client_id
        await self.trigger(Interfaces.SUBSCRIBED, req)

    async def _unsubscribe(self, req):
        req['client'] = self.__client_id
        await self.trigger(Interfaces.UNSUBSCRIBED, req)

    def _get_mode(self, req: dict) -> str:
        if "weights" in req:
            return "weights"
        elif "gradients" in req:
            return "gradients"
        return ""

    def __get_unregistered_error(self, req: dict) -> dict:
        name = "UnregisteredServer"
        description = (
            " A weight vector from a server {req.origin.id} was received and this is unexpected."
            "Check the server origin."
        )
        details = {"server": self.__server_id, "req": req}
        return super()._get_error(name, description, details)
