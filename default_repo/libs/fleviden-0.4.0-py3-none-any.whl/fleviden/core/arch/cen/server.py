# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

""" This module implements a Federated Learning server-side functionality
corresponding to central server aggregation.
"""
# This implementation is based on the concept discussed in: Li L, Fan Y, Tse M, Lin KY.
# A review of applications in federated learning. Computers & Industrial Engineering.
# 2020 Nov 1;149:106854.

import copy
from typing import Optional

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod
from fleviden.core.validation.arch.cen.server_validation import ServerValidation as val


class Server(Pod):
    """A server-side implementation for Federated Learning central server aggregation.
    The server pod main functionality is to control the Federated Learning rounds in the
    sense that only the specified agents are allowed to send model updates and that each
    client only sends a single model update per round.
    """

    def __init__(
        self, num_rounds: int, min_clients: Optional[int] = 2, clients: Optional[dict] = {}
    ):
        """Creates a Server pod given a set of clients pods identities and initial weights.

        Parameters
        ----------
            num_rounds : int
                The number of federated learning rounds.

            min_clients : int
                Minimum number of clients required to trigger the process.

            clients : dict, optional
                A dictionary representing the federated learning clients.
                The keys of the dictionary are the client ID and every entry
                is a dictionary containing client information.

        Inputs
        ------
            Interfaces.UPDATE (/update)
                A request to update the global model parameters.

            Interfaces.BROADCAST (/broadcast)
                A request to broadcast the global model parameters to all clients.

            Interfaces.SUBSCRIBE (/subscribe)
                A request to subscribe a client to the federated learning process.

            Interfaces.UNSUBSCRIBE (/unsubscribe)
                A request to unsubscribe a client from the federated learning process.

            Interfaces.UPDATE_NUM_CLIENTS (/update-num-clients)
                A request to update the number of clients that are active in a round.

        Outputs
        -------
            Interfaces.UPDATED (/updated)
                A notification that the global model parameters have been updated.

            Interfaces.BROADCASTED (/broadcasted)
                A notification that the global model parameters have been broadcasted.

            Interfaces.SUBSCRIBED (/subscribed)
                A notification that a client has been subscribed.

            Interfaces.UNSUBSCRIBED (/unsubscribed)
                A notification that a client has been unsubscribed.

            Interfaces.UNSUBSCRIBED_ALL (/unsubscribed-all)
                A notification that all the clients have unsubscribed.

            Interfaces.UPDATED_NUM_CLIENTS (/updated-num-clients)
                A notification that the number of active clients has been updated.

            Interfaces.START_TRAINING (/start-training)
                A notification that enough clients have subscribed and the server is ready to start
                the training.

            Interfaces.STOP_TRAINING (/stop-training)
                A notification that the training process has been completed.
        """
        super().__init__()
        self.__fired = False
        self.__round = 0
        self.__num_rounds = num_rounds
        self.__min_clients = min_clients
        self.clients = clients
        self.num_active_clients = len(clients)
        self.updates = []
        self.subscribe = []
        self.unsubscribe = []

        self.register(Interfaces.UPDATE, self._update, schema=val.Update)
        self.register(Interfaces.UPDATED)

        self.register(Interfaces.BROADCAST, self._broadcast)
        self.register(Interfaces.BROADCASTED)

        self.register(Interfaces.SUBSCRIBE, self._subscribe)
        self.register(Interfaces.SUBSCRIBED)

        self.register(Interfaces.UNSUBSCRIBE, self._unsubscribe)
        self.register(Interfaces.UNSUBSCRIBED)

        self.register(Interfaces.START_TRAINING)
        self.register(Interfaces.STOP_TRAINING)

        self.register(Interfaces.UPDATE_CLIENTS, self._update_subscribed_clients)
        self.register(Interfaces.UPDATED_CLIENTS)

        self.register(Interfaces.UPDATE_NUM_CLIENTS, self._update_num_clients)
        self.register(Interfaces.UPDATED_NUM_CLIENTS)

        self.register(Interfaces.UNSUBSCRIBED_ALL)

    def _should_complete(self) -> bool:
        return self.__num_rounds is not None

    def _is_completed(self) -> bool:
        if self._should_complete():
            return self.__round == 2 * self.__num_rounds
        return False

    async def _update(self, req: dict) -> None:
        """Receives weights from client.

        Checks that the origin of the weights is registered in
        the list of clients.

        Checks that a given client do not send
        weights more than once in a single federated round.
        """
        mode = self._get_mode(req)

        client = req.get('client', req.get('origin', req.get('id')))
        info_msg = f"Received {mode} from {client}..."
        if client in self.updates:
            error = self._get_duplicated_error(client)
            return await self.trigger(Interfaces.ERROR, error)
        if client not in self.clients:
            error = self._get_unregistered_error()
            return await self.trigger(Interfaces.ERROR, error)
        self.updates.append(client)
        info_updates_clients = f" {len(self.updates)}/{self.num_active_clients} clients"
        req["num_clients"] = self.num_active_clients
        if len(self.updates) == self.num_active_clients:
            self.updates.clear()
            self.__round = self.__round + 1
            if self._is_completed():
                self.__round = 0
                req['clients'] = copy.deepcopy(self.clients)
                req['completed'] = True
                await self.trigger(
                    Interfaces.STOP_TRAINING, req, info_msg=info_msg + info_updates_clients
                )
            else:
                await self.trigger(
                    Interfaces.UPDATED, req, info_msg=info_msg + info_updates_clients
                )
        else:
            await self.trigger(Interfaces.UPDATED, req, info_msg=info_msg + info_updates_clients)

    async def _broadcast(self, req: dict) -> None:
        """Broadcasts weigths.

        It allows to broadcast the weights only for a maximum
        number of federated rounds. The maximum number of rounds
        is provided in the constructor.
        """
        mode = self._get_mode(req)

        info_msg = f"Broadcasting {mode}{' to ' + req['origin'] if 'origin' in req else ''}..."

        await self._update_subscribed_clients({})
        req['clients'] = list(self.clients.keys())
        self.__round = self.__round + 1
        if self._is_completed():
            self.__round = 0
            req['completed'] = True
            await self.trigger(Interfaces.STOP_TRAINING, req, info_msg=info_msg)
        else:
            await self.trigger(Interfaces.BROADCASTED, req)

    async def _subscribe(self, req):
        """Receives subscription from client.

        It processes subscriptions from clients. If the client has not
        subscribed yet, it adds the client to the list of subscribed
        clients. Else, it triggers an error.
        """
        client = req.get('client', req.get('origin', req.get('id')))
        if client not in self.clients:
            if client not in self.subscribe:
                self.subscribe.append(client)
            if client in self.unsubscribe:
                self.unsubscribe.remove(client)
        else:
            error = self._get_subscription_error(client)
            return await self.trigger(Interfaces.ERROR, error)
        info_msg = f"Subscribed {client}."
        await self.trigger(Interfaces.SUBSCRIBED, req, info_msg=info_msg)
        if len(self.subscribe) >= self.__min_clients and not self.__fired:
            self.__fired = True
            await self.trigger(Interfaces.START_TRAINING, req)

    async def _unsubscribe(self, req):
        """Receives unsubscription from client.

        It processes unsubscriptions from clients. If the client was
        not subscribed, it triggers an error. Else, it adds the client
        to the list of clients to be unsubscribed after the federated
        learning round ends.
        """
        client = req.get('client', req.get('origin', req.get('id')))
        if client in self.clients:
            if client not in self.unsubscribe:
                self.unsubscribe.append(client)
            if client in self.subscribe:
                self.subscribe.remove(client)
        else:
            error = self._get_unsubscribed_error(client)
            return await self.trigger(Interfaces.ERROR, error)
        info_msg = f"Unubscribed {client}."
        await self.trigger(Interfaces.UNSUBSCRIBED, req, info_msg=info_msg)

        if self._all_clients_unsubscribe(self.clients.keys(), self.unsubscribe):
            info_msg = "All clients have unsubscribed"
            await self.trigger(Interfaces.UNSUBSCRIBED_ALL, {}, info_msg=info_msg)

    async def _update_subscribed_clients(self, _req: dict) -> None:
        """Updates the list of subscribed clients after the requests for
        subscriptions and unsubscriptions have been processed.
        """
        for client in self.subscribe:
            self.clients[client] = {}
        self.subscribe.clear()

        for client in self.unsubscribe:
            self.clients.pop(client)
        self.unsubscribe.clear()

        await self.trigger(Interfaces.UPDATED_CLIENTS, {"clients": self.clients})
        await self._update_num_clients({})

    async def _update_num_clients(self, req):
        """Updates the number of clients that are active in a round."""
        self.num_active_clients = len(req.get('clients', self.clients))
        await self.trigger(Interfaces.UPDATED_NUM_CLIENTS, req)

    def _all_clients_unsubscribe(self, clients: [], unsubscribe: []) -> bool:
        "Check if the clients to be unsubscribed are exactly the same as the subscribed clients."
        if len(clients) != len(unsubscribe):
            return False
        return sorted(clients) == sorted(unsubscribe)

    def _get_mode(self, req: dict) -> str:
        if "weights" in req:
            return "weights"
        elif "gradients" in req:
            return "gradients"
        return ""

    def _get_unregistered_error(self) -> dict:
        name = "UnregisteredClient"
        description = (
            "A weight vector from a client was received and this is unexpected. Check the list of"
            " expected clients."
        )
        details = {"clients": self.clients}
        return super()._get_error(name, description, details)

    def _get_duplicated_error(self, origin) -> dict:
        name = "DuplicatedWeights"
        description = (
            "A weight vector from a client was received twice. Check the list of expected clients."
        )
        details = {"origin": origin, "clients": self.clients}
        return super()._get_error(name, description, details)

    def _get_unsubscribed_error(self, origin):
        name = "UnsubscribeError"
        description = "An unsubscribe request was received from a client that is not subscribed."
        details = {"origin": origin, "clients": self.clients}
        return super()._get_error(name, description, details)

    def _get_subscription_error(self, origin):
        name = "SubscribeError"
        description = (
            "A subscription request was received from a client that is already subscribed."
        )
        details = {"origin": origin, "clients": self.clients}
        return super()._get_error(name, description, details)
