# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a custom model trainer.
"""
from typing import Optional

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class CustomTrainer(Pod):
    """
    A CustomTrainer pod executes a custom Machine Learning pipeline defined by the user.

    Basic example:

    Creating a CustomTrainer pod.
        >>> def load_fn():
        >>>     # Model loading code
        >>> def train_fn():
        >>>     # Model training code
        >>> def evaluate_fn():
        >>>     # Model evaluation code
        >>> def predict_fn():
        >>>     # Model prediction code
        >>> custom_trainer_pod = CustomTrainer(filepath='model', epochs=10, batch_size=32,
        >>>                                    load_fn=load_fn, train_fn=train_fn,
        >>>                                    evaluate_fn=evaluate_fn, predict_fn=predict_fn)
    Loading model.
        >>> req = {'filepath': 'alt_model} # Use this req to load a different model.
        >>> custom_trainer_pod.trigger(Interfaces.LOAD_MODEL, req)
    Setting the req parameter for training and evaluating a model:
        >>> features = numpy.random.rand(100, 10)
        >>> targets = numpy.random.randint(2, 1000)
        >>> weights = numpy.random.rand(2850)
        >>> req = {'features': features, 'targets': targets, 'weights': weights}
    Training model.
        >>> custom_trainer_pod.trigger(Interfaces.TRAIN, req)
    Evaluating model.
        >>> custom_trainer_pod.trigger(Interfaces.EVALUATE, req)
    """

    def __init__(
        self,
        load_fn: Optional[callable] = None,
        train_fn: Optional[callable] = None,
        evaluate_fn: Optional[callable] = None,
        predict_fn: Optional[callable] = None,
        save_fn: Optional[callable] = None,
    ):
        """
        Creates a CustomTrainer pod.

        Parameters
        ----------
            load_fn: callable
                Function to be executed when triggering the /load-model wire.

            train_fn: callable
                Function to be executed when triggering the /train wire.

            evaluate_fn: callable
                Function to be executed when triggering the /evaluate wire.

            predict_fn: callable
                Function to be executed when triggering the /predict wire.

            save_fn: callable
                Function to be executed when triggering the /save-model wire.

        Inputs
        ------
            Interfaces.LOAD_MODEL (/load-model)
                Loads the weights from a model.

            Interfaces.TRAIN (/train)
                Trains an existing model from a given set of weights, features, and targets.

            Interfaces.EVALUATE (/evaluate)
                Evaluates an existing model from a given set of weights, features, and targets.

            Interfaces.PREDICT (/predict)
                Predicts a batch of examples using a model.

            Interfaces.SAVE_MODEL (/save-model)
                Saves the model.

        Outputs
        -------
            Interfaces.LOADED_MODEL (/loaded-model)
                Triggered when the model is loaded.

            Interfaces.INITIALIZED_MODEL (/initialized-model)
                Triggered when the model is initialized.

            Interfaces.TRAINED (/trained)
                Triggered when the model is trained.

            Interfaces.EVALUATED (/evaluated)
                Triggered when the model is evaluated.

            Interfaces.SAVED_MODEL (/saved-model)
                Triggered when the model is saved.

            Interfaces.COMPLETED (/completed)
                Triggered when the model is evaluated and the evaluation is completed.

            Interfaces.PREDICTED (/predicted)
                Triggered when the model predicts a batch of examples.
        """
        super().__init__()
        self.load_fn = load_fn
        self.train_fn = train_fn
        self.evaluate_fn = evaluate_fn
        self.predict_fn = predict_fn
        self.save_fn = save_fn

        self.register(Interfaces.LOAD_MODEL, self._load)
        self.register(Interfaces.LOADED_MODEL)

        self.register(Interfaces.INITIALIZED_MODEL)

        self.register(Interfaces.TRAIN, self._train)
        self.register(Interfaces.TRAINED)

        self.register(Interfaces.EVALUATE, self._evaluate)
        self.register(Interfaces.EVALUATED)
        self.register(Interfaces.COMPLETED)

        self.register(Interfaces.PREDICT, self._predict)
        self.register(Interfaces.PREDICTED)

        self.register(Interfaces.SAVE_MODEL, self._save_model)
        self.register(Interfaces.SAVED_MODEL)

    async def _load(self, req: dict) -> None:
        """
        Executes the function to load a model.

        Parameters
        ----------
            req : dict
                Request dictionary.
        """
        res = self.load_fn(req) if self.load_fn is not None else {}

        if not isinstance(res, dict):
            await self.trigger(
                Interfaces.ERROR,
                super()._get_error(
                    "LoadOutputTypeError",
                    "An error occurred when loading the model",
                    ValueError("The output of the load function must be a dictionary."),
                ),
            )
            return

        error = res.get('error', None)
        if error is not None:
            await self.trigger(Interfaces.ERROR, error)
        else:
            await self.trigger(Interfaces.LOADED_MODEL, res)
            if res.get('initialized', False):
                await self.trigger(Interfaces.INITIALIZED_MODEL, res, info_msg="Model initialized")

    async def _train(self, req: dict) -> None:
        """
        Executes the function to train a model.

        Parameters
        ----------
            req : dict
                Request dictionary.
        """
        res = self.train_fn(req) if self.train_fn is not None else {}

        if not isinstance(res, dict):
            await self.trigger(
                Interfaces.ERROR,
                super()._get_error(
                    "TrainOutputTypeError",
                    "An error occurred when training the model",
                    ValueError("The output of the train function must be a dictionary."),
                ),
            )
            return

        error = res.get('error', None)
        if error is not None:
            await self.trigger(Interfaces.ERROR, error)
        else:
            await self.trigger(Interfaces.TRAINED, res, info_msg="Training completed")

    async def _evaluate(self, req: dict) -> None:
        """
        Executes the function to evaluate a model.

        Parameters
        ----------
            req : dict
                Request dictionary.
        """
        res = self.evaluate_fn(req) if self.evaluate_fn is not None else {}

        if not isinstance(res, dict):
            await self.trigger(
                Interfaces.ERROR,
                super()._get_error(
                    "EvaluateOutputTypeError",
                    "An error occurred when evaluating the model",
                    ValueError("The output of the evaluate function must be a dictionary."),
                ),
            )
            return

        error = res.get('error', None)
        if error is not None:
            await self.trigger(Interfaces.ERROR, error)
        else:
            await self.trigger(Interfaces.EVALUATED, res, info_msg="Evaluation completed")
            completed = req.get('completed', False)
            if completed:
                await self.trigger(Interfaces.COMPLETED, res, info_msg="Evaluation completed")

    async def _predict(self, req: dict) -> None:
        """
        Executes the function to predict a batch of examples.

        Parameters
        ----------
            req : dict
                Request dictionary.
        """
        res = self.predict_fn(req) if self.predict_fn is not None else {}

        if not isinstance(res, dict):
            await self.trigger(
                Interfaces.ERROR,
                super()._get_error(
                    "PredictOutputTypeError",
                    "An error occurred when predicting with the model",
                    ValueError("The output of the predict function must be a dictionary."),
                ),
            )
            return

        error = res.get('error', None)
        if error is not None:
            await self.trigger(Interfaces.ERROR, error)
        else:
            await self.trigger(Interfaces.PREDICTED, res, info_msg="Prediction completed")

    async def _save_model(self, req: dict) -> None:
        """
        Executes the function to save the model.

        Parameters
        ----------
            req : dict
                Request dictionary.
        """
        res = self.save_fn(req) if self.save_fn is not None else {}

        if not isinstance(res, dict):
            await self.trigger(
                Interfaces.ERROR,
                super()._get_error(
                    "CustomTrainerSaveModelOutputTypeError",
                    "An error occurred when saving the model",
                    ValueError("The output of the save function must be a dictionary."),
                ),
            )
            return

        error = res.get('error', None)
        if error is not None:
            await self.trigger(Interfaces.ERROR, error)
        else:
            await self.trigger(Interfaces.SAVED_MODEL, res, info_msg="Saved model.")
