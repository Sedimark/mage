# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a model trainer based on the Scikit-Learn framework.
"""
import pickle
from typing import Optional

import numpy as np
from sklearn.linear_model import LinearRegression, Ridge, RidgeCV, SGDRegressor
from sklearn.metrics import get_scorer
from sklearn.neural_network import MLPClassifier, MLPRegressor

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod
from fleviden.core.validation.trainers.sklearn_validation import ScikitLearnValidation as val


class ScikitLearn(Pod):
    """
    A Scikit-Learn pod gives support to MLP (Regressor and Classifier) and
    regression (LinearRegression, Ridge, RidgeCV, SGDRegressor) models.

    The models are saved with the pickle library via pickle.dump(model, filepath).
        >>> pickle.dump(model, "model.pkl") # creates a pickle archive "model.pkl"

    Basic example:

    Creating a Scikit-Learn pod.
        >>> sklearn_pod = ScikitLearn(load_model_filepath='model.pkl', epochs=10, batch_size=32)
    Loading a model.
        >>> req = {"filepath": 'alt_model.pkl'} # Use this req load a different model.
        >>> sklearn_pod.trigger(Interfaces.LOAD_MODEL, req)
    Setting the req parameter for training and evaluating a model.
        >>> features = np.random.rand(1000,10)
        >>> targets = np.random.choice(2,1000)
        >>> weights = np.random.rand(2850)
        >>> req = {"features": features, "targets": targets, "weights": weights}
    Training a model.
        >>> sklearn_pod.trigger(Interfaces.TRAIN, req)
    Evaluating a model.
        >>> sklearn_pod.trigger(Interfaces.EVALUATE, req)

    """

    def __init__(
        self,
        load_model_filepath: str,
        epochs: Optional[int] = None,
        batch_size: Optional[int] = None,
        learning_rate_init: float = 0.001,
        metrics: list = [],
        send_gradients: bool = True,
        save_model_filepath: str = "model.pkl",
    ) -> None:
        """
        Creates a Scikit-Learn pod.

        Parameters
        ----------
            load_model_filepath: str
                Path to the saved model.

            batch_size: int
                Number of samples per gradient update.
                Only used for sklearn.neural_network models.

            epochs: int
                Number of epochs to train the model.
                Only used for sklearn.neural_network models.

            learning_rate_init: float
                The initial learning rate used to train the model.
                Only used for sklearn.neural_network models.

            metrics: list.
                Names of the metrics to be computed during evaluation.
                They must be implemented as a class or function in the
                sklearn.metrics mmodule.
                For example: ["accuracy", "neg_mean_absolute_error"].

            send_gradients: bool, optional
                If True, the gradients are sent after training. If False, the
                weights are sent instead. Default is True. Gradients are generated
                as the difference between the weights before and after a training round.

            save_model_filepath: str, optional
                Path to save the model when triggering the /save-model interface.
                Default is "model.pkl".

        Inputs
        ------
            Interfaces.LOAD_MODEL (/load-model)
                A request to load the model from the file.

            Interfaces.TRAIN (/train)
                A request to train the model with the given features and targets.

            Interfaces.EVALUATE (/evaluate)
                A request to evaluate the model with the given features and targets.

            Interfaces.UPDATE_WEIGHTS (/update-weights)
                Updates the weights of the model.

            Interfaces.SAVE_MODEL (/save-model)
                Saves the model to a file.

        Outputs
        -------
            Interfaces.LOADED_MODEL (/loaded-model)
                A trigger that sends the loaded model weights.

            Interfaces.TRAINED (/trained)
                A trigger that sends the trained model weights.

            Interfaces.EVALUATED (/evaluated)
                A trigger that sends the evaluation metrics.

            Interfaces.UPDATED_WEIGHTS (/updated-weights)
                Triggered when the model weights are updated.

            Interfaces.COMPLETED (/completed)
                A trigger that sends the evaluation metrics and indicates the end of the evaluation
                process.

            Interfaces.SAVED_MODEL (/saved-model)
                A trigger that indicates the model has been saved.
        """
        super().__init__()
        self.load_model_filepath = load_model_filepath
        self.model = None
        self.epochs = epochs
        self.batch_size = batch_size
        self.learning_rate_init = learning_rate_init
        self.metrics = metrics
        self.send_gradients = send_gradients
        self.save_model_filepath = save_model_filepath

        self.is_initialized = False
        self.is_loaded = False

        self.weights = []

        self.supported_mlp = [MLPRegressor, MLPClassifier]
        self.supported_regression = [LinearRegression, Ridge, RidgeCV, SGDRegressor]

        self.register(Interfaces.LOAD_MODEL, self._load, schema=val.Load)
        self.register(Interfaces.LOADED_MODEL)
        self.register(Interfaces.INITIALIZED_MODEL)

        self.register(Interfaces.TRAIN, self._train, schema=val.Train)
        self.register(Interfaces.TRAINED)

        self.register(Interfaces.EVALUATE, self._evaluate, schema=val.Evaluate)
        self.register(Interfaces.EVALUATED)

        self.register(Interfaces.COMPLETED)

        self.register(
            Interfaces.UPDATE_WEIGHTS, self.__update_weights_handler, schema=val.UpdateWeights
        )
        self.register(Interfaces.UPDATED_WEIGHTS)

        self.register(Interfaces.SAVE_MODEL, self._save_model, schema=val.SaveModel)
        self.register(Interfaces.SAVED_MODEL)

    async def _load(self, req: dict) -> None:
        """
        Loads a Scikit-Learn model from a given filepath via pickle
        """
        # 1. Load from file
        if not self.is_loaded:
            await self._load_model(req)

        # (/initialized-model trigger)
        if self.is_loaded and not self.is_initialized:
            await self.trigger(
                Interfaces.INITIALIZED_MODEL,
                {"weights": self.weights},
                info_msg="Model initialized.",
            )
            self.is_initialized = True

        # 2. Overwrite the model weights if updated weights are provided
        self._update_weights(req)

    async def _save_model(self, req: dict) -> None:
        """Saves the model in a model.pkl file.

        Parameters
        ----------
            req : dict
                Request dictionary.
        """
        filepath = req.get('filepath', self.save_model_filepath)
        try:
            if filepath is not None and self.model is not None:
                if not filepath.endswith(".pkl"):
                    filepath += ".pkl"
                with open(filepath, 'wb') as f:
                    pickle.dump(self.model, f)

                await self.trigger(
                    Interfaces.SAVED_MODEL,
                    {"filepath": filepath},
                    info_msg=f"Model saved at {filepath}",
                )
            else:
                error = super()._get_error(
                    "Scikit-LearnModelSavingError", "No filepath provided to save the model", req
                )
                await self.trigger(Interfaces.ERROR, error)
        except (ValueError, OSError) as error:
            error = super()._get_error(
                "Scikit-LearnModelSavingError",
                "An error occurred when saving the model",
                str(error),
            )
            await self.trigger(Interfaces.ERROR, error)

    async def _train(self, req: dict) -> None:
        """
        Trains an existing Scikit-Learn model from a given set of weights,
        features, and targets. The set of weights is a linear list of floats.
        The features and targets can be either lists or numpy arrays.

        Optionally, the number of epochs and batch size can be provided for
        MLP models. If either the number of epochs or the batch size is not
        provided, it defaults to the values specified in the constructor.

        After training, the function calculates the gradients by subtracting the updated weights
        from the reference weights. It then triggers the "/trained" event
        with the gradients (send_gradients=True) or the updated weights (send_gradients=False).
        """
        await self._load(req)
        if self.is_loaded:
            if type(self.model) in self.supported_mlp:
                self._train_mlp(req)
            else:
                self._train_regression(req)

            if self.send_gradients:
                gradients = (np.array(self.weights) - self._get_weights()).tolist()
                await self.trigger(
                    Interfaces.TRAINED, {"gradients": gradients}, info_msg="Training completed."
                )
            else:
                await self.trigger(
                    Interfaces.TRAINED,
                    {"weights": self._get_weights()},
                    info_msg="Training completed.",
                )

    def _train_mlp(self, req: dict) -> None:
        """
        Trains an existing Scikit-Learn MLP model from a given set of
        weights, features, and targets.
        """
        features, targets, epochs, batch_size, _ = self._get_params(req)
        _, num_labels = targets.shape
        targets = targets.ravel() if num_labels == 1 else targets
        learning_rate_init = req.get("learning_rate_init", self.learning_rate_init)
        params = {
            'batch_size': batch_size,
            'max_iter': epochs,
            'verbose': 0,
            'learning_rate_init': learning_rate_init,
        }
        self.model.set_params(**params)
        self.model.fit(features, targets)

    def _train_regression(self, req: dict) -> None:
        """
        Trains an existing Scikit-Learn regression model from a given set of
        weights, features, and targets.
        """
        features, targets, _, _, _ = self._get_params(req)
        _, num_labels = targets.shape
        targets = targets.ravel() if num_labels == 1 else targets
        self.model.fit(features, targets)

    async def _evaluate(self, req: dict) -> None:
        """
        Evaluates an existing Scikit-Learn model from a given set of weights,
        features, and targets. The set of weights is a linear list of floats.
        The features and targets can be either lists or numpy arrays.
        """
        await self._load(req)
        features, targets, _, _, _ = self._get_params(req)
        if self.is_loaded:
            _, num_labels = targets.shape
            targets = targets.ravel() if num_labels == 1 else targets
            evaluators = [get_scorer(metric) for metric in self.metrics]
            result = [evaluator(self.model, features, targets) for evaluator in evaluators]
            metrics = dict(zip(self.metrics, result))
            await self.trigger(Interfaces.EVALUATED, metrics, info_msg="Model evaluated")
            completed = req.get('completed', False)
            if completed:
                await self.trigger(Interfaces.COMPLETED, metrics, info_msg="Evaluation completed")

    async def _load_model(self, req: dict) -> None:
        """
        Loads a Scikit-Learn model from a given filepath.
        If the filepath is not provided, it defaults to its
        specified value in the constructor.
        """
        filepath = req.get('filepath', self.load_model_filepath)
        try:
            with open(filepath, 'rb') as f:
                self.model = pickle.load(f)
                supported = self.supported_mlp + self.supported_regression
                if type(self.model) not in supported:
                    error = super()._get_error(
                        "Scikit-LearnModelLoadingError",
                        "Invalid model type",
                        {"model_type": type(self.model), "supported_models": supported},
                    )
                    await self.trigger(Interfaces.ERROR, error)
                else:
                    self.metrics = await self._filter_valid_metrics(self.metrics)
                    weights = self._get_weights()
                    self.weights = weights
                    self.is_loaded = True
                    await self.trigger(
                        Interfaces.LOADED_MODEL,
                        {"weights": weights},
                        info_msg=f"Model loaded from {filepath}.",
                    )
        except (ValueError, OSError) as error:
            error = super()._get_error(
                "Scikit-LearnModelLoadingError",
                "An error occurred when loading the model",
                str(error),
            )
            await self.trigger(Interfaces.ERROR, error)

    def _get_params(self, req: dict) -> tuple:
        """
        Retrieve the training parameters from the
        request dictionary.
        """
        features = np.array(req.get('features', None))
        targets = np.array(req.get('targets', None))
        epochs = req.get('epochs', self.epochs)
        batch_size = req.get('batch_size', self.batch_size)
        identifiers = req.get('identifiers', None)

        return features, targets, epochs, batch_size, identifiers

    def _update_weights(self, req: dict) -> None:
        """
        Updates the model with the received gradients/weights.
        """
        gradients = req.pop('gradients', None)
        if gradients is not None:
            weights = self._restore_weights(gradients)
            self._set_weights(weights)
        else:
            weights = req.pop('weights', None)
            if weights is not None:
                self._set_weights(weights)

        # Update reference model weights
        if weights is not None:
            self.weights = weights

    async def __update_weights_handler(self, req: dict) -> None:
        """Updates the weights of the model and triggers the
        output interfaces."""

        if "gradients" not in req and "weights" not in req:
            await self.trigger(
                Interfaces.ERROR,
                super()._get_error(
                    "NoWeights", "No weights or gradients provided in the request.", req
                ),
            )
        else:
            self._update_weights(req)

            if self.weights is not None:
                await self.trigger(
                    Interfaces.UPDATED_WEIGHTS,
                    {"weights": self.weights, **req},
                    info_msg="Weights updated at trainer pod",
                )

    def _restore_weights(self, gradients: list) -> list:
        """Restore the weights using the updated gradients.

        Parameters
        ----------
            gradients : list
                Updated gradients.

        Returns
        -------
            list
                Restored weights.
        """
        return (np.array(self.weights) - np.array(gradients)).tolist()

    def _get_weights(self) -> list:
        """
        Given a Scikit-Learn model, obtain the model parameters in a
        linearized one-dimensional list.
        """
        if type(self.model) in self.supported_mlp:
            weights = self._get_weights_mlp()
        else:
            weights = self._get_weights_regression()
        return weights

    def _get_weights_mlp(self) -> list:
        """
        Given a Scikit-Learn MLP model, obtain the model parameters in a
        linearized one-dimensional list.
        """
        return np.concatenate([coef.flatten() for coef in self.model.coefs_]).tolist()

    def _get_weights_regression(self) -> list:
        """
        Given a Scikit-Learn regression model, obtain the model parameters in a
        linearized one-dimensional list.
        """
        return np.concatenate([coef.flatten() for coef in self.model.coef_]).tolist()

    def _set_weights(self, weights: list) -> None:
        """
        Given a Scikit-Learn model and a linearized list of floats, sets
        the model parameters from the given list of floats.
        """
        if type(self.model) in self.supported_mlp:
            self._set_weights_mlp(weights)
        else:
            self._set_weights_regression(weights)

    def _set_weights_mlp(self, weights: list) -> None:
        """
        Given a Scikit-Learn MLP model and a linearized list of floats, sets
        the model parameters from the given list of floats.
        """
        count_params = len(np.concatenate([coef.flatten() for coef in self.model.coefs_]))
        if count_params == len(weights):
            pad = 0
            for i, layer in enumerate(self.model.coefs_):
                to_be_set = []
                for params in layer:
                    size = len(params.reshape(-1))
                    section = np.array(weights[pad : pad + size])
                    to_be_set.append(section.reshape(params.shape))
                    pad += size
                self.model.coefs_[i] = np.asarray(to_be_set)

    def _set_weights_regression(self, weights: list) -> None:
        """
        Given a Scikit-Learn regression  model and a linearized list of floats,
        sets the model parameters from the given list of floats.
        """
        count_params = len(np.concatenate([coef.flatten() for coef in self.model.coef_]))
        if count_params == len(weights):
            pad = 0
            for i, layer in enumerate(self.model.coef_):
                size = len(layer.reshape(-1))
                if size == 1:
                    self.model.coef_[i] = np.array(weights[pad : pad + size])[0]
                else:
                    self.model.coef_[i] = np.array(weights[pad : pad + size])
                pad += size

    async def _filter_valid_metrics(self, metrics: list) -> list:
        """
        Deletes out metrics specified in the pod constructor
        that are not implemented in the sklearn.metrics module
        and triggers a warning.

        Parameters
        ----------
            metrics: list.
                Names of the metrics to be computed during evaluation.
        Returns
        --------
            valid_metrics: list.
                Pod metrics that are implemented in the sklearn.metrics
                module.

        Triggers
        --------
            Interfaces.WARNING (/warning): if the metric is not valid.

        """
        valid_metrics = []

        for metric in metrics:
            try:
                get_scorer(metric)
                valid_metrics.append(metric)
            except ValueError:
                warning = super()._get_warning(
                    "Scikit-LearnInvalidMetricWarning",
                    "Metric is not available in sklearn.metrics",
                    {'invalid_metric': metric},
                )
                await self.trigger(Interfaces.WARNING, warning)

        if not valid_metrics:
            warning = super()._get_warning(
                "Scikit-LearnUndefinedMetricsWarning",
                "No valid metric has been provided",
                {'provided_metrics': metrics},
            )
            await self.trigger(Interfaces.WARNING, warning)

        return valid_metrics
