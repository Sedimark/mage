# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a model trainer based on the Keras framework.
"""
from typing import Optional

import numpy as np
from tensorflow import keras

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod
from fleviden.core.validation.trainers.keras_validation import KerasValidation as val


class Keras(Pod):
    """
    A Keras pod trains a model saved via `model.save()`.

    The suggested format is "Keras v3" format, which uses the .keras extension.
        >>> model.save("model.keras") # creates a zip archive "model.keras".

    Basic example:

    Creating a Keras pod.
        >>> keras_pod = Keras(load_model_filepath='model.keras', epochs=10, batch_size=32)
    Loading a model.
        >>> req = {"filepath": 'alt_model.keras'} # Use this req load a different model.
        >>> keras_pod.trigger(Interfaces.LOAD_MODEL, req)
    Setting the req parameter for training and evaluating a model:
        >>> features = np.random.rand(1000,10)
        >>> targets = np.random.choice(2,1000)
        >>> weights = np.random.rand(2850)
        >>> req = {"features": features, "targets": targets, "weights": weights}
    Training a model.
        >>> keras_pod.trigger(Interfaces.TRAIN, req)
    Evaluating a model.
        >>> keras_pod.trigger(Interfaces.EVALUATE, req)
    """

    def __init__(
        self,
        load_model_filepath: str,
        load_weights_filepath: str = "weights.h5",
        epochs: Optional[int] = None,
        batch_size: Optional[int] = None,
        initializer: Optional[str] = None,
        metrics: list = [],
        send_gradients: bool = True,
        save_model_filepath: str = "model.keras",
        save_weights_filepath: str = "weights.h5",
    ):
        """
        Creates a Keras pod.

        Parameters
        ----------
            load_model_filepath: str
                Path to the load the model from, in .keras extension.

            load_weights_filepath: str, optional
                Path to load the model weights from, in .h5 extension.

            batch_size: int
                Number of samples per gradient update.

            epochs: int
                Number of epochs to train the model.

            initializer: str
                Keras weight initializer. Default value None
                means that no model weights initialization is performed.

            metrics: list.
                Names of the metrics to be computed during evaluation. They
                must be implemented as a class or function in the keras.metrics
                module. For example: ["accuracy", "mse"]. Some names are case
                sensitive, e.g., "Precision" is ok, but not "precision".

            send_gradients: bool, optional
                If True, the gradients are sent after training. If False, the
                weights are sent instead. Default is True. Gradients are generated
                as the difference between the weights before and after a training round.

            save_model_filepath: str, optional
                Path to save the model when triggering the /save-model interface.
                Default is "model.keras".

            save_weights_filepath: str, optional
                Path to save the model weights when triggering the /save-weights interface.
                Default is "weights.h5".

        Inputs
        ------
            Interfaces.LOAD_MODEL (/load-model)
                Loads a Keras model from a given filepath and optionally initializes the model
                weights.

            Interfaces.LOAD_WEIGHTS (/load-weights)
                Loads the model weights from a weights file in extension .h5.

            Interfaces.TRAIN (/train)
                Trains an existing Keras model from a given set of weights, features, and targets.

            Interfaces.EVALUATE (/evaluate)
                Evaluates an existing Keras model from a given set of weights, features, and
                targets.

            Interfaces.PREDICT (/predict)
                Predicts a batch of examples using the Keras model.

            Interfaces.UPDATE_WEIGHTS (/update-weights)
                Updates the weights of the model.

            Interfaces.SAVE_MODEL (/save-model)
                Saves the model in a model.keras file.

            Interfaces.SAVE_WEIGHTS (/save-weights)
                Saves only the model weights in a file in the extension .h5.

        Outputs
        -------
            Interfaces.LOADED_MODEL (/loaded-model)
                Triggered when the model is loaded.

            Interfaces.LOADED_WEIGHTS (/loaded-weights)
                Triggered when the model weights are loaded.

            Interfaces.INITIALIZED_MODEL (/initialized-model)
                Triggered when the model is initialized.

            Interfaces.TRAINED (/trained)
                Triggered when the model is trained.

            Interfaces.EVALUATED (/evaluated)
                Triggered when the model is evaluated.

            Interfaces.UPDATED_WEIGHTS (/updated-weights)
                Triggered when the model weights are updated.

            Interfaces.COMPLETED (/completed)
                Triggered when the model is evaluated and the evaluation is completed.

            Interfaces.PREDICTED (/predicted)
                Triggered when the model predicts a batch of examples.

            Interfaces.SAVED_MODEL (/saved-model)
                Triggered when the model is saved.

            Interfaces.SAVED_WEIGHTS (/saved-weights)
                Triggered when the model weights are saved.
        """
        super().__init__()
        self.load_model_filepath = load_model_filepath
        self.load_weights_filepath = load_weights_filepath
        self.model = None
        self.epochs = epochs
        self.batch_size = batch_size
        self.initializer = initializer
        self.metrics = metrics
        self.default_metrics = ["accuracy"]
        self.send_gradients = send_gradients
        self.save_model_filepath = save_model_filepath
        self.save_weights_filepath = save_weights_filepath

        self.is_initialized = False
        self.is_loaded = False

        self.weights = []

        self.register(Interfaces.LOAD_MODEL, self._load, schema=val.LoadModel)
        self.register(Interfaces.LOADED_MODEL)
        self.register(Interfaces.INITIALIZED_MODEL)

        self.register(Interfaces.LOAD_WEIGHTS, self._load_weights, val.LoadWeights)
        self.register(Interfaces.LOADED_WEIGHTS)

        self.register(Interfaces.TRAIN, self._train, schema=val.Train)
        self.register(Interfaces.TRAINED)

        self.register(Interfaces.EVALUATE, self._evaluate, schema=val.Evaluate)
        self.register(Interfaces.EVALUATED)
        self.register(Interfaces.COMPLETED)

        self.register(Interfaces.PREDICT, self._predict, schema=val.Predict)
        self.register(Interfaces.PREDICTED)

        self.register(
            Interfaces.UPDATE_WEIGHTS, self.__update_weights_handler, schema=val.UpdateWeights
        )
        self.register(Interfaces.UPDATED_WEIGHTS)

        self.register(Interfaces.SAVE_MODEL, self._save_model, schema=val.SaveModel)
        self.register(Interfaces.SAVED_MODEL)

        self.register(Interfaces.SAVE_WEIGHTS, self._save_weights, schema=val.SaveWeights)
        self.register(Interfaces.SAVED_WEIGHTS)

    async def _load(self, req):
        """
        Loads a Keras model from a given filepath and
        optionally initializes the loaded model weights.
        """
        # 1. Load from file
        if not self.is_loaded:
            await self._load_model(req)

        # 2 Initialize the model weights
        if self.is_loaded and not self.is_initialized and self.initializer is not None:
            initializer = req.get('initializer', self.initializer)
            initializer = keras.initializers.get(initializer)
            shape = (self.model.count_params(),)
            weights = initializer(shape=shape).numpy().tolist()
            self.weights = weights
            self.is_initialized = True
            await self.trigger(
                Interfaces.INITIALIZED_MODEL,
                {"weights": self.weights},
                info_msg="Model initialized",
            )

        # 3. Overwrite the model weights if updated weights are provided
        self._update_weights(req)

    async def _train(self, req: dict) -> None:
        """
        Trains an existing Keras model from a given set of weights, features, and targets.
        The set of weights is a linear list of floats.
        The features and targets can be either lists or numpy arrays.

        Optionally, the number of epochs and batch size can be provided.
        If either the number of epochs or the batch size is not provided,
        it defaults to the values specified in the constructor.

        After training, the function calculates the gradients by subtracting the updated weights
        from the reference weights. It then triggers the "/trained" event
        with the gradients (send_gradients=True) or the updated weights (send_gradients=False).
        """
        await self._load(req)
        features, targets, epochs, batch_size, _ = self._get_params(req)
        if self.is_loaded:
            self.model.fit(features, targets, epochs=epochs, batch_size=batch_size, verbose=0)

            if self.send_gradients:
                gradients = (np.array(self.weights) - np.array(self._get_weights())).tolist()
                await self.trigger(
                    Interfaces.TRAINED, {"gradients": gradients}, info_msg="Training completed."
                )
            else:
                await self.trigger(
                    Interfaces.TRAINED,
                    {"weights": self._get_weights()},
                    info_msg="Training completed.",
                )

    async def _evaluate(self, req: dict) -> None:
        """
        Evaluates an existing Keras model from a given set of weights, features, and targets.
        The set of weights is a linear list of floats.
        The features and targets can be either lists or numpy arrays.
        """
        await self._load(req)
        features, targets, _, _, _ = self._get_params(req)
        if self.is_loaded:
            metrics = self.model.evaluate(features, targets, verbose=0, return_dict=True)
            await self.trigger(Interfaces.EVALUATED, metrics, info_msg="Evaluation completed")
            completed = req.get('completed', False)
            if completed:
                await self.trigger(Interfaces.COMPLETED, metrics, info_msg="Evaluation completed")

    async def _predict(self, req: dict) -> None:
        """
        Predict a batch of examples using the Keras model.
        """
        await self._load(req)
        features, _, _, _, identifiers = self._get_params(req)
        if self.is_loaded:
            predictions = self.model.predict(features).astype(float).tolist()
            await self.trigger(
                Interfaces.PREDICTED,
                {"identifier": identifiers, "prediction": predictions},
                info_msg="Prediction completed",
            )

    async def _load_model(self, req: dict) -> None:
        """
        Loads a Keras model from a given filepath.
        If the filepath is not provided, it defaults to its specified value in the constructor.
        """
        filepath = req.get('filepath', self.load_model_filepath)
        try:
            self.model = keras.models.load_model(filepath)
            self.metrics = await self._filter_valid_metrics(self.metrics)
            if self.metrics:
                self.model.compile(
                    optimizer=self.model.optimizer, loss=self.model.loss, metrics=self.metrics
                )
            elif not getattr(self.model.compiled_metrics, '_metrics', None):
                self.model.compile(
                    optimizer=self.model.optimizer,
                    loss=self.model.loss,
                    metrics=self.default_metrics,
                )

                warning = super()._get_warning(
                    "NoCompiledMetrics",
                    """Loaded model does not have any compiled
                                            metrics. Defaulting to dummy metric.""",
                    {"default_metric": self.default_metrics},
                )
                await self.trigger(Interfaces.WARNING, warning)

            weights = self._get_weights()
            self.weights = weights
            self.is_loaded = True
            await self.trigger(
                Interfaces.LOADED_MODEL,
                {"weights": weights},
                info_msg=f"Model loaded from {filepath}",
            )

        except (ValueError, OSError) as error:
            error = super()._get_error(
                "KerasModelLoadingError", "An error occurred when loading the model", str(error)
            )
            await self.trigger(Interfaces.ERROR, error)

    async def _load_weights(self, req: dict) -> None:
        """Loads the model weights from a weights file in extension .h5.

        Parameters
        ----------
            req : dict
                Request dictionary.
        """

        filepath = req.get('filepath', self.load_weights_filepath)

        try:
            if filepath is not None and self.model is not None:
                self.model.load_weights(filepath)
                await self.trigger(
                    Interfaces.LOADED_WEIGHTS,
                    {"weights": self._get_weights()},
                    info_msg=f"Weights loaded from {filepath}",
                )
            else:
                error = super()._get_error(
                    "KerasweightsLoadingError",
                    "No filepath provided to load the weights",
                    req,
                )
                await self.trigger(Interfaces.ERROR, error)
        except (ValueError, OSError) as error:
            error = super()._get_error(
                "KerasweightsLoadingError",
                "An error occurred when loading the weights",
                str(error),
            )
            await self.trigger(Interfaces.ERROR, error)

    async def _save_model(self, req: dict) -> None:
        """Saves the model in a model.keras file.

        Parameters
        ----------
            req : dict
                Request dictionary.
        """

        filepath = req.get('filepath', self.save_model_filepath)
        try:
            if filepath is not None and self.model is not None:
                if not filepath.endswith(".keras"):
                    filepath += ".keras"
                self.model.save(filepath)
                await self.trigger(
                    Interfaces.SAVED_MODEL,
                    {"filepath": filepath},
                    info_msg=f"Model saved at {filepath}",
                )
            else:
                error = super()._get_error(
                    "KerasModelSavingError", "No filepath provided to save the model", req
                )
                await self.trigger(Interfaces.ERROR, error)
        except (ValueError, OSError) as error:
            error = super()._get_error(
                "KerasModelSavingError", "An error occurred when saving the model", str(error)
            )
            await self.trigger(Interfaces.ERROR, error)

    async def _save_weights(self, req: dict) -> None:
        """Saves only the model weights in a file in the extension .h5.

        Parameters
        ----------
            req : dict
                Request dictionary.
        """

        filepath = req.get('filepath', self.save_weights_filepath)
        try:
            if filepath is not None and self.model is not None:
                if not filepath.endswith(".h5"):
                    filepath += ".h5"
                self.model.save_weights(filepath)
                await self.trigger(
                    Interfaces.SAVED_WEIGHTS,
                    {"filepath": filepath},
                    info_msg=f"Weights saved at {filepath}",
                )
            else:
                error = super()._get_error(
                    "KerasWeightsSavingError",
                    "No filepath or model provided to save the weights.",
                    req,
                )
                await self.trigger(Interfaces.ERROR, error)
        except (ValueError, OSError) as error:
            error = super()._get_error(
                "KerasWeightsSavingError", "An error occurred when saving the weights.", str(error)
            )
            await self.trigger(Interfaces.ERROR, error)

    def _get_params(self, req: dict) -> tuple:
        """
        Retrieve the training parameters from the
        request dictionary.
        """
        features = req.get('features', None)
        targets = req.get('targets', None)
        epochs = req.get('epochs', self.epochs)
        batch_size = req.get('batch_size', self.batch_size)
        identifiers = req.get('identifiers', None)

        return features, targets, epochs, batch_size, identifiers

    def _update_weights(self, req: dict) -> None:
        """
        Updates the model with the received gradients/weights.
        """

        weights = req.pop('weights', None)
        if weights is not None:
            self._set_weights(weights)
        else:
            gradients = req.pop('gradients', None)
            if gradients is not None:
                weights = self._restore_weights(gradients)
                self._set_weights(weights)

        # Update reference model
        if weights is not None:
            self.weights = weights

    async def __update_weights_handler(self, req: dict) -> None:
        """Updates the weights of the model and triggers the
        output interfaces."""

        if "gradients" not in req and "weights" not in req:
            await self.trigger(
                Interfaces.ERROR,
                super()._get_error(
                    "NoWeights", "No weights or gradients provided in the request.", req
                ),
            )
        else:
            self._update_weights(req)

            if self.weights is not None:
                await self.trigger(
                    Interfaces.UPDATED_WEIGHTS,
                    {"weights": self.weights, **req},
                    info_msg="Weights updated at trainer pod",
                )

    def _restore_weights(self, gradients: list) -> list:
        """Restore the weights using the updated gradients.

        Parameters
        ----------
            gradients : list
                Updated gradients.

        Returns
        -------
            list
                Restored weights.
        """
        return (np.array(self.weights) - np.array(gradients)).tolist()

    def _get_weights(self) -> list:
        """
        Given a keras model, obtain the model parameters in a
        linearized one-dimensional list.
        """
        weights = []
        for layer in self.model.layers:
            params_list = layer.get_weights()
            for params in params_list:
                weights += params.reshape(-1).tolist()
        return weights

    def _set_weights(self, weights: list) -> None:
        """
        Given a keras model and a linearized list of floats, sets
        the model parameters from the given list of floats.
        """
        if self.model.count_params() == len(weights):
            pad = 0
            for layer in self.model.layers:
                to_be_set = []
                param_list = layer.get_weights()
                for params in param_list:
                    size = len(params.reshape(-1))
                    section = np.array(weights[pad : pad + size])
                    to_be_set.append(section.reshape(params.shape))
                    pad += size
                layer.set_weights(to_be_set)

    async def _filter_valid_metrics(self, metrics: list) -> list:
        """
        Deletes out metrics specified in the pod constructor
        that are not implemented in the keras.metrics module
        and triggers a warning.

        Parameters
        --------
            metrics: list.
                Metrics input by the user.

        Returns
        --------
            valid_metrics: list.
                Pod metrics that are implemented in the keras.metrics
                module.

        Triggers
        --------
            Interfaces.WARNING (/warning)
                If the metric is not valid.

        """
        valid_metrics = []

        for metric in metrics:
            # Check if the name of a metric corresponds to a function/class in keras.metrics
            if callable(keras.metrics.get(metric)):
                valid_metrics.append(metric)
            else:
                warning = super()._get_warning(
                    "KerasInvalidMetricWarning",
                    "Metric is not available in the Keras Metrics module.",
                    {'invalid_metric': metric},
                )
                await self.trigger(Interfaces.WARNING, warning)

        return valid_metrics
