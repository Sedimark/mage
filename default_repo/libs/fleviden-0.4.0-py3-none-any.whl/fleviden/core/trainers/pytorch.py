# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a model trainer based on the Pytorch framework.
"""

import importlib.util
import inspect
from typing import Optional

import numpy as np
import torch
import torch.optim as optim
from sklearn.metrics import get_scorer
from torch.utils.data import DataLoader, TensorDataset

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Pytorch(Pod):
    """
    A Pytorch pod that trains, evaluates, and predicts using a Pytorch model.

    The model has to be saved as a model.pt file, containing the model state,
    loss function and (optional) optimizer; on the other hand, the model architecture has to be
    defined in a Python script.

    For example:

    Model definition
        >>> # my_model.py
        >>> class BasicModel(nn.Module):
        >>>     def __init__(self):
        >>>         super(BasicModel, self).__init__()
        >>>         self.fc1 = nn.Linear(9, 32)
        >>>         self.fc2 = nn.Linear(32, 1)
        >>>     def forward(self, x):
        >>>         x = F.relu(self.fc1(x))
        >>>         x = self.fc2(x)
        >>>         return x

    Instantiate the model, loss and optimizer.
        >>> model = BasicModel()
        >>> loss_function = nn.BCEWithLogitsLoss()
        >>> optimizer = optim.Adam(model.parameters(), lr=0.0001, weight_decay=1e-8)

    Save the checkpoint.
        >>> checkpoint = {
        >>>     'model_state': model.state_dict(),
        >>>     'optimizer': optimizer,
        >>>     'optimizer_state': optimizer.state_dict(),
        >>>     'loss': loss_function,
        >>>     'loss_state': loss_function.state_dict(),
        >>> }
        >>> torch.save(checkpoint, "model.pt")

    If no optimizer is specified in the checkpoint, it defaults to Adam with lr=1e-3.

    Create a Pytorch pod.
        >>> pod_pytorch = Pytorch(
        >>>     load_model_filepath="model.pt",
        >>>     modulepath="my_model.py",
        >>>     epochs=5,
        >>>     batch_size=254,
        >>> )
    """

    def __init__(
        self,
        load_model_filepath: str,
        modulepath: str,
        load_weights_filepath: str = "weights.pth",
        epochs: Optional[int] = None,
        batch_size: Optional[int] = None,
        metrics: list = [],
        custom_dataset_class=None,
        dataloader_args: dict = {},
        send_gradients: bool = True,
        save_model_filepath: str = "model.pth",
        save_weights_filepath: str = "weights.pth",
    ):
        """
        Creates a new Pytorch pod.

        Parameters
        ----------
            load_model_filepath : str
                The path to the file where the model.pt is located.

            modulepath : str
                The path to the Python module containing the Pytorch model.

            load_weights_filepath : str, optional
                The path to the file where the weights are loaded from.

            epochs : int, optional
                The number of training epochs.

            batch_size : int, optional
                The batch size for training.

            metrics : list, optional
                A list of metrics to evaluate.
                They must be implemented as a class or function in the
                sklearn.metrics mmodule.
                For example: ["accuracy", "neg_mean_absolute_error"].

            custom_dataset_class : class, optional
                A custom dataset class to use for the DataLoader. If not
                provided, it will create a TensorDataset with the features
                and targets as tensors. The custom dataset class should
                take features and targets as input and return a Pytorch Dataset.

            dataloader_args : dict, optional
                A dictionary with additional arguments for the DataLoader.
                For example: dataloader_args={"num_workers": 2, "shuffle": True}

            send_gradients: bool, optional
                If True, the gradients are sent after training. If False, the
                weights are sent instead. Default is True. Gradients are generated
                as the difference between the weights before and after a training round.

            save_model_filepath : str, optional
                The path to save the model checkpoint after training.

            save_weights_filepath : str, optional
                The path to save the model weights after training.

        Inputs
        ------
            Interfaces.LOAD_MODEL (/load-model)
                Loads a Pytorch model from a given filepath and modulepath.

            Interfaces.LOAD_WEIGHTS (/load-weights)
                Loads the weights of the model from a given filepath.

            Interfaces.TRAIN (/train)
                Trains a Pytorch model from a given set of weights, features, and targets.

            Interfaces.EVALUATE (/evaluate)
                Evaluates a Pytorch model from a given set of weights, features, and targets.

            Interfaces.PREDICT (/predict)
                Predicts a batch of examples using the Pytorch model.

            Interfaces.UPDATE_WEIGHTS (/update-weights)
                Updates the weights of the model.

            Interfaces.SAVE_MODEL (/save-model)
                Saves the model checkpoint to a given filepath.

            Interfaces.SAVE_WEIGHTS (/save-weights)
                Saves the model weights to a given filepath.

        Outputs
        -------
            Interfaces.LOADED_MODEL (/loaded-model)
                Triggered when the model is loaded.

            Interfaces.LOADED_WEIGHTS (/loaded-weights)
                Triggered when the weights are loaded.

            Interfaces.TRAINED (/trained)
                Triggered when the model is trained.

            Interfaces.EVALUATED (/evaluated)
                Triggered when the model is evaluated.

            Interfaces.UPDATED_WEIGHTS (/updated-weights)
                Triggered when the model weights are updated.

            Interfaces.SAVED_MODEL (/saved-model)
                Triggered when the model is saved.

            Interfaces.SAVED_WEIGHTS (/saved-weights)
                Triggered when the model weights are saved.

            Interfaces.COMPLETED (/completed)
                Triggered when the model is evaluated and the evaluation is completed.

            Interfaces.PREDICTED (/predicted)
                Triggered when the model predicts a batch of examples.
        """
        super().__init__()
        self.load_model_filepath = load_model_filepath
        self.load_weights_filepath = load_weights_filepath
        self.modulepath = modulepath
        self.epochs = epochs
        self.batch_size = batch_size
        self.custom_dataset_class = custom_dataset_class
        self.dataloader_args = dataloader_args
        self.metrics = metrics
        self.send_gradients = send_gradients
        self.save_model_filepath = save_model_filepath
        self.save_weights_filepath = save_weights_filepath

        # Model, loss and optimizer
        self.model = None
        self.criterion = None
        self.optimizer = None
        self.weights = []

        self.device = (
            "cuda"
            if torch.cuda.is_available()
            else "mps" if torch.backends.mps.is_available() else "cpu"
        )

        self.is_loaded = False
        self.is_initialized = False

        self.register(Interfaces.LOAD_MODEL, self._load)
        self.register(Interfaces.LOADED_MODEL)
        self.register(Interfaces.INITIALIZED_MODEL)

        self.register(Interfaces.LOAD_WEIGHTS, self._load_weights)
        self.register(Interfaces.LOADED_WEIGHTS)

        self.register(Interfaces.TRAIN, self._train)
        self.register(Interfaces.TRAINED)

        self.register(Interfaces.EVALUATE, self._evaluate)
        self.register(Interfaces.EVALUATED)

        self.register(Interfaces.PREDICT, self._predict)
        self.register(Interfaces.PREDICTED)

        self.register(Interfaces.COMPLETED)

        self.register(Interfaces.UPDATE_WEIGHTS, self.__update_weights_handler)
        self.register(Interfaces.UPDATED_WEIGHTS)

        self.register(Interfaces.SAVE_MODEL, self._save_model)
        self.register(Interfaces.SAVED_MODEL)

        self.register(Interfaces.SAVE_WEIGHTS, self._save_weights)
        self.register(Interfaces.SAVED_WEIGHTS)

    async def _load(self, req: dict) -> None:
        """
        Loads the Pytorch model from a given file.
        """
        # 1. Load from file
        if not self.is_loaded:
            await self._load_model(req)

        # (/initialized-model trigger)
        if self.is_loaded and not self.is_initialized:
            await self.trigger(
                Interfaces.INITIALIZED_MODEL,
                {"weights": self.weights},
                info_msg="Model initialized.",
            )
            self.is_initialized = True

        # 2. Overwrite model weights if updated weights are provided
        self._update_weights(req)

    async def _save_model(self, req: dict) -> None:
        """Saves the model in a model.pt file.

        Parameters
        ----------
            req : dict
                Request dictionary.
        """

        filepath = req.get('filepath', self.save_model_filepath)
        try:
            if filepath is not None and self.model is not None:
                if not filepath.endswith(".pth") and not filepath.endswith(".pt"):
                    filepath += ".pth"
                # save model
                torch.save(
                    {
                        'model_state': self.model.state_dict(),
                        'optimizer_class_name': self.optimizer.__class__.__name__,
                        'optimizer_state': self.optimizer.state_dict(),
                        'loss': self.criterion,
                        'loss_class_name': self.criterion.__class__.__name__,
                        'loss_state': self.criterion.state_dict(),
                    },
                    filepath,
                )
                await self.trigger(
                    Interfaces.SAVED_MODEL,
                    {"filepath": filepath},
                    info_msg=f"Model saved at {filepath}",
                )
            else:
                error = super()._get_error(
                    "PytorchModelSavingError", "No filepath provided to save the model", req
                )
                await self.trigger(Interfaces.ERROR, error)
        except (ValueError, OSError) as error:
            error = super()._get_error(
                "PytorchModelSavingError", "An error occurred when saving the model", str(error)
            )
            await self.trigger(Interfaces.ERROR, error)

    async def _save_weights(self, req: dict) -> None:
        """Saves the model weights in a model.pt file.

        Parameters
        ----------
            req : dict
                Request dictionary.
        """

        filepath = req.get('filepath', self.save_weights_filepath)
        try:
            if filepath is not None and self.model is not None:
                if not filepath.endswith(".pth") and not filepath.endswith(".pt"):
                    filepath += ".pth"
                # save weights
                torch.save({'model_state': self.model.state_dict()}, filepath)
                await self.trigger(
                    Interfaces.SAVED_WEIGHTS,
                    {"filepath": filepath},
                    info_msg=f"Weights saved at {filepath}",
                )
            else:
                error = super()._get_error(
                    "PytorchWeightsSavingError", "No filepath provided to save the weights", req
                )
                await self.trigger(Interfaces.ERROR, error)
        except (ValueError, OSError) as error:
            error = super()._get_error(
                "PytorchWeightsSavingError", "An error occurred when saving the weights", str(error)
            )
            await self.trigger(Interfaces.ERROR, error)

    async def _train(self, req: dict):
        """
        Trains an existing Pytorch model from a given set of weights, features, and targets.
        The set of weights is a linear list of floats.
        The features and targets can be either lists or numpy arrays.

        Optionally, the number of epochs and batch size can be provided in
        the req input message.
        If either the number of epochs or the batch size is not provided,
        it defaults to the values specified in the constructor.

        After training, the function calculates the gradients by subtracting the updated weights
        from the reference weights. It then triggers the "/trained" event
        with the gradients (send_gradients=True) or the updated weights (send_gradients=False).
        """
        await self._load(req)
        if self.is_loaded:
            features, targets, epochs, batch_size, _ = self._get_params(req)
            self.dataloader_args['batch_size'] = batch_size
            dataloader = self._to_dataloader(features, targets, self.dataloader_args)

            self.model.train()
            for epoch in range(epochs):
                for inputs, labels in dataloader:
                    inputs, labels = inputs.to(self.device), labels.to(self.device)
                    self.optimizer.zero_grad()
                    outputs = self.model(inputs)
                    loss = self.criterion(outputs, labels)
                    # print(f'Epoch: {epoch}, Loss: {loss.item()}\t')
                    loss.backward()
                    self.optimizer.step()
            if self.send_gradients:
                gradients = (np.array(self.weights) - np.array(self._get_weights())).tolist()
                await self.trigger(
                    Interfaces.TRAINED, {"gradients": gradients}, info_msg="Training completed."
                )
            else:
                await self.trigger(
                    Interfaces.TRAINED,
                    {"weights": self._get_weights()},
                    info_msg="Training completed.",
                )

    async def _evaluate(self, req: dict):
        """
        Evaluates an existing Pytorch model from a given set of weights, features, and targets.
        The set of weights is a linear list of floats.
        The features and targets can be either lists or numpy arrays.
        """
        await self._load(req)
        self.model.eval()
        if self.is_loaded:
            features, targets, _, batch_size, _ = self._get_params(req)
            self.dataloader_args['batch_size'] = batch_size
            dataloader = self._to_dataloader(features, targets, self.dataloader_args)

            metrics = {}
            for metric in self.metrics:
                metrics[metric] = 0

            with torch.no_grad():
                for inputs, labels in dataloader:
                    inputs, labels = inputs.to(self.device), labels.to(self.device)
                    outputs = self.model(inputs)
                    for metric in self.metrics:
                        m = self._compute_metric(metric, outputs, labels)
                        metrics[metric] += m
            for metric in self.metrics:
                metrics[metric] /= len(dataloader)
            await self.trigger(Interfaces.EVALUATED, metrics)
            completed = req.get('completed', False)
            if completed:
                await self.trigger(Interfaces.COMPLETED, metrics)

    async def _predict(self, req: dict):
        """
        Predict a batch of examples using the Pytorch model.
        """
        await self._load(req)
        self.model.eval()
        if self.is_loaded:
            features, _, _, _, identifiers = self._get_params(req)
            self.dataloader_args['batch_size'] = 1
            dataloader = self._to_dataloader(features, [0] * len(features), self.dataloader_args)

            predictions = []
            with torch.no_grad():
                for inputs, _ in dataloader:
                    inputs = inputs.to(self.device)
                    outputs = self.model(inputs[0])
                    predictions.extend(outputs.numpy())
            await self.trigger(
                Interfaces.PREDICTED, {"identifiers": identifiers, "predictions": predictions}
            )

    async def _load_model(self, req: dict):
        """
        Loads a Pytorch model from a given filepath and modulepath,
        the first one containing the model.pt checkpoint (loss, optimizer
        and model state), and the second providing the model architecture
        in a Python script.

        If the filepath or modulepath are not provided,
        it defaults to their specified values in the constructor.
        """
        filepath = req.get('filepath', self.load_model_filepath)
        modulepath = req.get('modulepath', self.modulepath)
        try:
            checkpoint = torch.load(filepath, weights_only=False)

            # Read the model class from a python script
            ModelClass = self._get_model_architecture(modulepath)
            self.model = ModelClass()
            self.model.load_state_dict(checkpoint['model_state'])

            # Loss function (Mandatory)
            loss_class_name = checkpoint['loss'].__class__.__name__
            loss_class = getattr(torch.nn, loss_class_name)
            self.criterion = loss_class()
            self.criterion.load_state_dict(checkpoint['loss_state'])

            # Optimizer (defaults to Adam)
            try:
                optimizer_class_name = checkpoint['optimizer_class_name']
                optimizer_class = getattr(optim, optimizer_class_name)
                self.optimizer = optimizer_class(self.model.parameters())
                self.optimizer.load_state_dict(checkpoint['optimizer_state'])
            except Exception as e:
                self.optimizer = optim.Adam(self.model.parameters(), lr=1e-3)

            weights = self._get_weights()
            self.weights = weights
            self.is_loaded = True
            await self.trigger(
                Interfaces.LOADED_MODEL,
                {"weights": weights},
                info_msg=f"Model loaded from {filepath}.",
            )

        except (ValueError, OSError) as error:
            error = super()._get_error(
                "PyTorchModelLoadingError", "An error occurred when loading the model", str(error)
            )
            await self.trigger(Interfaces.ERROR, error)

    async def _load_weights(self, req: dict):
        """Loads the weights of the model from a given file.
        The weights are the model.state_dict() in a .pth file.
        """

        filepath = req.get('filepath', self.load_weights_filepath)
        try:
            checkpoint = torch.load(filepath, weights_only=False)
            self.model.load_state_dict(checkpoint['model_state'])
            await self.trigger(
                Interfaces.LOADED_WEIGHTS,
                {"weights": self.weights},
                info_msg=f"Weights loaded from {filepath}.",
            )
        except (ValueError, OSError) as error:
            error = super()._get_error(
                "PytorchWeightsLoadingError",
                "An error occurred when loading the weights",
                str(error),
            )
            await self.trigger(Interfaces.ERROR, error)

    def _update_weights(self, req: dict) -> None:
        """
        Updates the model with the received gradients/weights.
        """
        gradients = req.pop('gradients', None)
        if gradients is not None:
            weights = self._restore_weights(gradients)
            self._set_weights(weights)
        else:
            weights = req.pop('weights', None)
            if weights is not None:
                self._set_weights(weights)

        # Update reference model weights
        if weights is not None:
            self.weights = weights

    async def __update_weights_handler(self, req: dict) -> None:
        """Updates the weights of the model and triggers the
        output interfaces."""

        if "gradients" not in req and "weights" not in req:
            await self.trigger(
                Interfaces.ERROR,
                super()._get_error(
                    "NoWeights", "No weights or gradients provided in the request.", req
                ),
            )
        else:
            self._update_weights(req)

            if self.weights is not None:
                await self.trigger(
                    Interfaces.UPDATED_WEIGHTS,
                    {"weights": self.weights, **req},
                    info_msg="Weights updated at trainer pod",
                )

    def _restore_weights(self, gradients: list) -> list:
        """Restore the weights using the updated gradients.

        Parameters
        ----------
            gradients : list
                Updated gradients.

        Returns
        -------
            list
                Restored weights.
        """
        return (np.array(self.weights) - np.array(gradients)).tolist()

    def _get_weights(self) -> list:
        """
        Given a Pytorch model, obtain the model parameters in a
        linearized one-dimensional list.
        """
        weights = []
        for param in self.model.parameters():
            weights.extend(param.data.numpy().flatten().tolist())

        return weights

    def _set_weights(self, weights: list):
        """
        Given a Pytorch model and a linearized list of floats, sets
        the model parameters from the given list of floats.
        """
        index = 0
        for param in self.model.parameters():
            shape = param.data.shape
            size = np.prod(shape)
            param.data = torch.tensor(weights[index : index + size]).reshape(shape)
            index += size

    def _get_params(self, req: dict) -> tuple:
        """
        Retrieve the training parameters from the
        request dictionary.
        """
        features = req.get('features', None)
        targets = req.get('targets', None)
        epochs = req.get('epochs', self.epochs)
        batch_size = req.get('batch_size', self.batch_size)
        identifiers = req.get('identifiers', None)

        return features, targets, epochs, batch_size, identifiers

    def _to_dataset_class(self, features, targets):
        """
        Convert the features and targets into a custom dataset class
        or to a TensorDataset by default.

        Parameters
        ----------
            features : Any
                Data features in provided format.

            targets : Any
                Data labels in provided format.

        Returns
        -------
            dataset : torch.utils.data.Dataset
                The Pytorch Dataset with features and targets as tensors.
        """
        if self.custom_dataset_class is not None:
            dataset = self.custom_dataset_class(features, targets)
        else:
            dataset = TensorDataset(
                torch.tensor(np.array(features), dtype=torch.float32),
                torch.tensor(np.array(targets), dtype=torch.float32),
            )

        return dataset

    def _to_dataloader(self, features, targets, dataloader_args):
        """
        Convert the features and targets into a Pytorch DataLoader.

        Parameters
        ----------
            features : Any
                Data features in provided format.

            targets : Any
                Data labels in provided format.

            dataloader_args : dict
                Arguments for the DataLoader.

        Returns
        -------
            dataloader : torch.utils.data.DataLoader
                The Pytorch DataLoader with features and targets as tensors.
        """
        # To tensor dataset
        dataset = self._to_dataset_class(features, targets)

        # To dataloader
        dataloader = DataLoader(dataset, **dataloader_args)

        return dataloader

    def _get_model_architecture(self, module_path):
        """
        Reads the model architecture defined as a class(nn.Module) from
        a Python script.

        Parameters
        ----------
            module_path : str
                The path to the Python script containing the model architecture.

        Returns
        -------
            model_class : nn.Module
                Model architecture.
        """
        # Load the module from the given path
        spec = importlib.util.spec_from_file_location("model_module", module_path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        # Find the model class in the module
        model_class = None
        for name, obj in inspect.getmembers(module, inspect.isclass):
            if issubclass(obj, torch.nn.Module) and obj.__module__ == module.__name__:
                model_class = obj
                break

        if model_class is None:
            raise ValueError("No valid Pytorch model class found in the module")

        return model_class

    def _compute_metric(self, metric, outputs, labels):
        """
        Computes the value of a metric given the model outputs and labels.

        Parameters
        ----------
            metric : str
                The metric to compute.

            outputs : torch.Tensor
                The model outputs.

            labels : torch.Tensor
                The target labels.
        """
        outputs_np = outputs.detach().cpu().numpy()
        labels_np = labels.detach().cpu().numpy()

        try:
            scorer = get_scorer(metric)
        except ValueError:
            raise ValueError(f"Unsupported metric: {metric}")

        if metric in ["roc_auc", "roc_auc_ovr", "roc_auc_ovo"]:
            preds = np.argmax(outputs_np, axis=1)
        elif metric in ["accuracy", "f1", "precision", "recall"]:
            if outputs_np.shape[1] == 1:  # Binary classification case
                preds = (outputs_np > 0.5).astype(np.float32)
            else:  # Multiclass classification case
                preds = np.argmax(outputs_np, axis=1)
                labels_np = np.argmax(labels_np, axis=1)
        elif metric in ["neg_mean_squared_error", "neg_mean_absolute_error"]:
            preds = outputs_np
        else:
            preds = (outputs_np > 0.5).astype(np.float32)

        try:
            result = scorer._score_func(labels_np, preds, zero_division=0)
        except TypeError:
            result = scorer._score_func(labels_np, preds)

        return result
