# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a HealthCheck pod that periodically pings clients to check
if they are responsive.
"""

import asyncio

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class HealthCheck(Pod):
    """A HealthCheck pod that periodically pings clients to check if they are responsive.

    The HealthCheck pod sends a ping to all active clients every period seconds. If a client
    does not respond to the ping for num_retries times, it is considered unhealthy.

    It can be used in conjunction with a Server pod to monitor the health of
    clients. The HealthCheck pod does not keep track of the list of active clients. It has to
    be updated manually with the /update-clients trigger.

    An example of a server-side HealthCheck pod is shown below:

    Create a Server, HTTP and HealthCheck pod:
        >>> pod_server = Server(server_id, clients=clients)
        >>> pod_http = HTTP(server_id)
        >>> pod_healthcheck = HealthCheck(period=30, num_retries=2, autostart=True)

    Link the HTTP pod to send pings to clients:
        >>> pod_healthcheck.link(Interfaces.PING, pod_http, "/ping-from-server")
        >>> pod_http.bridge_multicast("/ping-from-server", "/ping-sent", Interfaces.REST_PING_FROM_SERVER)

    Link the HTTP pod to receive client pings:
        >>> pod_http.wait(Interfaces.REST_PONG_FROM_CLIENT)
        >>> pod_http.link(Interfaces.REST_PONG_FROM_CLIENT, pod_healthcheck, Interfaces.RECEIVE_PING)

    Link the Server pod to update the list of active clients:
        >>> pod_server.link(Interfaces.UPDATED_CLIENTS, pod_healthcheck, Interfaces.UPDATE_CLIENTS)

    Link the Server pod to unsubscribe unhealthy clients:
        >>> pod_healthcheck.link(Interfaces.UNHEALTHY, pod_server, Interfaces.UNSUBSCRIBE)

    At the client side, you can link the HTTP pod to automatically send an ACK when pinged:
        >>> pod_http.wait(Interfaces.REST_PING_FROM_SERVER)
        >>> pod_http.link(Interfaces.REST_PING_FROM_SERVER, pod_http, Interfaces.REST_PONG_TO_SERVER)
        >>> pod_http.bridge(Interfaces.REST_PONG_TO_SERVER, host=f"http://{server}", endpoint=Interfaces.REST_PONG_FROM_CLIENT)
    """

    def __init__(self, period: int = 60, num_retries: int = 3, autostart: bool = True):
        """Creates a HealthCheck pod.

        Parameters
        ----------
            period : int, optional
                Number of seconds in between periodic pings, by default 60.

            num_retries : int, optional
                Max number of pings sent to an unresponsive client before considering it
                unhealthy.

            autostart : bool, optional
                If True, the periodic ping loop is triggered automatically after
                initialization (/update-clients). If False, it has to be manually started with
                a trigger to /start. By default True.

        Inputs
        ------
            Interfaces.UPDATE_CLIENTS (/update-clients)
                Updates the list of active clients. If the HealthCheck pod is not initialized,
                it initializes it.

            Interfaces.START (/start)
                Starts the periodic ping loop.

            Interfaces.STOP (/stop)
                Stops the periodic ping loop.

            Interfaces.SEND_PING (/send-ping)
                Sends a ping to all active clients. Triggered by the periodic ping loop.

            Interfaces.RECEIVE_PING (/receive-ping)
                Receives a ping response (pong) from a client.

        Outputs
        -------
            Interfaces.UPDATED_CLIENTS (/updated-clients)
                Triggered after updating the list of active clients.

            Interfaces.PING (/ping)
                Sends a ping to all active clients.

            Interfaces.PONG (/pong)
                Triggered after receiving a response from a pinged client.

            Interfaces.HEALTHY (/healthy)
                A notification that a client is healthy.

            Interfaces.UNHEALTHY (/unhealthy)
                A notification that a client is unhealthy.
        """
        super().__init__()

        self.period = period
        self.num_retries = num_retries
        self.autostart = autostart

        self.clients_ping_count = {}

        self.is_initialized = False
        self._running = False
        self.loop = None

        self.register(Interfaces.START, self._start_loop)
        self.register(Interfaces.STOP, self._stop_loop)

        self.register(Interfaces.SEND_PING, self._send_ping)
        self.register(Interfaces.PING)

        self.register(Interfaces.RECEIVE_PING, self._receive_ping)
        self.register(Interfaces.PONG)

        self.register(Interfaces.UPDATE_CLIENTS, self._update_clients)
        self.register(Interfaces.UPDATED_CLIENTS)

        self.register(Interfaces.HEALTHY)
        self.register(Interfaces.UNHEALTHY)

    async def _update_clients(self, req: dict) -> None:
        """Updates the list of active clients."""

        active_clients = req.get("clients")

        # Re-initialize clients count
        if active_clients:
            self.clients_ping_count = {client: 0 for client in active_clients}

        await self.trigger(Interfaces.UPDATED_CLIENTS, self.clients_ping_count)

        if not self.is_initialized and self.autostart:
            self.is_initialized = True
            await self._start_loop(req)

    async def _start_loop(self, _req: dict) -> None:
        """Starts the periodic ping loop, which triggers /send-ping every period seconds."""
        self._running = True

        async def _periodic_ping():
            while self._running:
                try:
                    await asyncio.sleep(self.period)
                    await self.trigger(Interfaces.SEND_PING, {})
                except Exception as e:
                    error = {
                        "name": type(e).__name__,
                        "description": "An error occurred in the periodic ping loop",
                        "details": str(e),
                    }
                    await self.trigger(Interfaces.ERROR, error)
                    self._running = False

        self.loop = asyncio.get_event_loop()
        self.loop.create_task(_periodic_ping())

    async def _stop_loop(self, _req: dict) -> None:
        """Stops the periodic ping loop."""
        self._running = False
        tasks = [task for task in asyncio.all_tasks() if task.get_name() == "_periodic_ping"]
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
        self.loop = None

    async def _send_ping(self, _req: dict) -> None:
        """Send a ping to all active clients and update their count. When a client is
        unresponsive for num_retries, it is considered unhealthy.
        """

        # Get healthy and unhealthy clients
        active_clients = [
            client for client, count in self.clients_ping_count.items() if count < self.num_retries
        ]
        inactive_clients = [
            client for client, count in self.clients_ping_count.items() if count >= self.num_retries
        ]

        # +1 to number of pings
        self.clients_ping_count = {
            client: count + 1 for client, count in self.clients_ping_count.items()
        }

        # Ping healthy clients (/ping), notify about unhealthy ones (/unhealthy)
        if active_clients:
            await self.trigger(Interfaces.PING, {"clients": active_clients})
            for client in active_clients:
                await self.trigger(Interfaces.HEALTHY, {"origin": client})

        if inactive_clients:
            for client in inactive_clients:
                await self.trigger(
                    Interfaces.UNHEALTHY, {"origin": client}, info_msg="Unhealthy client."
                )
                self.clients_ping_count.pop(client)

    async def _receive_ping(self, req: dict) -> None:
        """Receives a ping response (/pong) from a client and resets its retries count."""
        client = req.get("origin", req.get("id", req.get("client_id", None)))

        # Reset retries for client
        if client in self.clients_ping_count:
            self.clients_ping_count[client] = 0
            await self.trigger(Interfaces.PONG, {"client": client})
        else:
            warning = {
                "name": "UnknownClient",
                "description": "Received a ping from an unknown client",
                "details": f"Client: {client}",
            }
            await self.trigger(Interfaces.WARNING, warning)
