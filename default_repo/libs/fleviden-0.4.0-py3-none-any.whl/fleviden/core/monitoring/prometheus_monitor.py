# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a Prometheus-compatible metrics monitor.
"""

from aiohttp import web

from fleviden.core.bridge.http import HTTP
from fleviden.core.flow.cache import Cache
from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class PrometheusMonitor(Pod):
    """This class implements a Prometheus-compatible monitoring pod that stores
    a dictionary of metrics in cache and formats it as text upon receiving a request
    from a Prometheus server.

    The monitor creates an HTTP server with a the specified port, and opens a /metrics endpoint
    for scraping.

    For example:

    Create a monitor pod:
        >>> monitor = PrometheusMonitor(port=8000)

    Link the monitor to any other pod that generates metrics.
        >>> other_pod.link(Interfaces.METRIC, monitor, Interfaces.STORE)

    Configure a Prometheus server to scrap for metrics at the IP:port of the monitor.
        >>> #prometheus.yml
        >>> scrape_configs:
        >>>     static_configs:
        >>>     - targets: ['<IP>:8000']

    *Note: In a dockerized environment, the <IP> is the container, e.g., client-one:8000.*
    """

    def __init__(self, port=8000):
        """Creates a PrometheusMonitor pod.

        Parameters
        ----------
            port : int, optional
                HTTP port where the Prometheus sever can scrap metrics, by default 8000.

        Inputs
        ------
            Interfaces.STORE (/store)
                A request to store metrics in the monitor's Cache.

        Outputs
        -------
            Interfaces.STORED (/stored)
                A notification that metrics have been saved in cache.
        """
        super().__init__()

        self.port = port

        self.cache = Cache(overwrite=False)
        self.http = HTTP("prometheus-monitor", port=self.port)

        self.register(Interfaces.STORE)
        self.link(Interfaces.STORE, self.cache, Interfaces.STORE)
        self.cache.link(Interfaces.STORED, self, Interfaces.STORED)
        self.register(Interfaces.STORED)

        self.http.wait("/metrics", 'get', wait_callback=self._get_metrics)

    async def _get_metrics(self, _req):
        """Serve metrics in Prometheus text exposition format."""
        metrics_dict = self.cache.cache
        if metrics_dict:
            metrics_text = self.format_metrics(metrics_dict)
            return web.Response(text=metrics_text, content_type='text/plain')

    def format_metrics(self, req: dict):
        """Format dictionary as Prometheus text."""
        metrics_lines = []
        for name, value in req.items():
            metrics_lines.append(f"# HELP {name} Automatically generated metric")
            metrics_lines.append(f"# TYPE {name} gauge")
            metrics_lines.append(f"{name} {value}")
        return "\n".join(metrics_lines)
