# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module provides the implementation for a client that interacts with the Evidently library.
"""

import copy
from typing import List, Optional, Union

import pandas
from evidently.base_metric import Metric
from evidently.metric_preset import (
    ClassificationPreset,
    DataDriftPreset,
    DataQualityPreset,
    RegressionPreset,
    TargetDriftPreset,
)
from evidently.report import Report

from fleviden.core.interfaces.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class EvidentlyMonitor(Pod):
    """
    A pod to interact with the Evidently library.

    Check the Evidently documentation for more details:
    https://docs.evidentlyai.com/
    """

    def __init__(
        self,
        reference_filepath: Optional[str] = None,
        current_filepath: Optional[str] = None,
        metrics: Optional[List[Metric]] = None,
    ):
        """
        Initializes the EvidentlyMonitor.

        Parameters
        ----------
            reference_filepath : str, optional
                A string with the filepath for the reference dataset in csv format.

            current_filepath : str, optional
                A string with the filepath for the current dataset in csv format.

            metrics : list, optional
                A list of metrics to evaluate.

        Inputs
        ------
            Interfaces.REPORT (/report)
                A request to run the metrics in self.metrics.

            Interfaces.DETECT_DATA_DRIFT (/detect-data-drift)
                A request to detect data drift.

            Interfaces.REPORT_DATA_DRIFT (/report-data-drift)
                A request to run the metrics in DataDriftPreset.

            Interfaces.REPORT_DATA_QUALITY (/report-data-quality)
                A request to run the metrics in DataQualityPreset.

            Interfaces.REPORT_TARGET_DRIFT (/report-target-drift)
                A request to run the metrics in TargetDriftPreset.

            Interfaces.REPORT_CLASSIFICATION (/report-classification)
                A request to run the metrics in ClassificationPreset.

            Interfaces.REPORT_REGRESSION (/report-regression)
                A request to run the metrics in RegressionPreset.

        Outputs
        -------
            Intefaces.REPORTED (/reported)
                A notification with the metrics report.

            Interfaces.DETECTED_DATA_DRIFT (/detected-data-drift)
                A notification that a data drift has been detected.

            Interfaces.DETECTED_NO_DATA_DRIFT (/detected-no-data-drift)
                A notification that no data drift has been detected

            Interfaces.REPORTED_DATA_DRIFT (/reported-data-drift)
                A notification with the metric report for the metrics in DataDriftPreset.

            Interfaces.REPORTED_DATA_QUALITY (/reported-data-quality)
                A notification with the metric report for the metrics in DataQualityPreset.

            Interfaces.REPORTED_TARGET_DRIFT (/reported-target-drift)
                A notification with the metric report for the metrics in TargetDriftPreset.

            Interfaces.REPORTED_CLASSIFICATION (/reported-classification)
                A notification with the metric report for the metrics in ClassificationPreset.

            Interfaces.REPORTED_REGRESSION (/reported-regression)
                A notification with the metric report for the metrics in RegressionPreset.
        """
        super().__init__()

        self.reference_data = None
        self.reference_filepath = reference_filepath
        self.current_filepath = current_filepath
        self.__metrics = copy.deepcopy(metrics)

        self.register(Interfaces.REPORT, self.__report)
        self.register(Interfaces.REPORTED)
        self.register(Interfaces.DETECT_DATA_DRIFT, self.__detect_data_drift)
        self.register(Interfaces.DETECTED_DATA_DRIFT)
        self.register(Interfaces.DETECTED_NO_DATA_DRIFT)
        self.register(
            Interfaces.REPORT_DATA_QUALITY,
            self.__report_callback(DataQualityPreset(), Interfaces.REPORTED_DATA_QUALITY),
        )
        self.register(Interfaces.REPORTED_DATA_QUALITY)
        self.register(
            Interfaces.REPORT_DATA_DRIFT,
            self.__report_callback(DataDriftPreset(), Interfaces.REPORTED_DATA_DRIFT),
        )
        self.register(Interfaces.REPORTED_DATA_DRIFT)
        self.register(
            Interfaces.REPORT_TARGET_DRIFT,
            self.__report_callback(TargetDriftPreset(), Interfaces.REPORTED_TARGET_DRIFT),
        )
        self.register(Interfaces.REPORTED_TARGET_DRIFT)
        self.register(
            Interfaces.REPORT_CLASSIFICATION,
            self.__report_callback(ClassificationPreset(), Interfaces.REPORTED_CLASSIFICATION),
        )
        self.register(Interfaces.REPORTED_CLASSIFICATION)
        self.register(
            Interfaces.REPORT_REGRESSION,
            self.__report_callback(RegressionPreset(), Interfaces.REPORTED_REGRESSION),
        )
        self.register(Interfaces.REPORTED_REGRESSION)

    async def __detect_data_drift(self, req: dict) -> None:
        """
        Runs the metrics defined in DataDriftPresent and triggers Interfaces.DETECTED_DATA_DRIFT if
        a data drift is detected.
        """
        current_data = req.get('current_data', None)
        reference_data = req.get('reference_data', None)
        if current_data is None:
            warning = self.__get_current_data_warning(req)
            await self.trigger(Interfaces.WARNING, warning)
        elif reference_data is None:
            warning = self.__get_reference_data_warning(req)
            await self.trigger(Interfaces.WARNING, warning)
        else:
            current_data = pandas.DataFrame(current_data)
            reference_data = pandas.DataFrame(reference_data)
            report = Report(metrics=[DataDriftPreset()])
            report.run(reference_data=reference_data, current_data=current_data)

            triggered = False
            for metric in report.as_dict()['metrics']:
                if metric['result']['dataset_drift']:
                    info_msg = "Data drift has been detected"
                    await self.trigger(Interfaces.DETECTED_DATA_DRIFT, {}, info_msg=info_msg)
                    triggered = True
                elif metric['metric'] == "DataDriftTable":
                    for column in metric['result']['drift_by_columns'].values():
                        if column['drift_detected']:
                            info_msg = "Data drift has been detected"
                            await self.trigger(
                                Interfaces.DETECTED_DATA_DRIFT, {}, info_msg=info_msg
                            )
                            triggered = False
                            break
                if triggered:
                    break

            if not triggered:
                info_msg = "No data drift has been detected"
                await self.trigger(Interfaces.DETECTED_NO_DATA_DRIFT, {}, info_msg=info_msg)

    async def __report(self, req: dict) -> None:
        """
        Reports the configured metrics.
        """
        current_filepath = req.get('current_filepath', self.current_filepath)
        if self.__metrics is None:
            warning = self.__get_no_metrics_warning()
            await self.trigger(Interfaces.WARNING, warning)
        else:
            for metric in self.__metrics:
                if isinstance(metric, Metric):
                    report = Report(metrics=[metric])
                    req = await self.__run_report(report, current_filepath)
                    if req is not None:
                        await self.trigger(Interfaces.REPORTED, req)
                else:
                    self.__metrics.remove(metric)
                    warning = self.__get_metric_warning(metric.__name__)
                    await self.trigger(Interfaces.WARNING, warning)

    def __report_callback(self, metric: callable, interface: str) -> callable:
        """
        Return a function callback that runs the target report.

        Parameters
        ----------
            metric : callable
                The target metric to be reported.

            interface : str
                The pod interface to be triggered.

        Returns
        -------
            callable
                The callback function that runs the report and sends its through the interface.
        """

        async def report(req: dict) -> None:
            if isinstance(metric, DataQualityPreset):
                info_msg = "Reported data quality"
            elif isinstance(metric, DataDriftPreset):
                info_msg = "Reported data drift"
            elif isinstance(metric, TargetDriftPreset):
                info_msg = "Reported target drift"
            elif isinstance(metric, ClassificationPreset):
                info_msg = "Reported classification"
            elif isinstance(metric, RegressionPreset):
                info_msg = "Reported regression"
            report = Report(metrics=[metric])
            current_filepath = req.get('current_filepath', self.current_filepath)
            req = await self.__run_report(report, current_filepath)
            if req is not None:
                await self.trigger(interface, req, info_msg=info_msg)

        return report

    async def __run_report(self, report: callable, current_filepath: str) -> Union[dict, None]:
        """
        A function to run a metrics report.

        Parameters
        ----------
            report : callable
                The Evidently report to be run.

            current_filepath : str
                A path to the current data.

        Returns
        -------
            dict
                A dictionary with the report.
        """
        try:
            if self.reference_data is None:
                self.reference_data = pandas.read_csv(self.reference_filepath)
            current_data = pandas.read_csv(current_filepath)
            report.run(reference_data=self.reference_data, current_data=current_data)
            return report.as_dict()
        except FileNotFoundError:
            warning = self.__get_file_warning(current_filepath)
            await self.trigger(Interfaces.WARNING, warning)
        return None

    def __get_metric_warning(self, metric: str) -> dict:
        name = "EvidentlyMetricWarning"
        description = f"The metric {metric} is not supported by Evidently"
        details = {'metric': metric}
        return super()._get_warning(name, description, details)

    def __get_file_warning(self, file: str) -> dict:
        name = "EvidentlyFileWarning"
        description = f"The file {file} does not exist"
        details = {}
        return super()._get_warning(name, description, details)

    def __get_no_metrics_warning(self) -> dict:
        name = "EvidentlyNoMetricsWarning"
        description = "No metric has been configured for the pod"
        details = {}
        return super()._get_warning(name, description, details)

    def __get_current_data_warning(self, req) -> dict:
        name = "EvidentlyCurrentDataWarning"
        description = "No 'current_data' field found in req"
        details = {"req_keys": list(req.keys())}
        return super()._get_warning(name, description, details)

    def __get_reference_data_warning(self, req) -> dict:
        name = "EvidentlyReferenceDataWarning"
        description = "No 'reference_data' field found in req"
        details = {"req_keys": list(req.keys())}
        return super()._get_warning(name, description, details)
