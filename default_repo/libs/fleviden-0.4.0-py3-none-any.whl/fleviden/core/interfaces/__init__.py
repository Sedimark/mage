from fleviden.core.interfaces.interfaces import Interfaces
