# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module lists common interfaces' names within Fleviden.
"""


class Interfaces:
    """
    A list of common interfaces names within Fleviden, defined as
    constant strings. Each constant is equivalent to a lowercase string of the
    same name prefixed with a slash ("/"). Underscores in the constant
    names are replaced with hyphens in the string names.

    Example:
        >>> Interfaces.INITIALIZE == "/initialize"
        >>> Interfaces.START_TRAINING == "/start-training"

    To be used in Fleviden pods when registering or linking interfaces.

    For example:

    Import the Interfaces class and use it to register an interface:
        >>> from fleviden.core.interfaces import Interfaces
        >>> class MyPod(Pod):
        >>>     def __init__(self):
        >>>         super().__init__()
        >>>         self.register(Interfaces.INITIALIZE, self.initialize)

    Link two pods using the Interfaces class:
        >>> my_pod.link(Interfaces.INITIALIZED, other_pod, Interfaces.TRAIN)
    """

    # Pod interfaces
    ERROR = "/error"
    WARNING = "/warning"
    INFO = "/info"
    DEBUG = "/debug"
    CRITICAL = "/critical"
    ROUTE = "/route"

    # Common interfaces
    INITIALIZE = "/initialize"
    INITIALIZED = "/initialized"
    COMPLETED = "/completed"
    UPDATE = "/update"
    UPDATED = "/updated"
    FORWARD = "/forward"
    FORWARDED = "/forwarded"
    NOT_FORWARDED = "/not-forwarded"
    LOAD = "/load"
    LOADED = "/loaded"
    FIRE = "/fire"
    IN = "/in"
    OUT = "/out"
    READY = "/ready"
    INPUT = "/input"
    OUTPUT = "/output"
    START = "/start"
    STARTED = "/started"
    STOP = "/stop"
    STOPPED = "/stopped"

    # Arch interfaces
    BROADCAST = "/broadcast"
    BROADCASTED = "/broadcasted"
    MULTICAST = "/multicast"
    MULTICASTED = "/multicasted"
    SUBSCRIBE = "/subscribe"
    SUBSCRIBED = "/subscribed"
    UNSUBSCRIBE = "/unsubscribe"
    UNSUBSCRIBED = "/unsubscribed"
    UPDATE_NUM_CLIENTS = "/update-num-clients"
    UPDATED_NUM_CLIENTS = "/updated-num-clients"
    START_TRAINING = "/start-training"
    STOP_TRAINING = "/stop-training"
    UPDATE_SERVER = "/update-server"
    UPDATE_CLIENT = "/update-client"
    UPDATE_CLIENTS = "/update-clients"
    UPDATED_CLIENTS = "/updated-clients"
    UNSUBSCRIBED_ALL = "/unsubscribed-all"
    UNSUBSCRIBE_MULTICAST = "/unsubscribe-multicast"
    UNSUBSCRIBED_MULTICAST = "/unsubscribed-multicast"
    END_MULTICAST = "/end-multicast"
    ENDED_MULTICAST = "/ended-multicast"
    COMPLETE = "/complete"

    # Aggregator interfaces
    AGGREGATE = "/aggregate"
    AGGREGATED = "/aggregated"
    UPDATE_WEIGHTS = "/update-weights"
    UPDATED_WEIGHTS = "/updated-weights"

    # Logger interfaces
    SEND_DEBUG = "/send-debug"
    SEND_INFO = "/send-info"
    SEND_WARNING = "/send-warning"
    SEND_ERROR = "/send-error"
    SEND_CRITICAL = "/send-critical"

    # Encoder interfaces
    ENCODE = "/encode"
    ENCODED = "/encoded"
    DECODE = "/decode"
    DECODED = "/decoded"

    # Flow interfaces
    SEND = "/send"
    RECV = "/recv"
    TICK = "/tick"
    STORE = "/store"
    STORED = "/stored"
    RETRIEVE = "/retrieve"
    RETRIEVED = "/retrieved"
    FILTER = "/filter"
    FILTERED = "/filtered"
    FINISH = "/finish"
    TERMINATE = "/terminate"
    TURN_ON = "/turn-on"
    TURNED_ON = "/turned-on"
    TURN_OFF = "/turn-off"
    TURNED_OFF = "/turned-off"
    TIMEOUT = "/timeout"
    SEND_OUTPUT = "/send-output"
    UPDATE_COUNT = "/update-count"
    UPDATED_COUNT = "/updated-count"
    DOWNSTREAM = "/downstream"
    UPSTREAM = "/upstream"
    DOCK_0 = "/dock-0"
    DOCK_1 = "/dock-1"
    DOCK_2 = "/dock-2"
    DOCK_X = "/dock-"
    MONITOR = "/monitor"

    # Loader interfaces
    LOAD_DATA = "/load-data"
    LOADED_DATA = "/loaded-data"
    CLEAR = "/clear"
    CLEARED = "/cleared"
    RELOAD = "/reload"
    RELOADED = "/reloaded"
    METADATA = "/metadata"

    # Privacy interfaces
    ADD_NOISE = "/add-noise"
    NOISE_ADDED = "/noise-added"
    GENERATE_SEED = "/generate-seed"
    GENERATED_SEED = "/generated-seed"
    RECEIVE_SEED = "/receive-seed"
    RECEIVED_SEED = "/received-seed"
    RECEIVED_PARAMETERS = "/received-parameters"
    SEND_SEED = "/send-seed"
    REST_RCV_SEED = "/rest/rcv-seed"
    MULTICAST_SEED = "/multicast-seed"

    # Trainer interfaces
    LOAD_MODEL = "/load-model"
    LOADED_MODEL = "/loaded-model"
    LOAD_WEIGHTS = "/load-weights"
    LOADED_WEIGHTS = "/loaded-weights"
    SAVE_MODEL = "/save-model"
    SAVED_MODEL = "/saved-model"
    SAVE_WEIGHTS = "/save-weights"
    SAVED_WEIGHTS = "/saved-weights"
    UPDATE_WEIGHTS = "/update-weights"
    UPDATED_WEIGHTS = "/updated-weights"
    INITIALIZED_MODEL = "/initialized-model"
    TRAIN = "/train"
    TRAINED = "/trained"
    EVALUATE = "/evaluate"
    EVALUATED = "/evaluated"
    PREDICT = "/predict"
    PREDICTED = "/predicted"

    # Selector interfaces
    COMPLETED_ROUND = "/completed-round"
    SELECT = "/select"
    SELECTED = "/selected"
    SELECT_ONE = "/select-one"
    SELECT_BATCH = "/select-batch"

    # Utils interfaces
    HANDSHAKE = "/handshake"
    CLIP = "/clip"
    CLIPPED = "/clipped"

    # Monitoring interfaces
    PING = "/ping"
    PONG = "/pong"
    RECEIVE_PING = "/receive-ping"
    SEND_PING = "/send-ping"
    HEALTHY = "/healthy"
    UNHEALTHY = "/unhealthy"

    # MinIO interfaces
    INIT_MINIO = "/init-minio"
    CREATE_BUCKET = "/create-bucket"
    CREATED_BUCKET = "/created-bucket"
    DELETE_BUCKET = "/delete-bucket"
    DELETED_BUCKET = "/deleted-bucket"
    DOWNLOAD_OBJECT = "/download-object"
    DOWNLOADED_OBJECT = "/downloaded-object"
    DELETE_OBJECT = "/delete-object"
    DELETED_OBJECT = "/deleted-object"
    UPLOAD_OBJECT = "/upload-object"
    UPLOADED_OBJECT = "/uploaded-object"

    # MLflow interfaces
    INIT_MLFLOW = "/init-mlflow"
    CREATE_EXPERIMENT = "/create-experiment"
    CREATED_EXPERIMENT = "/created-experiment"
    CREATE_RUN = "/create-run"
    CREATED_RUN = "/created-run"
    GET_EXPERIMENT_BY_NAME = "/get-experiment-by-name"
    GOT_EXPERIMENT_BY_NAME = "/got-experiment-by-name"
    LOG_PARAM = "/log-param"
    LOGGED_PARAM = "/logged-param"
    LOG_METRIC = "/log-metric"
    LOGGED_METRIC = "/logged-metric"
    LOG_MODEL = "/log-model"
    LOGGED_MODEL = "/logged-model"
    LOG_BATCH = "/log-batch"
    LOGGED_BATCH = "/logged-batch"

    # Prometheus interfaces
    QUERY = "/query"
    QUERIED = "/queried"
    QUERY_RANGE = "/query-range"
    QUERIED_RANGE = "/queried-range"
    GET_METADATA = "/get-metadata"
    GOT_METADATA = "/got-metadata"
    GET_TARGETS = "/get-targets"
    GOT_TARGETS = "/got-targets"
    GET_ALERTS = "/get-alerts"
    GOT_ALERTS = "/got-alerts"
    GET_RULES = "/get-rules"
    GOT_RULES = "/got-rules"
    GET_STATUS_CONFIG = "/get-status-config"
    GOT_STATUS_CONFIG = "/got-status-config"
    GET_STATUS_FLAGS = "/get-status-flags"
    GOT_STATUS_FLAGS = "/got-status-flags"
    GET_RUNTIME_INFO = "/get-runtime-info"
    GOT_RUNTIME_INFO = "/got-runtime-info"

    # Memory interfaces
    IN_0 = "/in-0"
    IN_1 = "/in-1"

    # REST interfaces
    REST_UPDATE_CLIENT = "/rest/update-client"
    REST_UPDATE_SERVER = "/rest/update-server"
    REST_UPDATE_FROM_SERVER = "/rest/update-from-server"
    REST_UPDATE_FROM_CLIENT = "/rest/update-from-client"
    REST_SUBSCRIBE_TO_SERVER = "/rest/subscribe-to-server"
    REST_UNSUBSCRIBE_FROM_SERVER = "/rest/unsubscribe-from-server"
    REST_BROADCAST = "/rest/broadcast"
    REST_MULTICAST = "/rest/multicast"
    REST_DOWNSTREAM = "/rest/downstream"
    REST_UPSTREAM = "/rest/upstream"
    REST_TERMINATE = "/rest/terminate"
    REST_UNSUBSCRIBE_MULTICAST = "/rest/unsubscribe-multicast"
    REST_END_MULTICAST = "/rest/end-multicast"
    REST_PONG_FROM_CLIENT = "/rest/pong-from-client"
    REST_PONG_TO_SERVER = "/rest/pong-to-server"
    REST_PING_FROM_SERVER = "/rest/ping-from-server"
    REST_MONITOR = "/rest/monitor"
    REST_DRIFT_FROM_CLIENT = "/rest/drift-from-client"
    REST_NO_DRIFT_FROM_CLIENT = "/rest/no-drift-from-client"
    POST_FORWARDED = "/post/forwarded"
    POST_BROADCASTED = "/post/broadcasted"

    # Evidently interfaces
    REPORT = "/report"
    REPORTED = "/reported"
    REPORT_DATA_DRIFT = "/report-data-drift"
    REPORTED_DATA_DRIFT = "/reported-data-drift"
    REPORT_DATA_QUALITY = "/report-data-quality"
    REPORTED_DATA_QUALITY = "/reported-data-quality"
    REPORT_TARGET_DRIFT = "/report-target-drift"
    REPORTED_TARGET_DRIFT = "/reported-target-drift"
    REPORT_CLASSIFICATION = "/report-classification"
    REPORTED_CLASSIFICATION = "/reported-classification"
    REPORT_REGRESSION = "/report-regression"
    REPORTED_REGRESSION = "/reported-regression"
    DETECT_DATA_DRIFT = "/detect-data-drift"
    DETECTED_DATA_DRIFT = "/detected-data-drift"
    DETECTED_NO_DATA_DRIFT = "/detected-no-data-drift"
