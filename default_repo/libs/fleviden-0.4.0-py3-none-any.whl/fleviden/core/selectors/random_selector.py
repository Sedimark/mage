# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a selector pod for generating a random subset from a specified list.
"""

import copy
from typing import Union

import numpy as np

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class RandomSelector(Pod):
    """
    A selector pod for generating a random subset of samples from a list/array.

    For example, this pod can be used to select a subset of clients
    to train in a particular federated learning round.

    Create the Selector pod in the server script:
        >>> pod_selector = RandomSelector(size=0.5, entry="clients")

    Then, link the Selector pod to the Server pod when broadcasting (start of a round):
        >>> pod_server.link(Interfaces.BROADCASTED, pod_selector, Interfaces.SELECT)
        >>> pod_selector.link(Interfaces.SELECTED, pod_http, Interfaces.BROADCASTED)

    Finally, update the number of active clients in the Server pod:
        >>> pod_selector.link(Interfaces.SELECTED, pod_server, Interfaces.UPDATE_NUM_CLIENTS)
    """

    def __init__(
        self,
        size: Union[int, float] = 1,
        input_entry: str = "clients",
        output_entry: str = None,
        forward_input: bool = False,
    ):
        """Creates a selector pod.

        Parameters
        ----------
            size : Union[int, float], optional
                Number of elements to select in each batch when triggering the /select wire.
                By default 1. If a float is provided, in range (0, 1), the size will be relative
                to the input list length.

            input_entry : str, optional
                Key in the input request dictionary to generate the subset from,
                by default "clients". If the entry is not a list, an error will be triggered.

            output_entry : str, optional
                Key in the output request dictionary where the selection is sent.
                If None, the input_entry will be used instead, replacing the input value.

            forward_input : bool
                Controls whether the dictionary received in the input wired is forwarded in
                the output wire together with the selected clients, or the pod only outputs
                the selected clients.

        Inputs
        ------
            Interfaces.SELECT (/select)
                Triggers the selection process. The req message can contain a 'size' key
                with the required selection size.

        Outputs
        -------
            Interfaces.SELECTED (/selected)
                A notification containing the selected subset.
        """

        super().__init__()
        self.size = size
        self.input_entry = input_entry
        self.output_entry = output_entry
        self.forward_input = forward_input

        self.register(Interfaces.SELECT, self._select)
        self.register(Interfaces.SELECTED)

    async def _select(self, req: dict) -> None:
        """
        Selects a subset of samples from a given list at req[entry].
        """
        try:
            input_list = req.get(self.input_entry)
            # Assert that the input is a list/array
            if isinstance(input_list, np.ndarray):
                input_list = input_list.tolist()
            if not isinstance(input_list, list):
                error = super()._get_error(
                    "RandomSelectorTypeError",
                    "Entry to select from is not a list or a numpy array.",
                    {"entry": self.input_entry, "type": type(input_list)},
                )
                await self.trigger(Interfaces.ERROR, error)
                return
            # Perform selection
            else:
                if self.forward_input:
                    out_req = copy.deepcopy(req)
                else:
                    out_req = {}

                # Get selection size
                size = req.get("size", self.size)
                if isinstance(size, float):
                    size = np.clip(size, 0, 1)
                    size = max(int(self.size * len(input_list)), 1)

                # Ensure size does not exceed input length
                if size > len(input_list):
                    warning = super()._get_warning(
                        "RandomSelectorSizeWarning",
                        "Size exceeds input list length. Clipping size to input length.",
                        {"requested_size": size, "input_length": len(input_list)},
                    )
                    await self.trigger(Interfaces.WARNING, warning)
                    size = len(input_list)

                # Random selection
                selected = np.random.choice(input_list, size, replace=False).tolist()

                # Update the request with the selected subset
                if self.output_entry is not None:
                    out_req[self.output_entry] = selected
                else:
                    out_req[self.input_entry] = selected

                # Output
                await self.trigger(
                    Interfaces.SELECTED,
                    out_req,
                    info_msg=f"Selected {self.input_entry} for current round: {selected}",
                )

        except OSError as error:
            error_info = super()._get_error(
                "RandomSelectorError",
                "An error occurred while performing the selection.",
                str(error),
            )
            await self.trigger(Interfaces.ERROR, error_info)
