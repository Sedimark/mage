# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a selector pod for generating subsets from a specified list in a
round-robin fashion.
"""

import copy
import random
from typing import Optional, Union

import numpy as np

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class RoundRobinSelector(Pod):
    """
    A selector pod for generating subsets from a list in a round-robin fashion.

    The selection process can be triggered in two ways: either by selecting one element at a time
    with /select-one, or by selecting a batch of elements at once with /select-batch.

    For example, this pod can be used to select a subset of clients to train in a particular
    federated learning round, and then select a different subset in the next round.

    Create a `RoundRobinSelector` pod in the server script:
        >>> selector = RoundRobinSelector(input_entry="clients", random_start=True, size=2)

    Then, link the selector pod to the Server pod when broadcasting (start of a round):
        >>> pod_server.link(Interfaces.BROADCASTED, pod_selector, Interfaces.SELECT_BATCH)
        >>> pod_selector.link(Interfaces.SELECTED, pod_http, Interfaces.BROADCASTED)

    Finally, update the number of active clients in the Server pod:
        >>> pod_selector.link(Interfaces.SELECTED, pod_server, Interfaces.UPDATE_NUM_CLIENTS)
    """

    def __init__(
        self,
        input_entry: str = "clients",
        output_entry: Optional[str] = None,
        random_start: bool = False,
        size: Union[int, float] = 1,
        forward_input: bool = False,
    ):
        """
        Creates a selector pod that generates subsets from a list in a round-robin fashion.

        Parameters
        ----------
            input_entry : str
                Key in the input request dictionary to generate the subset from. By default,
                "clients".

            output_entry : str, optional
                Key in the output request dictionary where the selection is sent.
                If None, the input_entry will be used instead, replacing the input value.

            random_start : bool, optional
                If True, the first selection will be random. Otherwise, the first selection will be
                the first element of the input list. By default False.

            size : Union[int, float], optional
                Number of elements to select in each batch when triggering the /select-batch wire.
                By default 1 (equivalent to /select-one calls). If a float is provided, in range
                (0, 1), the size will be relative of the input list length.

            forward_input : bool, optional
                If True, the input request will be forwarded to the output request. By default
                False.

        Inputs
        ------
            Interfaces.INITIALIZE (/initialize)
                Initializes the selector with the input list.

            Interfaces.SELECT_ONE (/select-one)
                Triggers the selection of the next element.

            Interfaces.SELECT_BATCH (/select-batch)
                Triggers the selection of the next batch of elements.

        Outputs
        -------
            Interfaces.SELECTED (/selected)
                A notification containing the selected subset.

            Interfaces.COMPLETED_ROUND (/completed-round)
                A notification indicating that all the elements have been selected once.
        """

        super().__init__()
        self.input_entry = input_entry
        self.output_entry = output_entry
        self.random_start = random_start
        self.size = size
        self.forward_input = forward_input

        self.input_list = None
        self.input_length = 0
        self.index = 0
        self.initial_index = 0

        self.register(Interfaces.INITIALIZE, self._initialize)

        self.register(Interfaces.SELECT_ONE, self._select_one)
        self.register(Interfaces.SELECT_BATCH, self._select_batch)
        self.register(Interfaces.SELECTED)

        self.register(Interfaces.COMPLETED_ROUND)

    async def _initialize(self, req: dict) -> None:
        """
        Initializes the selector with the input list from the request at the input entry.
        """
        self.input_list = req.get(self.input_entry, None)

        # Check if input is list/np.array
        if isinstance(self.input_list, np.ndarray):
            self.input_list = self.input_list.tolist()
        if not isinstance(self.input_list, list):
            error = super()._get_error(
                "RoundRobinSelectorTypeError",
                "Entry to select from is not a list or a numpy array.",
                {"entry": self.input_entry, "type": type(self.input_list)},
            )
            await self.trigger(Interfaces.ERROR, error)
            self.input_list = None
            return

        self.input_length = len(self.input_list)
        self.index = random.randint(0, self.input_length - 1) if self.random_start else 0
        self.initial_index = self.index

        # Set size relative to input list length if float
        if isinstance(self.size, float):
            self.size = np.clip(self.size, 0, 1)
            self.size = max(int(self.size * self.input_length), 1)

        # Ensure size does not exceed input length
        if self.size > self.input_length:
            warning = super()._get_warning(
                "RoundRobinSelectorSizeWarning",
                "Size exceeds input list length. Clipping size to input length.",
                {"requested_size": self.size, "input_length": self.input_length},
            )
            await self.trigger(Interfaces.WARNING, warning)
            self.size = self.input_length

        if self.output_entry is None:
            self.output_entry = self.input_entry

    async def _select(self, req: dict, num_elements: int) -> None:
        """
        Generic method to select elements from the input list.

        Parameters
        ----------
            req : dict
                Input request dictionary.

            num_elements : int
                Number of elements to select.
        """
        if self.forward_input:
            out_req = copy.deepcopy(req)
        else:
            out_req = {}

        # Perform selection
        if self.input_list is not None:
            selected = []
            for _ in range(num_elements):
                selected.append(self.input_list[self.index])
                self.index = (self.index + 1) % self.input_length
                await self._check_round_completed()

            out_req[self.output_entry] = selected

            await self.trigger(
                Interfaces.SELECTED, out_req, info_msg=f"Selected next {num_elements}: {selected}."
            )

    async def _select_one(self, req: dict) -> None:
        """
        Selects the next element in the list in a round-robin fashion.
        """
        if self.input_list is None:
            await self._initialize(req)
        await self._select(req, 1)

    async def _select_batch(self, req: dict) -> None:
        """
        Selects the next batch of elements in the list in a round-robin fashion.
        """
        if self.input_list is None:
            await self._initialize(req)
        await self._select(req, self.size)

    async def _check_round_completed(self):
        """
        Checks if the round is completed.
        """
        if self.index == self.initial_index:
            await self.trigger(Interfaces.COMPLETED_ROUND, {})
