# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

import numpy as np
from numpy.typing import NDArray

from fleviden.core.interfaces.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class ClipNormalization(Pod):
    """
    A pod to perform gradient clipping normalization to prevent exploding gradients.

    The implementation is based on the techniques discussed in the
    paper: Pan Y, Ni J, Su Z. FL-PATE: Differentially Private Federated Learning with
    Knowledge Transfer. IEEE Global Communications Conference (GLOBECOM). 2021. DOI:
    10.1109/GLOBECOM46510.2021.9685079.

    This function is part of a federated learning framework (FL-PATE) that aims to enhance
    data privacy through knowledge transfer. Specifically, the function implements a mechanism
    to clip the gradients of local model updates based on their norms to prevent data leakage
    and ensure more robust updates. The gradients are normalized using a median-based threshold.
    This technique helps maintain the integrity of local updates while allowing the global model
    to be updated effectively without directly addressing differential privacy.
    """

    def __init__(self):
        """
        Creates a ClipNormalization pod.

        Inputs
        ------
            Interfaces.CLIP (/clip)
                A request to clip the gradients of a model update.

        Outputs
        -------
            Interfaces.CLIPPED (/clipped)
                Triggered with the result of the clipping operation.
        """
        super().__init__()

        self.register(Interfaces.CLIP, self._clip)
        self.register(Interfaces.CLIPPED)

    async def _clip(self, req: dict) -> None:
        """Performs gradient clipping normalization."""
        gradients = req.get("gradients", None)
        if gradients is None:
            error = {
                "name": "ClipNormValueError",
                "description": "No gradients provided for clip normalization. Bypassing request.",
                "details": list(req.keys()),
            }
            await self.trigger(Interfaces.ERROR, error)
            await self.trigger(Interfaces.CLIPPED, req)
        else:
            clipped_gradients, clip_value = clip_normalization(gradients)

            await self.trigger(
                Interfaces.CLIPPED, {"gradients": clipped_gradients, "clip_value": clip_value}
            )


def clip_normalization(gradients: NDArray) -> tuple[NDArray, float]:
    """
    Performs gradient clipping normalization for all participating clients in a federated learning
    environment.

    Parameters
    ----------
        gradients : NDArray
            The local gradients from different clients, shape (num_clients, num_weights).

    Returns
    -------
        tuple[NDArray, float]
            The adjusted local weights, shape (num_clients, num_weights), and the clip value used.
    """
    # Calculate the norms of the gradients
    norms = np.linalg.norm(gradients, axis=1)

    # Calculate the clipping value
    clip_value = max(np.median(norms), np.finfo(float).eps)

    # Clip the gradients
    scaling_factors = np.maximum(1, norms / clip_value).reshape(-1, 1)
    clipped_gradients = gradients / scaling_factors

    return clipped_gradients, clip_value
