# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements the Gaussian mechanism for Differential Privacy in Federated Learning.

Reference:
Pan, Y., Ni, J., & Su, Z. (2021). FL-PATE: Differentially Private Federated Learning with Knowledge
Transfer. In 2021 IEEE Global Communications Conference (GLOBECOM) (pp. 1-6). IEEE.
https://doi.org/10.1109/GLOBECOM46510.2021.9685079
"""

from typing import Dict, Optional, Tuple, Union

import numpy as np

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod
from fleviden.core.validation.privacy.gaussian_noise_validation import (
    GaussianNoiseValidation as val,
)


class GaussianNoise(Pod):
    """
    A pod to add Gaussian noise to model parameters for differential privacy.

    The noise is determined by the differential privacy parameters delta and epsilon, and
    optionally a sensitivity value.

        std_dev = sensitivity * sqrt(2 * log(1.25 / delta)) / epsilon

    If sensitivity is not provided but clip_value is given due to clip normalization being applied,
    then the Sensitivity (S) is calculated as S = 2*C/num_clients. Otherwise, S is calculated as
    S = 2/num_clients.
    """

    def __init__(
        self,
        delta: float,
        epsilon: float,
        sensitivity: Optional[float] = None,
        percentage: float = 1.0,
    ):
        """
        Initializes the GaussianNoise Pod.

        Parameters
        ----------
            delta : float
                Delta parameter for differential privacy, indicating the probability of privacy
                failure.

            epsilon : float
                Epsilon parameter for differential privacy, indicating the privacy cost. Lower
                values mean stronger privacy.

            sensitivity : float, optional
                The sensitivity of the function being differentially private. If not provided, it
                will be calculated as 2*C/num_clients if a clip normalization has been applied
                (i.e., a clip_value has been calculated and received), and as S=2/num_clients
                otherwise.  Note that S is upper bounded by 2*C/num_clients with clip normalization
                applied, and by 2/num_clients otherwise. Defaults to None.

            percentage : float, optional
                The percentage of values to apply noise to, starting from the end of the vector.
                Defaults to 1.0 (all vector). For example, if set to 0.4, only the last 40% of
                values will have noise applied. This is useful for applying noise to only a subset
                of the weights from the last layers of a model. This value is automatically clipped
                between 0 and 1.

        Inputs
        ------
            Interfaces.ADD_NOISE (/add-noise)
                Adds Gaussian noise to the weights/gradients provided in the request.

        Outputs
        -------
            Interfaces.NOISE_ADDED (/noise-added)
                Triggered after adding noise to the weights/gradients.
        """
        super().__init__()
        self.delta = delta
        self.epsilon = epsilon
        self.sensitivity = sensitivity
        self.percentage = percentage
        self.mode = "gradients"

        self.register(
            Interfaces.ADD_NOISE,
            self._add_gaussian_noise,
            schema=val.AddGaussianNoise,
        )
        self.register(Interfaces.NOISE_ADDED)

    async def _add_gaussian_noise(self, req: Dict) -> None:
        """
        Adds Gaussian noise to the weights provided in the request.

        Parameters
        ----------
        req : dict
            Request dictionary containing:
                - weights or gradients (List[float]): to which noise will be added.
                - num_clients (int): Number of clients connected to the server.
                - clip_value (float, optional): The clipping value used to scale the noise. If None,
                  noise is generated using only std_dev.
                - completed (bool, optional): Indicates if the federated process is finished.
                  Defaults to False.
        """
        if "weights" in req:
            parameters = np.array(req["weights"])
            self.mode = "weights"
        elif "gradients" in req:
            parameters = np.array(req["gradients"])
            self.mode = "gradients"

        num_clients = np.array(req["num_clients"])
        clip_value = req.get("clip_value")
        completed = req.get('completed', False)

        noise = await self._generate_noise(parameters.shape, num_clients, clip_value)
        noise = self._mask_vector_on_percentage(noise, self.percentage)
        noisy_parameters = parameters + noise

        await self._trigger_completion(noisy_parameters, completed)

    async def _generate_noise(
        self, shape: Tuple[int], num_clients: int, clip_value: Union[float, None]
    ) -> np.ndarray:
        """
        Generates Gaussian noise based on the provided parameters.

        Parameters
        ----------
            shape : tuple
                Shape of the parameters array.

            num_clients : int
                Number of clients.

            clip_value : Union[float, None]
                Clipping value used to scale the noise.

        Returns
        -------
            np.ndarray
                Array of Gaussian noise.
        """
        # Determine sensitivity based on provided clip_value and sensitivity
        sensitivity = await self._calculate_sensitivity(num_clients, clip_value)

        # Calculate standard deviation for Gaussian noise
        std_dev = self._calculate_std_dev(sensitivity)

        # Check and bound the standard deviation if necessary
        std_dev = await self._check_and_bound_std_dev(std_dev, num_clients, clip_value)

        # Generate Gaussian noise
        if clip_value is not None:
            return np.random.normal(0, std_dev * clip_value, size=shape)
        else:
            return np.random.normal(0, std_dev, size=shape)

    async def _calculate_sensitivity(
        self, num_clients: int, clip_value: Union[float, None]
    ) -> float:
        """
        Calculates the sensitivity based on the provided clip_value and number of clients.

        Parameters
        ----------
            num_clients : int
                Number of clients.

            clip_value : Union[float, None]
                Clipping value used to scale the noise.

        Returns
        -------
            float
                The calculated sensitivity.
        """
        if self.sensitivity is not None:
            return self.sensitivity

        sensitivity = self.calculate_upper_bound_sensitivity(num_clients, clip_value)
        await self.trigger(Interfaces.WARNING, self._get_max_sensitivity_warning())
        return sensitivity

    def _calculate_std_dev(self, sensitivity: float) -> float:
        """
        Calculates the standard deviation for Gaussian noise.

        Parameters
        ----------
            sensitivity : float
                The sensitivity value used for the calculation.

        Returns
        -------
            float
                The calculated standard deviation.
        """
        return sensitivity * np.sqrt(2 * np.log(1.25 / self.delta)) / self.epsilon

    def _mask_vector_on_percentage(self, vector: list, percentage: float):
        """Applies a mask to a vector such that the first `1-percentage`
        elements are zeroed out. That is to say, only the last `percentage`
        of values are kept.

        Parameters
        ----------
            vector : list
                A vector of values.

            percentage : float
                The percentage of values to keep, starting from the end of the vector.
        """
        percentage = max(0, min(percentage, 1))

        mask = np.ones(len(vector))
        mask[0 : int(len(vector) * (1 - percentage))] = 0

        return mask * vector

    async def _check_and_bound_std_dev(
        self, std_dev: float, num_clients: int, clip_value: Union[float, None]
    ) -> float:
        """
        Checks if the standard deviation is higher than the bounded standard deviation using
        the maximum sensitivity. If it is, the standard deviation is bounded and a warning is
        triggered.

        Parameters
        ----------
            std_dev : float
                The standard deviation to be checked.

            num_clients : int
                Number of clients.

            clip_value : Union[float, None]
                Clipping value used to scale the noise.

        Returns
        -------
            float
                The bounded standard deviation.
        """
        bounded_sensitivity = self.calculate_upper_bound_sensitivity(num_clients, clip_value)
        bounded_std_dev = self._calculate_std_dev(bounded_sensitivity)

        if std_dev > bounded_std_dev:
            await self.trigger(
                Interfaces.WARNING, self._get_std_dev_bound_warning(std_dev, bounded_std_dev)
            )
            std_dev = bounded_std_dev

        return std_dev

    def calculate_upper_bound_sensitivity(
        self, num_clients: int, clip_value: Union[float, None]
    ) -> float:
        """
        Calculates the upper bound of sensitivity based on the number of clients and the clip value.

        Parameters
        ----------
            num_clients : int
                Number of clients.

            clip_value : Union[float, None]
                Clipping value used to scale the noise.

        Returns
        -------
            float
                The calculated upper bound of sensitivity.
        """
        if clip_value is not None:
            return 2 * clip_value / num_clients
        else:
            return 2 / num_clients

    async def _trigger_completion(self, noisy_parameters: np.ndarray, completed: bool) -> None:
        """
        Triggers the appropriate event based on the completion status.

        Parameters
        ----------
            noisy_parameters : np.ndarray
                The arameters after adding noise.

            completed : bool
                Whether the aggregation process is completed.
        """
        if completed:
            await self.trigger(
                Interfaces.COMPLETED,
                {self.mode: noisy_parameters.tolist(), "completed": True},
                info_msg="Noise added (completed)",
            )
        else:
            await self.trigger(
                Interfaces.NOISE_ADDED,
                {self.mode: noisy_parameters.tolist()},
                info_msg="Noise added",
            )

    def _get_std_dev_bound_warning(self, std_dev: float, bounded_std_dev: float) -> Dict:
        """
        Creates a warning message when the standard deviation is bounded.
        """
        name = "StdDevBoundWarning"
        description = (
            f"Standard deviation {std_dev} is too high based on provided sensitivity and has been "
            f"bounded to {bounded_std_dev} to ensure privacy (see Pod documentation for details)."
        )
        details = ""
        return super()._get_warning(name, description, details)

    def _get_max_sensitivity_warning(self) -> Dict:
        """
        Creates a warning message when the standard deviation is calculated using the maximum
        sensitivity.
        """
        name = "StdDevMaxSensitivityWarning"
        description = "Sensitivity is not provided; std_dev calculated using maximum sensitivity."
        details = ""
        return super()._get_warning(name, description, details)
