# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a logger than can print and save messages with different
levels of criticality.
"""
import json
import logging
import os
from datetime import datetime
from typing import Optional, Union

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Logger(Pod):
    """
    The Logger can send messages through the standard output and
    save them in a log.
    """

    def __init__(
        self,
        level: str = "debug",
        console: bool = True,
        path: Optional[str] = None,
        indent: int = None,
    ):
        """
        Logger constructor.

        Parameters
        ----------
            level : str
                Logger level. Supported: debug, info,
                error, warning, critical.

            console : bool
                If True, the logger will print the
                messages via console.

            path : str
                Path to the folder where to save the
                log.

            indent : int
                Number of spaces to indent the log.

        Inputs
        ------
            Interfaces.SEND_DEBUG (/send-debug)
                A request to send a debug message.

            Interfaces.SEND_INFO (/send-info)
                A request to send an info message.

            Interfaces.SEND_WARNING (/send-warning)
                A request to send a warning message.

            Interfaces.SEND_ERROR (/send-error)
                A request to send an error message.

            Interfaces.SEND_CRITICAL (/send-critical)
                A request to send a critical message.
        """
        super().__init__()

        self.indent = indent

        self.logger = logging.getLogger(__name__)
        self.level = self._get_logger_level(level)
        self.logger.setLevel(self.level)
        self.logger.propagate = False

        # Formatter
        formatter = logging.Formatter('%(levelname)s : %(message)s')

        # Console handler
        if console:
            if not self.logger.hasHandlers():
                console_handler = logging.StreamHandler()
                console_handler.setLevel(self.level)
                console_handler.setFormatter(formatter)
                self.logger.addHandler(console_handler)

        # File handler
        if path is not None:
            os.makedirs(path, exist_ok=True)
            now = datetime.now()
            now = now.strftime("%Y_%m_%d_%H%M")
            output = f'{path}/{now}.log'
            file_handler = logging.FileHandler(output)
            file_handler.setLevel(logging.DEBUG)
            file_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)

        # Interfaces
        self.register(Interfaces.SEND_DEBUG, self.debug)
        self.register(Interfaces.SEND_INFO, self.info)
        self.register(Interfaces.SEND_WARNING, self.warning)
        self.register(Interfaces.SEND_ERROR, self.error)
        self.register(Interfaces.SEND_CRITICAL, self.critical)

    def _get_logger_level(self, level_str: str):
        """
        Retrieves the level from the logging module according to a string.

        Supported inputs are: "debug", "info", "warning", "error" and "critical",
        corresponding with the homonymous logging levels.

        Parameters
        ----------
            level_str : str
                Name of a logging level.
        Returns
        --------
            level : logging level
                Corresponding level in the logging module.
        """

        if level_str == "debug":
            level = logging.DEBUG
        elif level_str == "info":
            level = logging.INFO
        elif level_str == "error":
            level = logging.ERROR
        elif level_str == "warning":
            level = logging.WARNING
        elif level_str == "critical":
            level = logging.CRITICAL

        return level

    async def debug(self, msg: Union[str, dict]):
        """
        Logs a message at DEBUG level.

        Parameters
        ----------
            msg : Union[str, dict]
                Message.
        """
        self.logger.debug(json.dumps(msg, indent=self.indent))

    async def info(self, msg: Union[str, dict]):
        """
        Logs a message at INFO level.

        Parameters
        ----------
            msg : Union[str, dict]
                Message.
        """
        self.logger.info(json.dumps(msg, indent=self.indent))

    async def warning(self, msg: Union[str, dict]):
        """
        Logs a message at WARNING level.

        Parameters
        ----------
            msg : Union[str, dict]
                Message.
        """
        self.logger.warning(json.dumps(msg, indent=self.indent))

    async def error(self, msg: Union[str, dict]):
        """
        Logs a message at ERROR level.

        Parameters
        ----------
            msg : Union[str, dict]
                Message.
        """
        self.logger.error(json.dumps(msg, indent=self.indent))

    async def critical(self, msg: Union[str, dict]):
        """
        Logs a message at CRITICAL level.

        Parameters
        ----------
            msg : Union[str, dict]
                Message.
        """
        self.logger.critical(json.dumps(msg, indent=self.indent))
