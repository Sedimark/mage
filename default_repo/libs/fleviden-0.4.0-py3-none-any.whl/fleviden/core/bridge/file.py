# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module provides the implementation for a link that connects pods via the filesystem.
"""

import asyncio
import json
import os

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class File(Pod):
    """This class allows to connect a pod to another pod via a file."""

    def __init__(self, origin: str):
        """Creates a new file bridge pod.

        Parameters
        ----------
            origin : str
                Identifier of the source name attached to all bridged messages.

        Inputs
        ------
            Interfaces.LOAD (/load)
                A request to load a file containing messages.

        Outputs
        -------
            Interfaces.FIRE (/fire)
                A notification that a message has been loaded.
        """
        super().__init__()
        self.__check_params(origin)
        self.__origin = origin
        self.__sources = []
        self.register(Interfaces.LOAD, self.__load)
        self.register(Interfaces.FIRE)

    def __check_params(self, origin: str) -> None:
        """Checks that the parameters given to the pod are correct."""
        assert isinstance(origin, str)

    def wait(self, path: str, remove: bool = True) -> None:
        """Registers a new file containing messages to be loaded.

        Parameters
        ----------
            path: str
                A file path to the filesystem.

            remove: bool
                Wheter to remove the file after reading all messages.
        """
        self.__sources.append({'path': path, 'remove': remove})

    async def _on_start(self):
        """Loads the registered files and trigger the appropiate output wire."""
        sources = [
            self.trigger(Interfaces.LOAD, {'path': source.path, 'remove': source.remove})
            for source in self.__sources
        ]
        await asyncio.gather(*sources)

    def bridge(self, route: str, path: str) -> None:
        """Dumps all messages sent through the specified wire to the specified file.

        Parameters
        ----------
            route: str
                The local output wire to bridge.

            path: str
                The file name where to write the messages.
        """
        self.register(route, self.__get_bridge(path))

    async def __load(self, req: dict):
        await self.__fsload(req)
        await self.__remove(req)

    async def __fsload(self, req: dict):
        """Loads a file from the file system. Each line must be a valid JSON.
        The path must be given in the req.
        """
        path = req["path"]
        try:
            file = open(path, 'r', encoding='UTF-8')
            for line in file:
                req = json.loads(line)
                await self.trigger(Interfaces.FIRE, req)
        except json.JSONDecodeError as exception:
            error = self.__get_format_error(exception, path)
            await self.trigger(Interfaces.ERROR, error)
        except IOError as exception:
            error = self.__get_io_error(exception, path)
            await self.trigger(Interfaces.ERROR, error)
        except Exception as exception:
            error = self.__get_unk_error(exception, path)
            await self.trigger(Interfaces.ERROR, error)
        finally:
            file.close()

    async def __remove(self, req: dict):
        """Removes a file from the file system. The path must be given in the req."""
        path = req["path"]
        remove = bool(req["remove"])
        if remove:
            try:
                os.remove(path)
            except FileNotFoundError as exception:
                warning = self.__get_nf_warning(exception, path)
                await self.trigger(Interfaces.WARNING, warning)
            except OSError as exception:
                warning = self.__get_dir_warning(exception, path)
                await self.trigger(Interfaces.WARNING, warning)
            except Exception as exception:
                warning = self.__get_unk_warning(exception, path)
                await self.trigger(Interfaces.WARNING, warning)

    def __get_bridge(self, path: str) -> callable:
        """Returns a function callback that manages incoming messages to be
        written in the file system.
        """

        async def bridge(req):
            req['origin'] = self.__origin
            await self.__fswrite(path, req)

        return bridge

    async def __fswrite(self, path: str, req: dict) -> None:
        """Writes a serialized version of the request in a file at the specified path."""
        try:
            file = open(path, 'a', encoding='UTF-8')
            json.dump(req, file)
            file.write('\n')
        except IOError as exception:
            error = self.__get_io_error(exception, path)
            await self.trigger(Interfaces.ERROR, error)
        except Exception as exception:
            error = self.__get_unk_error(exception, path)
            await self.trigger(Interfaces.ERROR, error)
        finally:
            file.close()

    def __get_format_error(self, error, path) -> dict:
        name = "FileFormatError"
        description = "You tried to load a file but the format is not a valid JSON object."
        details = {"error": error, "path": path}
        return super()._get_error(name, description, details)

    def __get_io_error(self, error, path) -> dict:
        name = "FileError"
        description = "You tried to use a file but an IOError was raised. Check the open docs."
        details = {"error": error, "path": path}
        return super()._get_error(name, description, details)

    def __get_unk_error(self, error, path) -> dict:
        name = "UnknownFileError"
        description = "Something unknown happened while using the file."
        details = {"error": error, "path": path}
        return super()._get_error(name, description, details)

    def __get_nf_warning(self, warning, path) -> dict:
        name = "UnableToRemoveNotExists"
        description = (
            "A message that was received by this interface was readed but it was not possible to"
            " remove it due to it not longer exists."
        )
        details = {"warning": warning, "path": path}
        return super()._get_warning(name, description, details)

    def __get_dir_warning(self, warning, path) -> dict:
        name = "UnableToRemoveIsDir"
        description = (
            "A message that was received by this interface was readed but it refers to a directory"
            " instead of a file at the moment of removal."
        )
        details = {"warning": warning, "path": path}
        return super()._get_warning(name, description, details)

    def __get_unk_warning(self, warning, path) -> dict:
        name = "UnableToRemoveUnknownReason"
        description = (
            "An unknown error prevented the removal of the received file. This may happen due to a"
            " platform dependant error, e.g. removing an already open file in Windows or"
            " insuficient permisions."
        )
        details = {"warning": warning, "path": path}
        return super()._get_warning(name, description, details)
