# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module provides the implementation for a generic HTTP client that can be used to interact
with any REST API.
"""

from typing import Optional

import aiohttp

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class External(Pod):
    """
    A class to interact with any REST API, extending the Pod class.

    This class provides methods to make HTTP requests and handle responses in a generalized way.
    """

    def __init__(self, base_url: str, timeout_ms: int = 10000, max_size_mb: int = 20):
        """
        Initializes the External client.

        Parameters
        ----------
            base_url : str
                The base URL for the REST API.

            timeout_ms : int
                The number of milliseconds to wait for an HTTP response.

            max_size_mb : int
                Maximum size of the responses, in MB.
        """
        super().__init__()
        self.base_url = base_url
        self.timeout = timeout_ms / 1000  # Convert milliseconds to seconds
        self.max_size_bytes = max_size_mb * 1024 * 1024  # From MB to bytes
        self.session = None

    async def _create_session(self):
        if self.session is None:
            self.session = aiohttp.ClientSession(conn_timeout=self.timeout)

    async def _close_session(self):
        if self.session is not None:
            await self.session.close()
            self.session = None

    async def _request(self, method: str, endpoint: str, return_response_data: bool, **kwargs):
        """
        A helper method to make HTTP requests.

        Parameters
        ----------
            method : str
                The HTTP method to use (GET, POST, PUT, DELETE).
            endpoint : str
                The endpoint to send the request to.
            return_response_data : bool
                Whether to return the raw response data or to parse it as JSON.
            kwargs : dict
                Additional parameters to pass to the aiohttp request.
        """
        url = self.base_url + endpoint
        async with self.session.request(method, url, **kwargs) as response:
            status = response.status

            # Successful request
            if status >= 200 and status < 300:
                if return_response_data:
                    return await response.read()
                try:
                    return await response.json()
                except Exception:
                    text = await response.text()
                    return {"response": text}

            # Error
            else:
                try:
                    response_error = await response.json()
                except Exception:
                    text = await response.text()
                    response_error = {"response": text}

                error = super()._get_error(
                    "HTTPRequestError",
                    " The HTTP request was not successful.",
                    {"status": status, **response_error},
                )

                await self.trigger(Interfaces.ERROR, error)
                return error

    async def get(
        self, endpoint: str, params: Optional[dict] = None, return_response_data=False, **kwargs
    ) -> dict:
        """
        Sends a GET request to the API.

        Parameters
        ----------
            endpoint : str
                The endpoint to send the GET request to.
            params : dict, optional
                Query parameters to include in the request.
            return_response_data : bool
                Whether to return the raw response data or to parse it as JSON. Default is False.
            kwargs : dict
                Additional parameters to pass to the aiohttp request.

        Returns
        -------
            dict
                The JSON response from the server.
        """
        await self._create_session()

        return await self._request(
            'GET', endpoint, params=params, return_response_data=return_response_data, **kwargs
        )

    async def post(
        self, endpoint: str, json: Optional[dict] = None, return_response_data=False, **kwargs
    ) -> dict:
        """
        Sends a POST request to the API.

        Parameters
        ----------
            endpoint : str
                The endpoint to send the POST request to.
            json : dict, optional
                The JSON payload to include in the request.
            return_response_data : bool
                Whether to return the raw response data or to parse it as JSON. Default is False.
            kwargs : dict
                Additional parameters to pass to the aiohttp request.

        Returns
        -------
            dict
                The JSON response from the server.
        """
        await self._create_session()

        return await self._request(
            'POST', endpoint, json=json, return_response_data=return_response_data, **kwargs
        )

    async def put(
        self, endpoint: str, json: Optional[dict] = None, return_response_data=False, **kwargs
    ) -> dict:
        """
        Sends a PUT request to the API.

        Parameters
        ----------
            endpoint : str
                The endpoint to send the PUT request to.
            json : dict, optional
                The JSON payload to include in the request.
            return_response_data : bool
                Whether to return the raw response data or to parse it as JSON. Default is False.
            kwargs : dict
                Additional parameters to pass to the aiohttp request.

        Returns
        -------
            dict
                The JSON response from the server.
        """
        await self._create_session()

        return await self._request(
            'PUT', endpoint, json=json, return_response_data=return_response_data, **kwargs
        )

    async def delete(
        self, endpoint: str, json: Optional[dict] = None, return_response_data=False, **kwargs
    ) -> dict:
        """
        Sends a DELETE request to the API.

        Parameters
        ----------
            endpoint : str
                The endpoint to send the DELETE request to.
            json : dict, optional
                The JSON payload to include in the request.
            return_response_data : bool
                Whether to return the raw response data or to parse it as JSON. Default is False.
            kwargs : dict
                Additional parameters to pass to the aiohttp request.

        Returns
        -------
            dict
                The JSON response from the server.
        """
        await self._create_session()

        return await self._request(
            'DELETE', endpoint, json=json, return_response_data=return_response_data, **kwargs
        )

    async def head(self, endpoint: str, return_response_data=False, **kwargs) -> dict:
        """
        Sends a HEAD request to the API.

        Parameters
        ----------
            endpoint : str
                The endpoint to send the HEAD request to.
            return_response_data : bool
                Whether to return the raw response data or to parse it as JSON. Default is False.
            kwargs : dict
                Additional parameters to pass to the aiohttp request.

        Returns
        -------
            dict
                The JSON response from the server.
        """
        await self._create_session()

        return await self._request(
            'HEAD', endpoint, return_response_data=return_response_data, **kwargs
        )

    async def on_start(self):
        """
        Initializes the aiohttp client session.
        """
        await self._create_session()

    async def on_end(self):
        """
        Closes the HTTP session.
        """
        await self._close_session()
