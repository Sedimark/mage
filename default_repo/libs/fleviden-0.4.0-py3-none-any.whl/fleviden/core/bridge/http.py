# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module provides the implementation for a bridge that connects pods
via the HTTP protocol.
"""

import asyncio
import ssl
import time
from typing import Optional

import aiohttp
from aiohttp import web
from aiohttp.client_exceptions import ClientConnectionError

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class HTTP(Pod):
    """This class allows to connect two pods via HTTP.

    The Pod acts as a web server and as a client at the same time.

    You can link any wire to the HTTP pod using the `Pod.link()` method. Afterwards,
    you can `HTTP.bridge()` the connected wire by specifying a host, endpoint and port in the
    target machine.

    In the target machine, you can `HTTP.wait()` any HTTP request by specifying an
    endpoint and an output wire.
    """

    def __init__(
        self,
        origin: str,
        port: int = 80,
        port_https: int = 443,
        timeout: int = 5000,
        max_size_mb: int = 200,
        max_retries: int = 5,
        retry_delay_seconds: int = 10,
        tls_flag: bool = False,
        cafile: Optional[str] = None,
        certfile: Optional[str] = None,
        keyfile: Optional[str] = None,
    ):
        """
        Creates a new HTTP pod.

        Parameters
        ----------
            origin: str
                Must contain an id entry identifying the source name attached to
                all bridged messages.

            port: int
                The TCP port to listen for requests.

            port_https: int
                The TCP port to listen for secure requests.

            timeout: int
                The number of milliseconds to wait for an HTTP response.

            max_size_mb: int
                Maximum size of the requests, in MB.

            max_retries: int
                Maximum number of retries before triggering an error when the HTTP
                connection fails.

            retry_delay_seconds: int
                Number of seconds to wait before retrying the connection.

            tls_flag: bool
                To activate Transport Layer Security. If True, cafile, certfile and keyfile
                must be provided.

            cafile: str
                Path to the CA File for TLS connection.

            certfile: str
                Path to the Certfile for the TLS connection.

            keyfile: str
                Path to the Keyfile for the TLS connection.
        """
        super().__init__()
        self.__check_params(origin, port, timeout)
        self.__origin = origin
        self.__port = port
        self.__port_https = port_https
        self.__timeout = timeout
        self.__max_size_bytes = max_size_mb * 1024 * 1024  # From MB to bytes
        self.__app = web.Application(client_max_size=self.__max_size_bytes)
        self.__client_session = None
        self.__runner = None
        self.__retry = 0
        self.__max_retries = max_retries + 1
        self.__retry_delay_seconds = retry_delay_seconds
        self.__tls_flag = tls_flag
        self.__cafile = cafile
        self.__certfile = certfile
        self.__keyfile = keyfile

    def bridge_multicast(
        self,
        input: str = Interfaces.INPUT,
        output: str = Interfaces.OUTPUT,
        endpoint: str = Interfaces.REST_MULTICAST,
        verb: str = 'post',
    ) -> None:
        """
        Registers the interfaces to multicast data to a subset of clients to the
        target endpoint using the specified HTTP verb.

        Parameters
        ---------
            input : str
                The input wire to register.

            output : str
                The output wire to be triggered.

            endpoint : str
                The target machine endpoint name.

            verb : str
                The HTTP verb used to send the request. Must be 'get', 'post', 'put', or 'delete'.
        """
        assert verb in ['get', 'post', 'put', 'delete']
        self.register(input, self.__multicast_callback(endpoint, verb, output))
        self.register(output)

    def __multicast_callback(self, endpoint: str, verb: str, output: str):
        """
        Returns a function callback that manages incoming HTTP requests.

        The callback basically obtains the target client from the req dictionary, sends the request
        to all of them, and triggers the pod output wire with the captured message.

        Parameters
        ----------
            endpoint : str
                The target machine endpoint name.

            verb : str
                The HTTP verb used to send the request. Must be 'get', 'post', 'put', or 'delete'.

            output : str
                The name of the output wire to be triggered in the HTTP pod.

        Returns
        -------
            multicast : callable
                The callback function that sends the HTTP request only to the 'clients' in the req dict.
        """

        async def multicast(req: dict) -> None:
            clients = req.get("clients", None)
            if clients is None:
                warning = super()._get_warning(
                    "HTTPClientSelectionWarning",
                    "Impossible to multicast because no client has been selected.",
                    "",
                )
                await self.trigger(Interfaces.WARNING, warning)
            else:
                for client in clients:
                    host = f"https://{client}" if self.__tls_flag else f"http://{client}"
                    url = host + endpoint
                    req['origin'] = self.__origin
                    await self._send_http_request(verb, url, req)
            await self.trigger(output, req)

        return multicast

    def __check_params(self, origin: str, port: int, timeout: int) -> None:
        """
        Checks that the parameters given to the HTTP pod are correct.

        Parameters
        ----------
            origin: dict
                Must contain an id entry identifying the source name attached to
                all bridged messages.

            port: int
                The TCP port to listen for requests.

            timeout: int
                The number of milliseconds to wait for an HTTP response.
        """
        assert isinstance(origin, str)
        assert isinstance(port, int)
        assert isinstance(timeout, int)

    def wait(self, wire: str, verb: str = 'post', wait_callback: Optional[callable] = None) -> None:
        """
        Registers an HTTP endpoint.

        Parameters
        ----------
            wire : str
                The name of the HTTP endpoint and output wire triggered when a request is received.

            verb : str
                The HTTP verb used to listen. Must be 'get', 'post', 'put', or 'delete'.

            wait_callback: callable, optional
                Callback function triggered when a request is received. If None is provided,
                a function that extracts the payload and triggers the output wire is called.
        """
        assert verb in ['get', 'post', 'put', 'delete']
        self.register(wire)
        if wait_callback is None:
            wait_callback = self.__wait_callback(wire)

        if verb == 'get':
            route = web.get(wire, wait_callback)
        elif verb == 'post':
            route = web.post(wire, wait_callback)
        elif verb == 'put':
            route = web.put(wire, wait_callback)
        elif verb == 'delete':
            route = web.delete(wire, wait_callback)
        self.__app.add_routes([route])

    def __wait_callback(self, wire: str) -> callable:
        """
        Returns a function callback that manages incoming HTTP requests.

        The callback basically extracts the JSON payload and then triggers the pod
        output wire with the captured message.

        Parameters
        ----------
            wire : str
                The name of the HTTP endpoint and output wire triggered when a request is received.

        Returns
        -------
            callback : callable
                The callback function.
        """

        async def callback(req):
            req = await req.json()
            asyncio.create_task(self.trigger(wire, req))
            return web.json_response({"status": 200})

        return callback

    def bridge(
        self, route: str, host: str, endpoint: str, verb: str = 'post', notify: Optional[str] = None
    ) -> None:
        """
        Creates a bridge for all messages received in the specified route to the
        target host and endpoint using the specified HTTP verb.

        Parameters
        ---------
            route : str
                The local output wire to bridge.

            host : str
                The hostname of the target machine.

            endpoint : str
                The target machine endpoint name.

            verb : str
                The HTTP verb used to send the request. Must be 'get', 'post', 'put', or 'delete'.

            notify : str, optional
                The pod output interface that gets triggered once a successful
                response is received from the server. Default value None means that
                no output interface is triggered.
        """
        assert verb in ['get', 'post', 'put', 'delete']
        self.register(route, self.__bridge_callback(host, endpoint, verb, notify))

    def __bridge_callback(
        self, host: str, endpoint: str, verb: str, notify: Optional[str]
    ) -> callable:
        """
        Returns a function callback that manages messages sent through
        an input wire that are to be forwarded to the specified host and endpoint.
        """
        if notify is not None:
            self.register(notify)

        async def callback(req):
            url = host + endpoint
            req['origin'] = self.__origin
            await self._send_http_request(verb, url, req, notify)

        return callback

    async def on_start(self):
        if self.__client_session is None:
            client_ssl_context = None
            if self.__tls_flag:
                client_ssl_context = self.create_ssl_context(is_client=True)
            self.__client_session = aiohttp.ClientSession(
                connector=aiohttp.TCPConnector(ssl_context=client_ssl_context)
            )
        if self.__runner is None:
            ssl_context = None
            port = self.__port
            if self.__tls_flag:
                await self.trigger("/info", {"HTTP": "TLS enabled for HTTPS communication"})
                ssl_context = self.create_ssl_context(is_client=False)
                port = self.__port_https
        self.__runner = aiohttp.web.AppRunner(self.__app)
        await self.__runner.setup()

        site = aiohttp.web.TCPSite(self.__runner, port=port, ssl_context=ssl_context)
        await site.start()

    async def on_end(self) -> None:
        """
        Releases resources associated to the aiohttp client session and runner.
        """
        await self.__runner.cleanup()
        await self.__client_session.close()

    def create_ssl_context(self, is_client=True) -> ssl.SSLContext:
        """Create a SSL context for the client-side authentication and load certificate and key.

        Returns
        -------
            ssl_context
                Configured SSL context.
        """

        if is_client:
            ssl_context = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile=self.__cafile)
        else:
            ssl_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)

        ssl_context.load_cert_chain(
            certfile=self.__certfile,
            keyfile=self.__keyfile,
            password=None,
        )
        ssl_context.load_verify_locations(self.__cafile)
        ssl_context.verify_mode = ssl.CERT_REQUIRED
        ssl_context.check_hostname = True

        return ssl_context

    async def _send_http_request(
        self, verb: str, url: str, req: dict, notify: Optional[str] = None
    ):
        while self.__retry < self.__max_retries:
            try:
                http_method = getattr(self.__client_session, verb)
                async with http_method(url, json=req, timeout=self.__timeout) as res:
                    if res.status >= 200 and res.status < 300:
                        if notify is not None:
                            await self.trigger(notify, {"response": res})
                    else:
                        error = super()._get_error(
                            "HTTPResponseError",
                            "Received HTTP error in response from server.",
                            {"response": res},
                        )
                        await self.trigger(Interfaces.ERROR, error)
                self.__retry = 0
                break
            except ClientConnectionError:
                self.__retry += 1
                time.sleep(self.__retry_delay_seconds)
                if self.__retry >= self.__max_retries:
                    error = super()._get_error(
                        "HTTPConnectionError",
                        "The HTTP client could not open a TCP connection.",
                        {"url": url},
                    )
                    await self.trigger(Interfaces.ERROR, error)
        self.__retry = 0
