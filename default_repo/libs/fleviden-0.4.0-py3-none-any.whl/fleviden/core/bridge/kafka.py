# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module provides the implementation for a link that connects pods via Kafka.
"""

import json
import ssl
from typing import Optional

from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
from aiokafka.helpers import create_ssl_context

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Kafka(Pod):
    """This class allows to connect a pod output wire to another pod via Kafka.

    A Kafka pod allows to connect via `Kafka.link()` the output wire of a source
    pod to another Kafka pod listening at a given endpoint.

    At the other end, the Kafka pod allows to define an endpoint via `Kafka.wait()`
    such as, when this endpoint receives a request, the request info is
    propagated to another pod input wire.
    """

    def __init__(
        self,
        origin: str,
        bootstrap_servers: list,
        request_timeout_ms: int = 4000,
        tls_flag: bool = False,
        cafile: Optional[str] = None,
        certfile: Optional[str] = None,
        keyfile: Optional[str] = None,
    ):
        """Creates a new Kafka pod.

        Parameters
        ----------
            origin: str
                Must contain an id entry identifying the source name attached to
                all bridged messages.

            bootstrap_servers: list
                A list of string containing the addresses to the Kafka brokers.

            request_timeout_ms: int, optional
                The request timeout in milliseconds.

            tls_flag: bool
                To activate Transport Layer Security. If True, cafile, certfile and keyfile
                must be provided.

            cafile: str
                Path to the CA File for TLS connection.

            certfile: str
                Path to the Certfile for the TLS connection.

            keyfile: str
                Path to the Keyfile for the TLS connection.

        Outputs
        -------

            Interfaces.COMPLETED (/completed)
                A notification that the training process has been completed.
        """
        super().__init__()
        self.__check_params(origin, bootstrap_servers)
        self.__origin = origin
        self.__bootstrap_servers = bootstrap_servers
        self.__request_timeout_ms = request_timeout_ms
        self.__tls_flag = tls_flag
        self.__cafile = cafile
        self.__certfile = certfile
        self.__keyfile = keyfile
        self.__consumer = None
        self.__producer = None
        self.__handlers = {}
        self.register(Interfaces.COMPLETED)

    def __check_params(self, origin: str, bootstrap_servers: list) -> None:
        """Checks that the parameters given to the pod are correct.

        Parameters
        ----------
            origin: str
                Must contain an id entry identifying the source name attached to
                all bridged messages.

            bootstrap_servers: list
                A list of string containing the addresses to the Kafka brokers.
        """
        assert isinstance(origin, str)
        assert isinstance(bootstrap_servers, list)

    def wait(self, topic: str) -> None:
        """Registers a new Kafka topic consumer to receive messages.

        Parameters
        ----------
            topic: str
                The name of the Kafka topic and output wire
                triggered when a message is received.
        """
        self.register(topic)
        self.__handlers[topic] = self.__wait_callback(topic)

    def __wait_callback(self, wire: str) -> callable:
        """
        Returns a function callback that manages incoming Kafka messages.

        Parameters
        ----------
            wire: str
                The name of the Kafka topic and output wire
                triggered when a message is received.
        """

        async def callback(req):
            await self.trigger(wire, req)

        return callback

    def bridge(
        self,
        route: str,
        topic: str,
        key: Optional[str] = None,
        partition=None,
        timestamp=None,
        headers=None,
    ) -> None:
        """
        Creates a bridge for all messages received in the specified route to the
        target Kafka topic.

        Parameters
        ----------
            route: str
                The local output wire to bridge.

            topic: str
                The Kafka topic to which the messages are sent.

            key: str, optional
                The key as defined in aiokafka.

            partition:
                The partition as defined in aiokafka.

            timestamp:
                The timestamp as defined in aiokafka.

            headers:
                The headers as defined in aiokafka.
        """
        self.register(route, self.__bridge_callback(topic, key, partition, timestamp, headers))

    def __bridge_callback(
        self, topic: str, key: Optional[str] = None, partition=None, timestamp=None, headers=None
    ) -> callable:
        """
        Returns a linker function that publishes the request to the specified topic.
        """

        async def callback(req):
            req['origin'] = self.__origin
            try:
                msg = json.dumps(req).encode('utf-8')
                await self.__producer.send_and_wait(topic, msg, key, partition, timestamp, headers)
            finally:
                await self.trigger(Interfaces.COMPLETED, req)

        return callback

    async def on_start(self) -> None:
        """
        Initializes the Kafka consumer, the Kafka producer and waits for incoming messages.
        """
        context = self._create_ssl_context() if self.__tls_flag else None
        security_protocol = "SSL" if self.__tls_flag else "PLAINTEXT"

        self.__consumer = AIOKafkaConsumer(
            bootstrap_servers=self.__bootstrap_servers,
            auto_offset_reset='latest',
            request_timeout_ms=self.__request_timeout_ms,
            security_protocol=security_protocol,
            ssl_context=context,
        )
        await self.__consumer.start()
        self.__producer = AIOKafkaProducer(
            bootstrap_servers=self.__bootstrap_servers,
            request_timeout_ms=self.__request_timeout_ms,
            security_protocol=security_protocol,
            ssl_context=context,
        )
        await self.__producer.start()

    async def on_run(self) -> None:
        """
        Starts reading from the Kafka consumer API.
        """
        self.__consumer.subscribe(topics=list(self.__handlers.keys()))
        async for msg in self.__consumer:
            handler = self.__handlers[msg.topic]
            await handler(json.loads(msg.value.decode('utf-8')))

    async def on_end(self) -> None:
        """
        Stops the Kafka consumer and the Kafka producer.
        """
        await self.__consumer.stop()
        await self.__producer.stop()

    def _create_ssl_context(self) -> ssl.SSLContext:
        """Creates a SSLContext with the provided certificates."""

        context = create_ssl_context(
            cafile=self.__cafile, certfile=self.__certfile, keyfile=self.__keyfile
        )
        return context
