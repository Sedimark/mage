# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module provides the implementation for a client that interacts with the MLflow REST API.
"""

import random
import time

from fleviden.core.bridge.external import External
from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class MLflowClient(Pod):
    """
    A client to interact with the MLflow REST API using the External class.

    Check the MLflow REST API documentation for more details:
    https://mlflow.org/docs/latest/rest-api.html

    This class provides methods to create experiments, runs, log parameters, metrics, models,
    batches of metrics, parameters, and tags to MLflow.
    """

    def __init__(self, base_url: str):
        """
        Initializes the MLflowClient.

        Parameters
        ----------
            base_url : str
                The base URL for the MLflow REST API. For example, 'http://localhost:5000'
                or 'http://mlflow:5000'.

        Inputs
        ------
            Interfaces.CREATE_EXPERIMENT (/create-experiment)
                Creates a new experiment in MLflow.
                The request message must contain an 'experiment_name' and, optionally,
                an 'artifact_location'. If the experiment already exists, it returns its ID.
                If no name is provided, one is generated automatically.

            Interfaces.CREATE_RUN (/create-run)
                Creates a new run in MLflow.
                The request message must contain an 'experiment_id' and a 'run_name'. If no
                'experiment_id' is provided, the ID stored at the Pod level is used. If no
                'run_name' is provided, one is generated automatically.

                Example: `{"experiment_id": "123", "run_name": "run-1"}`

            Interfaces.GET_EXPERIMENT_BY_NAME (/get-experiment-by-name)
                Retrieves an experiment by name from MLflow.
                The request message must contain an 'experiment_name'.

                Example: `{"experiment_name": "experiment-1"}`

            Interfaces.LOG_PARAM (/log-param)
                Logs a parameter to a specific run in MLflow.
                The request message must contain a 'run_id' and the parameters to log. It is
                assumed that all key/value pairs in the request are parameters to log. Values
                are converted to strings before being logged. If no 'run_id' is provided, the
                ID stored at the Pod level is used.

                Example: {"run_id": "123", "param1": 0.5, "param2": "value"}

            Interfaces.LOG_METRIC (/log-metric)
                Logs a metric to a specific run in MLflow.
                The request message must contain a 'run_id' and the metrics to log. It is
                assumed that all numerical values in the request are metrics to log. The step
                and timestamp are automatically generated.

                Example: {"run_id": "123", "metric1": 0.5, "metric2": 0.7}

            Interfaces.LOG_MODEL (/log-model)
                Logs a model's metadata to a specific run in MLflow.
                The request message must contain a 'run_id' and the model's JSON representation
                in 'model_json'. If no 'run_id' is provided, the ID stored at the Pod level is used.
                The model itself must be saved separately.

                Example: {"run_id": "123", "model_json": {"name": "model", "version": "1.0"}}

            Interfaces.LOG_BATCH (/log-batch)
                Logs a batch of metrics, parameters, and tags to a specific run in MLflow.
                The request message must contain a 'run_id' and the 'metrics', 'params', and 'tags'
                to log. It is not necessary to provide all three types of data.
                The metrics must be provided as a list of dictionaries with keys 'key', 'value',
                'step', and 'timestamp'. The parameters must be provided as a list of dictionaries
                with keys 'key' and 'value'. The tags must be provided as a list of dictionaries
                with keys 'key' and 'value'.

                Example: {"run_id": "123", "metrics": [{"key": "metric1", "value": 0.5, "step": 0,
                "timestamp": 1234567890}], "params": [{"key": "param1", "value": "value"}],
                "tags": [{"key": "tag1", "value": "value"}]}.

        Outputs
        -------
            Interfaces.CREATED_EXPERIMENT (/created-experiment)
                Triggered when an experiment is successfully created.

            Interfaces.CREATED_RUN (/created-run)
                Triggered when a run is successfully created.

            Interfaces.GOT_EXPERIMENT_BY_NAME (/got-experiment-by-name)
                Triggered when an experiment is successfully retrieved by name.
                The output contains the experiment details in the 'experiment' key.

            Interfaces.LOGGED_PARAM (/logged-param)
                Triggered when a parameter is successfully logged.

            Interfaces.LOGGED_METRIC (/logged-metric)
                Triggered when a metric is successfully logged.

            Interfaces.LOGGED_MODEL (/logged-model)
                Triggered when a model is successfully logged.

            Interfaces.LOGGED_BATCH (/logged-batch)
                Triggered when a batch of metrics, parameters, and tags is successfully logged.
        """
        super().__init__()
        self.base_url = base_url
        self.http_client = External(base_url=base_url)

        self._experiment_name = None
        self._experiment_id = None
        self._run_id = None

        self._metric_log_step = 0

        self.register(Interfaces.CREATE_EXPERIMENT, self.create_experiment)
        self.register(Interfaces.CREATED_EXPERIMENT)

        self.register(Interfaces.CREATE_RUN, self.create_run)
        self.register(Interfaces.CREATED_RUN)

        self.register(Interfaces.GET_EXPERIMENT_BY_NAME, self.get_experiment_by_name)
        self.register(Interfaces.GOT_EXPERIMENT_BY_NAME)

        self.register(Interfaces.LOG_PARAM, self.log_param)
        self.register(Interfaces.LOGGED_PARAM)

        self.register(Interfaces.LOG_METRIC, self.log_metric)
        self.register(Interfaces.LOGGED_METRIC)

        self.register(Interfaces.LOG_MODEL, self.log_model)
        self.register(Interfaces.LOGGED_MODEL)

        self.register(Interfaces.LOG_BATCH, self.log_batch)
        self.register(Interfaces.LOGGED_BATCH)

        self.http_client.link(Interfaces.WARNING, self, Interfaces.WARNING)
        self.http_client.link(Interfaces.ERROR, self, Interfaces.ERROR)

    async def create_experiment(self, req: dict) -> None:
        """
        Creates a new experiment in MLflow. The request should
        contain the name of the experiment and the artifact location.

        If the experiment already exists, it returns its ID.

        Parameters
        ----------
            req : dict
                The request containing the 'experiment_name' and 'artifact_location'.
        """
        name = req.get("experiment_name", req.get("name", f'experiment-{random.randint(0, 1000)}'))
        artifact_location = req.get("artifact_location", "artifacts")

        payload = {'name': name, 'artifact_location': artifact_location}

        try:
            response = await self.http_client.post(
                '/api/2.0/mlflow/experiments/create', json=payload
            )

            # Check if experiment already exists
            if "error" in response and "details" in response["error"]:
                error_code = response["error"]["details"]["error_code"]
                if error_code == "RESOURCE_ALREADY_EXISTS":
                    response = await self.get_experiment_by_name(req)
                    self._experiment_id = response["experiment"]['experiment_id']
            else:
                self._experiment_id = response['experiment_id']

            self._experiment_name = name
            # Add run name to response if provided
            if "run_name" in req:
                response["run_name"] = req["run_name"]

            await self.trigger(
                Interfaces.CREATED_EXPERIMENT,
                response,
                info_msg=f"Created MLflow experiment with name {name} and ID {self._experiment_id}.",
            )

        except Exception as e:
            error = super()._get_error("MLflowError", "Error creating experiment.", str(e))
            await self.trigger(Interfaces.ERROR, error)

    async def get_experiment_by_name(self, req: dict) -> None:
        """
        Retrieves an experiment by name from MLflow. The request should
        contain the name of the experiment.

        Parameters
        ----------
            req : dict
                The request containing the 'experiment_name'.

        Returns
        -------
            response : dict
                The JSON response containing the details of the experiment.
        """
        name = req.get("experiment_name", req.get("name", None))
        payload = {'experiment_name': name}

        try:
            response = await self.http_client.get(
                '/api/2.0/mlflow/experiments/get-by-name', params=payload
            )
            await self.trigger(
                Interfaces.GOT_EXPERIMENT_BY_NAME,
                response,
                info_msg=f"Retrieved MLflow experiment with name {name}.",
            )
            return response

        except Exception as e:
            error = super()._get_error("MLflowError", "Error getting experiment by name.", str(e))
            await self.trigger(Interfaces.ERROR, error)

    async def create_run(self, req: dict) -> None:
        """
        Creates a new run in MLflow. The request should contain the ID of the
        experiment the run will be created into and the name of the run. If no
        run name is provided, it is randomly generated.

        Parameters
        ----------
            req : dict
                The request containing the 'experiment_id' and 'run_name'.
        """
        experiment_id = req.get("experiment_id", self._experiment_id)
        run_name = req.get("run_name", f"test-run-{random.randint(0, 100000)}")

        payload = {'experiment_id': experiment_id, 'run_name': run_name}
        try:
            response = await self.http_client.post('/api/2.0/mlflow/runs/create', json=payload)
            self._run_id = response['run']['info']['run_id']
            await self.trigger(
                Interfaces.CREATED_RUN,
                response,
                info_msg=f"Created MLflow run with name {run_name} and ID {self._run_id}.",
            )
        except Exception as e:
            error = super()._get_error("MLflowError", "Error creating run.", str(e))
            await self.trigger(Interfaces.ERROR, error)

    async def log_param(self, req: dict) -> None:
        """Logs a parameter or a batch of parameters to a specific run in MLflow.
        It is assumed that all key/value pairs in the request are parameters to log.

        Parameters are converted to strings before being logged, as required by the MLflow API.

        Parameters
        ----------
            req : dict
                The request containing the parameters to log.
        """
        run_id = req.pop("run_id", self._run_id)

        params_to_log = []
        not_to_log = []
        # Filter params and parse non-string values
        for key, value in req.items():
            if isinstance(value, (int, float, bool)):
                value = str(value)
            if not isinstance(value, str) or key == "req_id":
                not_to_log.append(key)
                continue
            params_to_log.append({"key": key, "value": value})

        try:
            # No parameters to log
            if len(params_to_log) == 0:
                return
            # Single parameter (POST to /log-parameter)
            elif len(params_to_log) == 1:
                payload = {
                    'run_id': run_id,
                    'key': params_to_log[0]['key'],
                    'value': params_to_log[0]['value'],
                }
                _ = await self.http_client.post('/api/2.0/mlflow/runs/log-parameter', json=payload)
            # Batch of parameters (POST to /log-batch)
            else:
                payload = {
                    'run_id': run_id,
                    'params': params_to_log,
                }
                _ = await self.http_client.post('/api/2.0/mlflow/runs/log-batch', json=payload)

            # Warn about non-string values
            if len(not_to_log) > 0:
                warning = super()._get_warning(
                    "MLflowWarning",
                    "Some values were not logged as parameters.",
                    f"Values for keys {not_to_log} were not logged.",
                )
                await self.trigger(Interfaces.WARNING, warning)

        except Exception as e:
            error = super()._get_error("MLflowError", "Error logging parameters.", str(e))
            await self.trigger(Interfaces.ERROR, error)

        await self.trigger(
            Interfaces.LOGGED_PARAM, payload, info_msg=f"Logged parameters: {payload}"
        )

    async def log_metric(self, req: dict) -> None:
        """Logs a metric or a batch of metrics to a specific run in MLflow.
        It is assumed that all numerical values in the request are metrics to log.

        The step and timestamp are automatically generated.

        Parameters
        ----------
            req : dict
                The request containing the metrics to log.
        """

        run_id = req.pop("run_id", self._run_id)
        step = req.get("step", self._metric_log_step)
        self._metric_log_step += 1
        timestamp = int(time.time() * 1000)

        metrics_to_log = []
        not_to_log = []
        # Filter out non-numeric values and the req_id
        for key, value in req.items():
            if not isinstance(value, (int, float)) or key in ["req_id"]:
                not_to_log.append(key)
                continue
            metrics_to_log.append(
                {"key": key, "value": value, "step": step, "timestamp": timestamp}
            )

        try:
            # No metrics to log
            if len(metrics_to_log) == 0:
                return
            # Single metric (POST to /log-metric)
            elif len(metrics_to_log) == 1:
                payload = {
                    'run_id': run_id,
                    'key': metrics_to_log[0]['key'],
                    'value': metrics_to_log[0]['value'],
                    'step': metrics_to_log[0]['step'],
                    'timestamp': metrics_to_log[0]['timestamp'],
                }
                _ = await self.http_client.post('/api/2.0/mlflow/runs/log-metric', json=payload)
            # Batch of metrics (POST to /log-batch)
            else:
                payload = {
                    'run_id': run_id,
                    'metrics': metrics_to_log,
                }
                _ = await self.http_client.post('/api/2.0/mlflow/runs/log-batch', json=payload)

            # Warn about non-numeric values
            if len(not_to_log) > 0:
                warning = super()._get_warning(
                    "MLflowWarning",
                    "Some values were not logged as metrics.",
                    f"Values for keys {not_to_log} were not logged.",
                )
                await self.trigger(Interfaces.WARNING, warning)

        except Exception as e:
            error = super()._get_error("MLflowError", "Error logging metrics.", str(e))
            await self.trigger(Interfaces.ERROR, error)

        await self.trigger(
            Interfaces.LOGGED_METRIC, payload, info_msg=f"Logged metrics: {payload}."
        )

    async def log_model(self, req: dict) -> None:
        """Logs a model's metadata to a specific run in MLflow.
        The model itself must be saved separately.

        Parameters
        ----------
            req : dict
                The request containing the model's metadata to log.
        """
        run_id = req.get("run_id", self._run_id)
        model_json = req.get("model_json", None)

        payload = {'run_id': run_id, 'model_json': model_json}
        try:
            response = await self.http_client.post('/api/2.0/mlflow/runs/log-model', json=payload)
            await self.trigger(
                Interfaces.LOGGED_MODEL, response, info_msg=f"Logged model to run {run_id}"
            )
        except Exception as e:
            error = super()._get_error("MLflowError", "Error logging model.", str(e))
            await self.trigger(Interfaces.ERROR, error)

    async def log_batch(self, req: dict) -> None:
        """Logs a batch of metrics, parameters, and tags to a specific run in MLflow.

        Metrics must be provided as a list of dictionaries with keys 'key', 'value', 'step',
        and 'timestamp'.

        Parameters must be provided as a list of dictionaries with keys 'key' and 'value'.

        Tags must be provided as a list of dictionaries with keys 'key' and 'value'.

        Parameters
        ----------
            req : dict
                The request containing the metrics, parameters, and tags to log.
        """
        run_id = req.get("run_id", self._run_id)
        metrics = req.get("metrics", [])
        params = req.get("params", [])
        tags = req.get("tags", [])

        payload = {'run_id': run_id, 'metrics': metrics, 'params': params, 'tags': tags}
        try:
            response = await self.http_client.post('/api/2.0/mlflow/runs/log-batch', json=payload)
            await self.trigger(Interfaces.LOGGED_BATCH, response, info_msg="Logged batch")
        except Exception as e:
            error = super()._get_error("MLflowError", "Error logging batch.", str(e))
            await self.trigger(Interfaces.ERROR, error)

    async def close(self):
        """
        Closes the MLflowClient.
        """
        await self.on_end()
