# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module provides the implementation for a client that interacts with the MinIO REST API.
"""
import json

import boto3
from botocore.auth import SigV4Auth
from botocore.awsrequest import AWSRequest

from fleviden.core.bridge.external import External
from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class MinIOClient(Pod):
    """
    A client to interact with the MinIO REST API, extending the External class.

    This class provides methods to create and delete MinIO buckets, upload, download, and delete
    objects from the MinIO server.

    For more details, check the S3 API compatibility documentation at:
    https://min.io/docs/minio/linux/reference/s3-api-compatibility.html
    """

    def __init__(self, base_url: str, access_key: str, secret_key: str):
        """
        Initializes the MinIO client.

        Parameters
        ----------
            base_url : str
                The base URL for the MinIO REST API.

            access_key : str
                The access key for the MinIO server.

            secret_key : str
                The secret key for the MinIO server.

        Inputs
        ------
            Interfaces.INITIALIZE (/initialize)
                Initializes the default bucket name, object name, and filepath for the MinIO client.
                The request message can contain the keys 'bucket_name', 'object_name' and a
                'filepath' pointing to the local file to upload/download.

            Interfaces.CREATE_BUCKET (/create-bucket)
                A request to create a bucket on the MinIO server. The request message must
                contain a 'bucket_name' or 'name'.

            Interfaces.DELETE_BUCKET (/delete-bucket)
                A request to delete a bucket from the MinIO server. The request message must
                contain a 'bucket_name' or 'name'.

            Interfaces.UPLOAD_OBJECT (/upload-object)
                A request to upload an object to the MinIO server. The request message must
                contain a 'bucket_name', 'object_name', and optionally a 'filepath' pointing to
                the file to upload.

            Interfaces.DOWNLOAD_OBJECT (/download-object)
                A request to download an object from the MinIO server. The request message must
                contain a 'bucket_name', 'object_name', and optionally a 'filepath' where the file
                will be downloaded.

            Interfaces.DELETE_OBJECT (/delete-object)
                A request to delete an object from the MinIO server. The request message must
                contain a 'bucket_name' and 'object_name'.

        Outputs
        -------
            Interfaces.INITIALIZED (/initialized)
                Triggered after initializing the default bucket name, object name
                and filepath.

            Interfaces.CREATED_BUCKET (/created-bucket)
                Triggered when a bucket is successfully created.

            Interfaces.DELETED_BUCKET (/deleted-bucket)
                Triggered when a bucket is successfully deleted.

            Interfaces.UPLOADED_OBJECT (/uploaded-object)
                Triggered when an object is successfully uploaded.

            Interfaces.DOWNLOADED_OBJECT (/downloaded-object)
                Triggered when an object is successfully downloaded.

            Interfaces.DELETED_OBJECT (/deleted-object)
                Triggered when an object is successfully deleted.
        """
        super().__init__()
        self.base_url = base_url
        self.http_client = External(base_url=base_url)

        self.register(Interfaces.INITIALIZE, self._initialize)
        self.register(Interfaces.INITIALIZED)

        self.register(Interfaces.CREATE_BUCKET, self._create_bucket)
        self.register(Interfaces.CREATED_BUCKET)

        self.register(Interfaces.DELETE_BUCKET, self._delete_bucket)
        self.register(Interfaces.DELETED_BUCKET)

        self.register(Interfaces.UPLOAD_OBJECT, self._upload_object)
        self.register(Interfaces.UPLOADED_OBJECT)

        self.register(Interfaces.DOWNLOAD_OBJECT, self._download_object)
        self.register(Interfaces.DOWNLOADED_OBJECT)

        self.register(Interfaces.DELETE_OBJECT, self._delete_object)
        self.register(Interfaces.DELETED_OBJECT)

        self.http_client.link(Interfaces.WARNING, self, Interfaces.WARNING)
        self.http_client.link(Interfaces.ERROR, self, Interfaces.ERROR)

        self.__access_key = access_key
        self.__secret_key = secret_key

        self._bucket_name = None
        self._object_name = None
        self._filepath = None

    async def _initialize(self, req: dict) -> None:
        """
        Initializes the default bucket name, object name, and filepath for the MinIO client.
        The keys 'bucket_name', 'object_name', and 'filepath' can be provided in the request.
        """
        self._bucket_name = req.get("bucket_name", req.get("name", None))
        self._object_name = req.get("object_name", req.get("object", None))
        self._filepath = req.get("filepath", None)

        if (self._bucket_name is None) and (self._object_name is None) and (self._filepath is None):
            error = super()._get_error(
                "InitializationError",
                "No values provided for bucket_name, object_name of filepath.",
                {},
            )
            await self.trigger(Interfaces.ERROR, error)
        else:
            output_req = {
                "bucket_name": self._bucket_name,
                "object_name": self._object_name,
                "filepath": self._filepath,
            }

            await self.trigger(
                Interfaces.INITIALIZED,
                output_req,
                info_msg=f'MinIO client initialized with {output_req}.',
            )

    async def _create_bucket(self, req: dict) -> None:
        """Creates a new bucket on the MinIO server. The request message should contain the
        bucket name. If no 'bucket_name' or 'name' is provided, it will use the bucket defined at
        initialization (/initialize). If the bucket already exists, a warning will be triggered."""

        bucket_name = req.get("bucket_name", req.get("name", self._bucket_name))
        endpoint = f"/{bucket_name}"

        # Get signed headers for the request
        url = f'{self.base_url}{endpoint}'
        headers = self.__get_signed_headers('HEAD', url)

        try:
            # Check if the bucket already exists
            response = await self.http_client.head(endpoint, headers=headers)

            if not "error" in response:
                await self.trigger(
                    Interfaces.WARNING,
                    response,
                    info_msg=f"MinIO bucket {bucket_name} already exists.",
                )
            # Create new bucket
            else:
                headers = self.__get_signed_headers('PUT', url)
                try:
                    response = await self.http_client.put(endpoint, headers=headers)
                    if "error" in response:
                        await self.trigger(Interfaces.ERROR, response)
                    else:
                        await self.trigger(
                            Interfaces.CREATED_BUCKET,
                            response,
                            info_msg=f"MinIO bucket {bucket_name} created.",
                        )

                except Exception as e:
                    error = super()._get_error("MinIOError", "Error creating bucket.", str(e))
                    await self.trigger(Interfaces.ERROR, error)
        except Exception as e:
            error = super()._get_error("MinIOError", "Error checking bucket existence.", str(e))
            await self.trigger(Interfaces.ERROR, error)

    async def _delete_bucket(self, req: dict) -> None:
        """Deletes a bucket from the MinIO server. The request message should contain the
        bucket name. If no 'bucket_name' or 'name' is provided, it will use the bucket defined at
        initialization (/initialize).

        Buckets can only be deleted if they are empty. If the bucket is not empty, the
        request will fail with an error message.
        """
        bucket_name = req.get("bucket_name", req.get("name", self._bucket_name))
        endpoint = f"/{bucket_name}"

        # Get signed headers for the request
        url = f'{self.base_url}{endpoint}'

        headers = self.__get_signed_headers('HEAD', url)
        try:
            # Check if the bucket exists
            response = await self.http_client.head(endpoint, headers=headers)

            if "error" in response:
                await self.trigger(
                    Interfaces.WARNING,
                    response,
                    info_msg=f"MinIO bucket to delete {bucket_name} does not exist.",
                )
            else:
                headers = self.__get_signed_headers('DELETE', url)
                try:
                    response = await self.http_client.delete(endpoint, headers=headers)
                    if "error" in response:
                        await self.trigger(Interfaces.ERROR, response)
                    else:
                        await self.trigger(
                            Interfaces.DELETED_BUCKET,
                            response,
                            info_msg=f"MinIO bucket {bucket_name} deleted.",
                        )

                except Exception as e:
                    error = super()._get_error("MinIOError", "Error deleting bucket.", str(e))
                    await self.trigger(Interfaces.ERROR, error)
        except Exception as e:
            error = super()._get_error("MinIOError", "Error checking bucket existence.", str(e))
            await self.trigger(Interfaces.ERROR, error)

    async def _upload_object(self, req: dict) -> None:
        """Uploads an object to the MinIO server. The request message should contain the
        bucket name and object name. If no 'bucket_name' or 'name' is provided, it will use the
        bucket defined at initialization (/initialize), and the same for the 'object_name'.
        Optionally, the request message can contain the filepath of the object to upload.
        If no filepath is provided, the request data will be serialized and uploaded.
        """
        bucket_name = req.pop("bucket_name", req.get("name", self._bucket_name))
        object_name = req.pop("object_name", req.get("object", self._object_name))
        filepath = req.get("filepath", self._filepath)

        # Read the file if a filepath is provided
        if filepath:
            try:
                with open(filepath, 'rb') as file:
                    data = file.read()
            except Exception as e:
                error = super()._get_error("FileReadError", "Error reading file.", str(e))
                await self.trigger(Interfaces.ERROR, error)
        # Otherwise, serialize the request data
        else:
            data = json.dumps(req)

        endpoint = f"/{bucket_name}/{object_name}"

        # Get signed headers for the request
        url = f'{self.base_url}{endpoint}'
        headers = self.__get_signed_headers('PUT', url)

        try:
            response = await self.http_client.put(endpoint, headers=headers, data=data)
            if "error" in response:
                await self.trigger(Interfaces.ERROR, response)
            else:
                await self.trigger(
                    Interfaces.UPLOADED_OBJECT,
                    response,
                    info_msg=f"MinIO: Object {object_name} uploaded.",
                )

        except Exception as e:
            error = super()._get_error("MinIOError", "Error uploading object.", str(e))
            await self.trigger(Interfaces.ERROR, error)

    async def _download_object(self, req: dict) -> None:
        """Downloads an object from the MinIO server. The request message should contain the
        bucket name and object name. If no 'bucket_name' or 'name' is provided, it will use the
        bucket defined at initialization (/initialize), and the same for the 'object_name'.
        Optionally, the request message can contain the filepath to save the downloaded object.
        If no filepath is provided, the object will be saved with the same name as the
        object name."""

        bucket_name = req.pop("bucket_name", req.get("name", self._bucket_name))
        object_name = req.pop("object_name", req.get("object", self._object_name))
        filepath = req.get("filepath", self._filepath)

        endpoint = f"/{bucket_name}/{object_name}"

        # Get signed headers for the request
        url = f'{self.base_url}{endpoint}'
        headers = self.__get_signed_headers('GET', url)

        try:
            response = await self.http_client.get(
                endpoint, headers=headers, return_response_data=True
            )
            try:
                # Write the downloaded object to a file
                with open(filepath, 'wb') as file:
                    file.write(response)
                await self.trigger(
                    Interfaces.DOWNLOADED_OBJECT,
                    {},
                    info_msg=f"Object {object_name} downloaded to {filepath}.",
                )
            except Exception as e:
                error = super()._get_error(
                    "FileWriteError", "Error writing downloaded file.", str(e)
                )
                await self.trigger(Interfaces.ERROR, error)
        except Exception as e:
            error = super()._get_error("MinIOError", "Error downloading object.", str(e))
            await self.trigger(Interfaces.ERROR, error)

    async def _delete_object(self, req: dict) -> None:
        """Deletes an object from the MinIO server. The request message should contain the
        bucket name and object name. If no 'bucket_name' or 'name' is provided, it will use the
        bucket defined at initialization (/initialize), and the same for the 'object_name'."""

        bucket_name = req.pop("bucket_name", req.get("name", self._bucket_name))
        object_name = req.pop("object_name", req.get("object", self._object_name))

        endpoint = f"/{bucket_name}/{object_name}"

        # Get signed headers for the request
        url = f'{self.base_url}{endpoint}'
        headers = self.__get_signed_headers('DELETE', url)

        try:
            response = await self.http_client.delete(endpoint, headers=headers)
            if "error" in response:
                await self.trigger(Interfaces.ERROR, response)
            else:
                await self.trigger(
                    Interfaces.DELETED_OBJECT,
                    response,
                    info_msg=f"MinIO: Object {object_name} deleted.",
                )

        except Exception as e:
            error = super()._get_error("MinIOError", "Error deleting object.", str(e))
            await self.trigger(Interfaces.ERROR, error)

    def __get_signed_headers(self, method, url, service='s3'):
        """Generates signed headers for the S3 request.

        Parameters
        ----------
            method : str
                The HTTP method for the request, e.g., 'GET', 'PUT', 'DELETE'.

            url : str
                The URL for the request.

            service : str
                The AWS service to use for the request.

        Returns
        -------
            headers : dict
                A dictionary containing the signed headers for the request.
        """
        # Initialize the boto3 session and credentials
        session = boto3.Session(
            aws_access_key_id=self.__access_key,
            aws_secret_access_key=self.__secret_key,
            region_name='us-east-1',
        )

        try:
            # Create credentials object
            credentials = session.get_credentials().get_frozen_credentials()
            # Create an AWSRequest object
            request = AWSRequest(method=method, url=url)

            # Create a SigV4Auth object and sign the request
            auth = SigV4Auth(credentials, service, 'us-east-1')
            auth.add_auth(request)

            # Extract headers
            headers = dict(request.headers)
            return headers
        except:
            return {}
