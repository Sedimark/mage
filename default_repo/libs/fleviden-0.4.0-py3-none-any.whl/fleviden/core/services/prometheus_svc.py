# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module provides the implementation for a client that interacts with the Prometheus HTTP API.
"""

from fleviden.core.bridge.external import External
from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class PrometheusClient(Pod):
    """
    This class implements a client to interact with the Prometheus REST API.

    It provides methods to query, retrieve the active targets, metadata, alerts,
    configuration, etc, from a running Prometheus server. Not all available interactions have
    been implemented in this pod.

    For more details, check the official Prometheus documentation on the HTTP API at:
    https://prometheus.io/docs/prometheus/latest/querying/api/

    Example:

    Create the PrometheusClient pod to query a server accesible at http://prometheus:9090:
        >>> prometheus_client = PrometheusClient(base_url="http://prometheus:9090")

    Query the server for the 'up' metric:
        >>> await prometheus_client.trigger(Interfaces.QUERY, {'query': 'up'})

    Retrieve the target discovery status of the Prometheus server:
        >>> await prometheus_client.trigger(Interfaces.GET_TARGETS, {})

    Get the current configuration of the Prometheus server:
        >>> await prometheus_client.trigger(Interfaces.GET_STATUS_CONFIG, {})

    """

    def __init__(self, base_url: str):
        """Initializes the PrometheusClient pod.

        Parameters
        ----------
            base_url : str
                The base URL of the Prometheus server.

        Inputs
        ------
            Interfaces.QUERY (/query)
                A request to evaluate an instant query at a single point in time. The query must
                be specified under the 'query' key. Optionally, a time can be provided under the
                'time' key. If none is provided, the server current time is used.

            Interfaces.QUERY_RANGE (/query-range)
                A request to evaluate an expression query over a range of time. The query must be
                specified under the 'query' key. A start and end time must be provided under the
                'start' and 'end' keys. Optionally, a 'step' can be included to specify the temporal
                resolution, otherwise, it defaults to 1 minute.

            Interfaces.GET_METADATA (/get-metadata)
                A request to obtain metadata about the metrics scraped from the targets. A specific
                metric can be specified under the 'metric' key, otherwise, all metric metadata is
                retrieved.

            Interfaces.GET_TARGETS (/get-targets)
                A request to obtain an overview of the current state of the Prometheus target
                discovery.

            Interfaces.GET_ALERTS (/get-alerts)
                A request to get the list of all active alerts.

            Interfaces.GET_RULES (/get-rules)
                A request to get the list of alerting and recording rules.

            Interfaces.GET_STATUS_CONFIG (/get-status-config)
                A request to get the currently loaded configuration file.

            Interfaces.GET_STATUS_FLAGS (/get-status-flags)
                A request to get the flag values that Prometheus was configured with.

            Interfaces.GET_RUNTIME_INFO (/get-runtime-info)
                A request to get runtime information properties about the Prometheus server.

        Outputs
        -------
            Interfaces.QUERIED (/queried)
                Triggered with the response of the instant query.

            Interfaces.QUERIED_RANGE (/queried-range)
                Triggered with the response of the range query.

            Interfaces.GOT_METADATA (/got-metadata)
                Triggered with the retrieved metrics metadata.

            Interfaces.GOT_TARGETS (/got-targets)
                Triggered with the state of the Prometheus target discovery.

            Interfaces.GOT_ALERTS (/got-alerts)
                Triggered with the list of active alerts.

            Interfaces.GOT_RULES (/got-rules)
                Triggered with the list of alerting and recording rules.

            Interfaces.GOT_STATUS_CONFIG (/got-status-config)
                Triggered with the currently loaded configuration file.

            Interfaces.GOT_STATUS_FLAGS (/got-status-flags)
                Triggered with the flag values of the Prometheus configuration.

            Interfaces.GOT_RUNTIME_INFO (/got-runtime-info)
                Triggered with the runtime information properties of the Prometheus server.
        """
        super().__init__()
        self.base_url = base_url
        self.http_client = External(base_url=base_url)

        self.register(Interfaces.QUERY, self._query_instant)
        self.register(Interfaces.QUERIED)

        self.register(Interfaces.QUERY_RANGE, self._query_range)
        self.register(Interfaces.QUERIED_RANGE)

        self.register(Interfaces.GET_METADATA, self._get_metadata)
        self.register(Interfaces.GOT_METADATA)

        self.register(Interfaces.GET_TARGETS, self._get_targets)
        self.register(Interfaces.GOT_TARGETS)

        self.register(Interfaces.GET_ALERTS, self._get_alerts)
        self.register(Interfaces.GOT_ALERTS)

        self.register(Interfaces.GET_RULES, self._get_rules)
        self.register(Interfaces.GOT_RULES)

        self.register(Interfaces.GET_STATUS_CONFIG, self._get_status_config)
        self.register(Interfaces.GOT_STATUS_CONFIG)

        self.register(Interfaces.GET_STATUS_FLAGS, self._get_status_flags)
        self.register(Interfaces.GOT_STATUS_FLAGS)

        self.register(Interfaces.GET_RUNTIME_INFO, self._get_runtime_info)
        self.register(Interfaces.GOT_RUNTIME_INFO)

    async def _query_instant(self, req: dict):
        """Evaluates an instant query at a single point in time. If no 'time' is
        provided in the request, the current server time is used."""
        query = req.get("query", None)
        if query is not None:
            endpoint = "/api/v1/query"
            params = {"query": query}
            if "time" in req:
                params["time"] = req.get("time")

            response = await self.http_client.get(endpoint=endpoint, params=params)
            await self.trigger(Interfaces.QUERIED, response)
        else:
            error = super()._get_error(
                "PrometheusQueryError",
                "A query was not provided in the request under the 'query' key.",
                str(req.keys()),
            )
            await self.trigger(Interfaces.ERROR, error)

    async def _query_range(self, req: dict):
        """
        Evaluates an expression query over a range of time. The request must contain:
        - 'query' (str): Prometheus expression query string.
        - 'start' (rfc3339 | unix_timestamp): Start timestamp, inclusive.
        - 'end' (rfc3339 | unix_timestamp): End timestamp, inclusive.
        - 'step' (duration | float): Query resolution step width in duration format, e.g. 1m,
        or float number of seconds. By default, 1m.
        """
        query = req.get("query", None)
        start = req.get("start", None)
        end = req.get("end", None)
        if (query is not None) and (start is not None) and (end is not None):
            endpoint = "/api/v1/query_range"
            step = req.get("step", "1m")
            params = {"query": query, "start": start, "end": end, "step": step}
            response = await self.http_client.get(endpoint=endpoint, params=params)
            await self.trigger(Interfaces.QUERIED_RANGE, response)
        else:
            error = super()._get_error(
                "PrometheusQueryRangeError",
                "A 'query', a 'start' and 'end' time were not provided in the query range request.",
                str(req.keys()),
            )
            await self.trigger(Interfaces.ERROR, error)

    async def _get_metadata(self, req: dict):
        """Returns metadata about metrics scraped from the targets, but not from the targets
        themselves. If no particular metric is queried under the 'metric' key in the req, all
        metric metadata is retrieved."""
        endpoint = '/api/v1/metadata'
        params = {}
        if "metric" in req:
            params['metric'] = req.get("metric")
        response = await self.http_client.get(endpoint=endpoint, params=params)
        await self.trigger(Interfaces.GOT_METADATA, response)

    async def _get_targets(self, _req: dict):
        """Returns an overview of the current state of the Prometheus target discovery."""
        endpoint = '/api/v1/targets'
        response = await self.http_client.get(endpoint=endpoint)
        await self.trigger(Interfaces.GOT_TARGETS, response)

    async def _get_alerts(self, _req: dict):
        """Returns a list of all active alerts."""
        endpoint = '/api/v1/alerts'
        response = await self.http_client.get(endpoint=endpoint)
        await self.trigger(Interfaces.GOT_ALERTS, response)

    async def _get_rules(self, _req: dict):
        """Returns a list of alerting and recording rules that are currently loaded."""
        endpoint = '/api/v1/rules'
        response = await self.http_client.get(endpoint=endpoint)
        await self.trigger(Interfaces.GOT_RULES, response)

    async def _get_status_config(self, _req: dict):
        """Returns currently loaded configuration file."""
        endpoint = '/api/v1/status/config'
        response = await self.http_client.get(endpoint=endpoint)
        await self.trigger(Interfaces.GOT_STATUS_CONFIG, response)

    async def _get_status_flags(self, _req: dict):
        """Returns flag values that Prometheus was configured with."""
        endpoint = '/api/v1/status/flags'
        response = await self.http_client.get(endpoint=endpoint)
        await self.trigger(Interfaces.GOT_STATUS_FLAGS, response)

    async def _get_runtime_info(self, _req: dict):
        """Returns various runtime information properties about the Prometheus server."""
        endpoint = '/api/v1/status/runtimeinfo'
        response = await self.http_client.get(endpoint=endpoint)
        await self.trigger(Interfaces.GOT_RUNTIME_INFO, response)
