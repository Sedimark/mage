# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
A coder to serialize data into b64 format with binarization and lossless compression.
"""

import base64
import copy
import json
import lzma

import cbor2
import msgpack
import zstd

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod
from fleviden.core.utils.object_utils import get_size


class BinaryCoder(Pod):
    """Binary Coder pod with lossless compression.

    This pod serializes data into base64 strings from a req dictionary,
    provided a binarizer and a compressor. The coder can be "cbor2", "msgpack" (MessagePack),

    or "json". The compressor can be "zstd" (ZStandard) or "LZMA".

    On the coder:

        1. **CBOR2** and **MessagePack** provide very similar performance, so the choice
        between them is mostly a matter of preference.

        2. **JSON** is less efficient than the other two and it is implemented for compatibility,
        but shouldn't be used for compression purposes.

    On the compressor:


        1. **LZMA** is the most efficient compressor, but it is slower than "Zstd". Highest
        compression ratio at highest computational cost.

        2. **Zstd** is in the middle ground between ratio and time. For most cases, it is
        the best choice. For relatively high input sizes, Zstd offers similar ratio to LZMA

        with a much lower computational cost.

    The resulting data is lossless, which guarantees that the original data can be
    reconstructed from the compressed data.

    For example, if you want to encode/decode data at
    a **client**, you can link the pods in the following way:

    Create the encoder pods:
        >>> #client.py
        >>> pod_bincoder = BinaryCoder(coder="cbor2", compressor="lzma", entry="data")

    Link the output of the client pod to the encoders:
        >>> pod_client.link(Interfaces.FORWARDED, pod_bincoder, Interfaces.ENCODE)

    Then, send the encoded data to the server via a bridge pod:
        >>> pod_bincoder.link(Interfaces.ENCODED, pod_http, Interfaces.UPDATE)

    If you want to decode the data received from the server:
        >>> pod_http.link(Interfaces.REST_UPDATE_FROM_SERVER, pod_bincoder, Interfaces.DECODE)
        >>> pod_bincoder.link(Interfaces.DECODED, pod_client, Interfaces.UPDATE)

    Analogously, you can implement the encoding/decoding logic at the **server** side:

    Create the encoder pods:
        >>> #server.py
        >>> pod_bincoder = BinaryCoder(coder="cbor2", compressor="lzma", entry="data")

    To encode the data to broadcast:
        >>> pod_server.link(Interfaces.BROADCASTED, pod_bincoder, Interfaces.ENCODE)
        >>> pod_bincoder.link(Interfaces.ENCODED, pod_http, "/broadcast-weights")

    To decode updates from clients:
        >>> pod_http.link(Interfaces.REST_UPDATE_FROM_CLIENT, pod_bincoder, Interfaces.DECODE)
        >>> pod_bincoder.link(Interfaces.DECODED, pod_server, Interfaces.UPDATE)

    The /encoded output will contain the compressed data and metadata related to the original and
    compressed size, for better understanding of the compression ratio. Although the final
    compression ratio depends on the data, the selected coder and compressor, you can expect
    a compression ratio of 3-6x for most cases.
    """

    def __init__(self, coder: str = "msgpack", compressor: str = "zstd", entry: str = "data"):
        """Creates a new BinaryCoder pod.

        Parameters
        ----------
            coder : str, optional
                Binary coder to encode/decode data to base64 strings, by default "msgpack".
                Supported: "cbor2", "msgpack" and "json". CBOR2 and MessagePack achieve very similar
                performance, with CBOR2 being slightly more efficient.
                JSON is supported for compatibility reasons, but it is not recommended.

            compressor : str, optional
                Algorithm to compress the bitstream losslessly, by default "lzma".
                Supported: "zstd", "lzma". LZMA is the most efficient, but the slowest.
                ZSTD provides a good balance between compression ratio and execution time, and is
                preferable when the input is very large.

            entry : str, optional
                Key of the output dictionary where the data is encoded to/decoded from, by default
                "data". In the encoding method, the input req message will be output with the
                format {entry: b64_data}. In the decoding, the original dictionary structure is
                reconstructed, so the key "entry" is not present.

        Inputs
        ------
            Interfaces.ENCODE (/encode)
                Encode a dictionary into a BitVector.

            Interfaces.DECODE (/decode)
                Decode a BitVector into a dictionary.

        Outputs
        -------
            Interfaces.ENCODED (/encoded)
                Triggered after the input req message has been encoded.

            Interfaces.DECODED (/decoded)
                Triggered after the input req message has been decoded.
        """
        super().__init__()

        self.coder = coder
        self.compressor = compressor
        self.entry = entry

        self.supported_coders = ["cbor2", "msgpack", "json"]
        self.supported_compressors = ["zstd", "lzma"]

        self.register(Interfaces.ENCODE, self._encode)
        self.register(Interfaces.ENCODED)

        self.register(Interfaces.DECODE, self._decode)
        self.register(Interfaces.DECODED)

    async def _check_parameters(self):
        """Checks if the provided parameters are valid."""
        if self.coder not in self.supported_coders:
            warning = super()._get_warning(
                "UnsupportedCoderWarning",
                f"Coder {self.coder} not supported. Using default msgpack.",
                {"supported_coders": self.supported_coders},
            )
            self.coder = "msgpack"
            await self.trigger(Interfaces.WARNING, warning)

        if self.compressor not in self.supported_compressors:
            warning = super()._get_warning(
                "UnsupportedCompressorWarning",
                f"Compressor {self.compressor} not supported. Using default zstd.",
                {"supported_compressors": self.supported_compressors},
            )
            self.compressor = "zstd"
            await self.trigger(Interfaces.WARNING, warning)

    async def _encode(self, req: dict):
        """Encodes and compresses the input req."""

        req_copy = copy.deepcopy(req)

        # Never encode the "origin" entry
        req_copy.pop("origin", None)

        # Check parameters
        await self._check_parameters()

        # To binary
        bin_data = self._to_binary(req_copy, self.coder)

        # Compress
        compressed_data = self._compress(bin_data, self.compressor)

        # To base64
        b64_data = base64.b64encode(compressed_data).decode('utf-8')

        original_size = get_size(req_copy)
        compressed_size = get_size(b64_data)
        compression_ratio = original_size / compressed_size

        data = {
            self.entry: b64_data,
            "original_size": original_size,
            "compressed_size": compressed_size,
            "compression_ratio": compression_ratio,
        }

        await self.trigger(
            Interfaces.ENCODED, data, info_msg=f"Compressed data (Ratio = {compression_ratio:.2f})."
        )

    async def _decode(self, req: dict):
        """Decompressess and decodes the input req."""

        req_copy = copy.deepcopy(req)

        # Check parameters
        await self._check_parameters()

        if self.entry not in req_copy:
            error = super()._get_error(
                "EntryNotFoundError",
                str(IndexError("The entry to decode was not found in the input request.")),
                {"entry": self.entry},
            )

            await self.trigger(Interfaces.ERROR, error)
            return

        # From bitvector to bytes
        b64_data = req_copy.pop(self.entry)
        compressed_data = base64.b64decode(b64_data)

        # Decompress
        decompressed_data = self._decompress(compressed_data, self.compressor)

        # From binary
        data = self._from_binary(decompressed_data, self.coder)

        await self.trigger(Interfaces.DECODED, {**req_copy, **data}, info_msg="Decompressed data.")

    def _to_binary(self, data, code: str):
        """Converts data to binary."""

        if code == "cbor2":
            return cbor2.dumps(data)
        elif code == "msgpack":
            return msgpack.packb(data)
        elif code == "json":
            return json.dumps(data).encode()

    def _from_binary(self, data, code: str):
        """Converts binary data to bytes"""

        if code == "cbor2":
            return cbor2.loads(data)
        elif code == "msgpack":
            return msgpack.unpackb(data)
        elif code == "json":
            return json.loads(data)

    def _compress(self, data, code: str):
        """Compresses binary data."""

        if code == "zstd":
            return zstd.compress(data)
        elif code == "lzma":
            return lzma.compress(data)

    def _decompress(self, data, code: str):
        """Decompresses binary data."""

        if code == "zstd":
            return zstd.decompress(data)
        elif code == "lzma":
            return lzma.decompress(data)
