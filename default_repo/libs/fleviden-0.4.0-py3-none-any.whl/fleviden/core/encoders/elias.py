# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
An Elias-omega coder for integers [1].

Reference:

[1] Elias, P. (1975). Universal codeword sets and representations
of the integers. IEEE Transactions on Information Theory, 21(2),
194–203. https://doi.org/10.1109/TIT.1975.1055349

"""

import numpy as np
from BitVector import BitVector

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Elias(Pod):
    """An Elias-omega coder for integers.

    Elias-omega coding is a universal code for positive integers
    that is used in scenarios where we want to compress data in which
    small numbers are more frequent than larger ones.

    This pod takes a vector of integers as input for the encoder and
    returns a single bitstream (BitVector) with the concatenation of the
    individual codes. The decoder performs the inverse operation,
    transforming a bitstream that has been encoded with Elias into a
    vector of integers.

    The encoding/decoding functions are recursive.
    """

    def __init__(self, entries: list, replace: bool = True):
        """Creates a new Elias pod.

        Parameters
        ----------
            entries : list[str]
                Entries in the req to encode/decode.

            replace : bool
                If True, the entries in the request dictionary are replaced by the outputs.
                If False, a new entry is added with the name "[entry]_elias_[encoded/decoded]",
                e.g., "weights_elias_encoded".

        Inputs
        ------
            Interfaces.ENCODE (/encode)
                Encodes the integers in the entries.

            Interfaces.DECODE (/decode)
                Decodes the Elias-omega code in the entries.

        Outputs
        -------
            Interfaces.ENCODED (/encoded)
                After all the entries have been encoded.

            Interfaces.DECODED (/decoded)
                After all the entries have been decoded.
        """
        super().__init__()

        self.entries = entries
        self.replace = replace

        self.register(Interfaces.ENCODE, self._encode)
        self.register(Interfaces.ENCODED)

        self.register(Interfaces.DECODE, self._decode)
        self.register(Interfaces.DECODED)

    async def _encode(self, req: dict) -> None:
        """Provides the Elias-omega encoding of a vector of integers.

        Parameters
        ----------
            req : dict
                The request dictionary containing the keys
                listed in the entries parameter.

        Triggers
        --------
            Interfaces.ERROR (/error)
                If the entry is not a vector of positive integers.

            Interfaces.WARNING (/warning)
                If the req dictionary doesn't contain an entry.

            Interfaces.ENCODED (/encoded)
                After all the entries have been encoded.
        """

        for entry in self.entries:
            if entry not in req:
                await self.trigger(
                    Interfaces.WARNING,
                    mandatory=False,
                    req={**req, **self.__get_invalid_key_warning(entry)},
                )
            else:
                vector = np.array(req[entry])
                encoded = BitVector(size=0)
                for value in vector:
                    if not isinstance(value, (int, np.integer)) or (value < 1):
                        await self.trigger(
                            Interfaces.ERROR,
                            mandatory=False,
                            req={**req, **self.__get_value_error(value)},
                        )
                        break  # Do not continue encoding
                    encoded += self._to_elias(value)

                if self.replace:
                    req[entry] = encoded
                else:
                    elias_key = entry + "_elias_encoded"  # For example: weights_elias_encoded
                    req[elias_key] = encoded

        await self.trigger(Interfaces.ENCODED, req)

    async def _decode(self, req: dict) -> None:
        """Provides the vector of integers from an Elias-omega code.

        Parameters
        ----------
            req : dict
                The request dictionary containing the keys
                listed in the entries parameter.

        Triggers
        --------
            Interfaces.WARNING (/warning)
                If the req dictionary doesn't contain an entry.

            Interfaces.DECODED (/decoded)
                After all the entries have been decoded.
        """
        for entry in self.entries:
            if entry not in req:
                await self.trigger(
                    Interfaces.WARNING,
                    mandatory=False,
                    req={**req, **self.__get_invalid_key_warning(entry)},
                )
            else:
                code = req[entry]
                decoded = []
                while len(code) > 1:
                    value, code = self._from_elias(code)
                    decoded.append(value)

                if self.replace:
                    req[entry] = np.array(decoded)
                else:
                    elias_key = entry + "_elias_decoded"  # For example: weights_elias_decoded
                    req[elias_key] = np.array(decoded)

        await self.trigger(Interfaces.DECODED, req)

    def _to_elias(self, n: int, code: BitVector = BitVector(intVal=0)) -> BitVector:
        """Encodes an integer number with its Elias-omega code.

        Elias-omega code is only defined for n >= 1.

        Parameters
        -----------
            n : int
                Number to decode.

        Returns
        -------
            code : bitvector
                Elias-omega code of n.
        """

        if n == 1:
            return code

        binary = BitVector(intVal=n)

        n = len(binary) - 1

        return self._to_elias(n, binary + code)

    def _from_elias(self, code: BitVector, n: int = 1) -> tuple[int, BitVector]:
        """Decodes the Elias-omega code into an integer.

        Parameters
        -----------
            code : bitvector
                Bitstream with the Elias-omega code.

        Returns
        -------
            n : int
                Integer number.

            code : bitvector
                Bitstream with the remaining Elias-omega code.

        """

        if code[0] == 0:
            return n, code[1:]

        begin = code[: 1 + n]
        end = code[1 + n :]
        n = begin.int_val()

        return self._from_elias(end, n)

    def __get_value_error(self, value) -> dict:
        name = "ValueError"
        description = "The input value is not a positive integer."
        details = {"param": value}
        return super()._get_error(name, description, details)

    def __get_invalid_key_warning(self, entry) -> dict:
        name = "MissingKey"
        description = "The key is not present in the request dictionary."
        details = {"invalid_key": entry}
        return super()._get_warning(name, description, details)
