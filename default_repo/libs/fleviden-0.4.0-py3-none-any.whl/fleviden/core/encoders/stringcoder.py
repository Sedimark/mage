# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
A general string coder to transform bits into readable characters.
"""

import base64

from BitVector import BitVector

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class StringCoder(Pod):
    """A generic coder from bitvector to string of characters compatible with .json.

    This pod expects a bitvector to perform the encoding
    and a string for the decoding.

    The currently supported codes are hexadecimal (4 bits per char) and base64 (6 bits
    per char). Base64 is the most efficient scheme to encode binary data into text format,
    since it is the highest power than can be represented using only ASCII printable
    characters.
    """

    def __init__(self, code: str, entries: list, replace: bool = True):
        """
        Creates a new StringCoder pod.

        Parameters
        ----------
            code : str
                Type of string encoding. Supported options are 'hex' and 'base64'.

            entries : list[str]
                Entries to encode/decode.

            replace : bool, optional
                If True, the entries in the request dictionary are replaced by the outputs.
                If False, a new entry is added with the name "[entry]_[code]_[encoded/decoded]",
                e.g., "weights_hex_encoded".

        Inputs
        ------
            Interfaces.ENCODE (/encode)
                Encodes a bitstream into a string of characters.

            Interfaces.DECODE (/decode)
                Decodes a string of characters into a bitstream.

        Outputs
        -------
            Interfaces.ENCODED (/encoded)
                Triggered after all the entries have been encoded.

            Interfaces.DECODED (/decoded)
                Triggered after all the entries have been decoded.
        """
        super().__init__()

        self.code = code
        self.entries = entries
        self.replace = replace

        self.register(Interfaces.ENCODE, self._encode)
        self.register(Interfaces.ENCODED)

        self.register(Interfaces.DECODE, self._decode)
        self.register(Interfaces.DECODED)

    async def _encode(self, req: dict) -> None:
        """Encodes a bitstream into a string of characters.

        Parameters
        ----------
            req : dict
                The request dictionary containing the keys listed in the entries parameter.

        Triggers
        --------
            Interfaces.ERROR (/error) : str
                Triggered if the selected string code is not supported.
            Interfaces.WARNING (/warning) : str
                Triggered if the req dictionary doesn't contain an entry.
            Interfaces.ENCODED (/encoded) : str
                Triggered after all the entries have been encoded.

        Notes
        -----
        This method encodes each entry in the request dictionary into a string of characters
        based on the selected string code. The supported string codes are 'hex' and 'b64'.
        If the selected string code is not supported, the /error trigger is triggered.
        If an entry is missing in the request dictionary, the /warning trigger is triggered.
        After encoding all the entries, the /encoded trigger is triggered.

        Examples
        --------
            >>> req = {'weights': [0.1, 0.2, 0.3]}
            >>> await self._encode(req)
        """
        for entry in self.entries:
            if entry not in req:
                await self.trigger(
                    Interfaces.WARNING,
                    mandatory=False,
                    req={**req, **self.__get_invalid_key_warning(entry)},
                )
            else:
                vector = req[entry]

                if self.code in ['hex', 'hexadecimal', 'h', 'hexa']:
                    encoded = self._to_hex(vector)
                elif self.code in ['b64', 'base64', 'base', '64']:
                    encoded = self._to_b64(vector)
                else:
                    await self.trigger(
                        Interfaces.ERROR,
                        mandatory=False,
                        req={**req, **self.__get_invalid_code_error(self.code)},
                    )
                    break

                if self.replace:
                    req[entry] = encoded
                else:
                    stringcode_key = (
                        entry + "_" + self.code + "_encoded"
                    )  # e.g. weights_b64_encoded
                    req[stringcode_key] = encoded

        await self.trigger(Interfaces.ENCODED, req)

    async def _decode(self, req: dict) -> None:
        """
        Decodes a string of characters into a bitstream.

        Parameters
        ----------
            req : dict
                The request dictionary containing the keys listed in the entries parameter.

        Triggers
        --------
            Interfaces.ERROR (/error) : str
                Triggered if the selected string code is not supported.
            Interfaces.WARNING (/warning) : str
                Triggered if the req dictionary doesn't contain an entry.
            Interfaces.DECODED (/decoded) : str
                Triggered after all the entries have been decoded.
        """

        for entry in self.entries:
            if entry not in req:
                await self.trigger(
                    Interfaces.WARNING,
                    mandatory=False,
                    req={**req, **self.__get_invalid_key_warning(entry)},
                )
            else:
                encoded = req[entry]

                if self.code in ['hex', 'hexadecimal', 'h', 'hexa']:
                    decoded = self._from_hex(encoded)
                elif self.code in ['b64', 'base64', 'base', 'b', '64']:
                    decoded = self._from_b64(encoded)
                else:
                    await self.trigger(
                        Interfaces.ERROR,
                        mandatory=False,
                        req={**req, **self.__get_invalid_code_error(self.code)},
                    )
                    break

                if self.replace:
                    req[entry] = decoded
                else:
                    stringcode_key = (
                        entry + "_" + self.code + "_decoded"
                    )  # e.g. weights_b64_decoded
                    req[stringcode_key] = decoded

        await self.trigger(Interfaces.DECODED, req)

    def _zeropad(self, bitvector: BitVector, N: int) -> BitVector:
        """
        Zero pad a bitstream so that the number of bits is a multiple of N.

        Parameters
        ----------
            bitvector : bitvector
                Input unpadded bitvector.

            N : int
                Number we want the length of the bitvector to be divisible by.

        Returns
        -------
            bitvector : bitvector
                Output bitvector with left zero-padding.
        """
        length = len(bitvector)

        if length % N == 0:
            return bitvector

        desired_length = length + (N - length % N)  # Next multiple of N

        zeros_to_add = desired_length - length

        bitvector.pad_from_left(zeros_to_add)

        return bitvector

    def _to_hex(self, bitvector: BitVector) -> str:
        """Converts a bitstream to a hexadecimal code.

        Parameters
        ----------
        bitvector : bitvector
            The input bitstream.

        Returns
        -------
        hexadecimal : str
            The hexadecimal code as a string.
        """
        bitvector = self._zeropad(bitvector, 4)
        hexadecimal = bitvector.get_bitvector_in_hex()

        return hexadecimal

    def _from_hex(self, hexadecimal: str) -> BitVector:
        """
        Convert a string with hexadecimal code to a bitvector.

        Parameters
        ----------
        hexadecimal : str
            Hexadecimal code string.

        Returns
        -------
        bitvector : bitvector
            The resulting bitvector.
        """
        bitvector = BitVector(hexstring=hexadecimal)

        return bitvector

    def _to_b64(self, bitvector: BitVector) -> str:
        """
        Convert a bitstream to base64 code.

        Parameters
        ----------
        bitvector : bitvector
            The input bitstream to be converted.

        Returns
        -------
        b64 : str
            The base64 code string.

        Notes
        -----
        This method takes a bitstream as input and converts it to a base64 code string.
        The input bitstream is first zero-padded to ensure it has a length that is a multiple of 8.
        Then, the bitstream is divided into chunks of 8 bits each.
        Each chunk is converted to a byte and the resulting bytes are concatenated.
        Finally, the concatenated bytes are encoded using base64 encoding and the resulting base64
        code string is returned.
        """
        bitvector = self._zeropad(bitvector, 8)
        bit_string = str(bitvector)

        chunks = [bit_string[i : i + 8] for i in range(0, len(bit_string), 8)]
        bit_bytes = bytes(int(chunk, 2) for chunk in chunks)

        b64 = base64.b64encode(bit_bytes).decode('utf-8')
        return b64

    def _from_b64(self, b64: str) -> BitVector:
        """
        Convert a base64 string to a bitvector.

        Parameters
        ----------
        b64 : str
            The base64 code string.

        Returns
        -------
        bitvector : BitVector
            The resulting bitvector.

        """
        decoded_bytes = base64.b64decode(b64)

        # Convert the bytes to a bitstream (str)
        bitstream = ''.join(format(byte, '08b') for byte in decoded_bytes)

        # Cast it into a BitVector
        bitvector = BitVector(bitstring=bitstream)

        return bitvector

    def __get_invalid_key_warning(self, entry) -> dict:
        name = "MissingKey"
        description = "The key is not present in the request dictionary."
        details = {"invalid_key": entry}
        return super()._get_warning(name, description, details)

    def __get_invalid_code_error(self, code) -> dict:
        name = "InvalidCode"
        description = "The code is not supported."
        details = {"invalid_code": code}
        return super()._get_error(name, description, details)
