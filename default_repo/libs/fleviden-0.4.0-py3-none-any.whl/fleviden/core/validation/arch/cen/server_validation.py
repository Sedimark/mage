"""
Pydantic models for the validation of the Server pod
interfaces.
"""

from typing import Union

from pydantic import BaseModel, ConfigDict


class ServerValidation:
    """
    Pydantic validation models for the Server pod interfaces.

    Each model is a class that inherits from pydantic.BaseModel,
    and should define the expected fields in the input req
    dictionary.
    """

    class Update(BaseModel):
        """
        Validation model for the /update wire.
        """

        model_config = ConfigDict(extra='allow', arbitrary_types_allowed=True)

        origin: Union[int, str]
