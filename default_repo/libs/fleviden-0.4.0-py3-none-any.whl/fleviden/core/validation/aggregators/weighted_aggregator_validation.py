"""
Pydantic models for the validation of the WeightedAggregator pod
interfaces.
"""

from typing import List, Optional, Union

from pydantic import BaseModel, ConfigDict


class WeightedAggrValidation:
    """
    Pydantic validation models for the WeightedAggregator pod interfaces.

    Each model is a class that inherits from pydantic.BaseModel,
    and should define the expected fields in the input req
    dictionary.
    """

    class Initialize(BaseModel):
        """
        Validation model for the /initialize wire.
        """

        model_config = ConfigDict(extra='allow', arbitrary_types_allowed=True)

        weights: Optional[List[float]] = None

    class Aggregate(BaseModel):
        """
        Validation model for the /aggregate wire.
        """

        model_config = ConfigDict(extra='allow', arbitrary_types_allowed=True)

        gradients: Optional[List[float]] = None
        weights: Optional[List[float]] = None
        alpha: Optional[Union[int, float, str]] = None
