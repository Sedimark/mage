"""
Pydantic models for the validation of the ScikitLearn pod
interfaces.
"""

from typing import Any, List, Optional

from pydantic import BaseModel, ConfigDict


class ScikitLearnValidation:
    """
    Pydantic validation models for the ScikitLearn pod interfaces.

    Each model is a class that inherits from pydantic.BaseModel,
    and should define the expected fields in the input req
    dictionary.
    """

    class Load(BaseModel):
        """
        Validation model for the /load wire.
        """

        model_config = ConfigDict(extra='allow', arbitrary_types_allowed=True)

        filepath: Optional[str] = None

    class Train(BaseModel):
        """
        Validation model for the /train wire.
        """

        model_config = ConfigDict(extra='allow', arbitrary_types_allowed=True)

        weights: Optional[List[float]] = None
        gradients: Optional[List[float]] = None
        features: Any
        targets: Any
        epochs: Optional[int] = None
        batch_size: Optional[int] = None
        learning_rate_init: Optional[float] = None
        filepath: Optional[str] = None

    class Evaluate(BaseModel):
        """
        Validation model for the /evaluate wire.
        """

        model_config = ConfigDict(extra='allow', arbitrary_types_allowed=True)

        weights: Optional[List[float]] = None
        gradients: Optional[List[float]] = None
        features: Any
        targets: Any

    class UpdateWeights(BaseModel):
        """
        Validation model for the /update-weights wire.
        """

        model_config = ConfigDict(extra='allow', arbitrary_types_allowed=True)

        weights: Optional[List[float]] = None
        gradients: Optional[List[float]] = None

    class SaveModel(BaseModel):
        """
        Validation model for the /save-model wire.
        """

        model_config = ConfigDict(extra='allow', arbitrary_types_allowed=True)

        filepath: Optional[str] = None
