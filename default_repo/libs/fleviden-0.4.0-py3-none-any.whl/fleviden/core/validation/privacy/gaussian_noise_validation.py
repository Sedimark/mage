# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
Validation schemas for the GaussianNoise Pod.
"""

from typing import List, Optional

from pydantic import BaseModel, ConfigDict


class GaussianNoiseValidation:
    """
    Pydantic validation models for the GaussianNoise interfaces.

    Each model defines the expected fields for the input request dictionary.
    """

    class AddGaussianNoise(BaseModel):
        """
        Validation model for the /add-noise wire.

        Attributes
        ----------
            weights : Optional[List[float]]
                The weights to which noise will be added.
            gradients : Optional[List[float]]
                The gradients to which noise will be added.
            clip_value : float
                The clipping value used to scale the noise. If None, noise is based only on std_dev.
            num_clients : int
                The number of clients connected to the server.
        """

        model_config = ConfigDict(extra='allow', arbitrary_types_allowed=True)

        weights: Optional[List[float]] = None
        gradients: Optional[List[float]] = None
        clip_value: Optional[float] = None
        num_clients: Optional[int] = None
