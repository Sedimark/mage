"""
Pydantic models for the validation of the ImageLoader pod
interfaces.
"""

from typing import Optional

from pydantic import BaseModel, ConfigDict


class ImageLoaderValidation:
    """
    Pydantic validation models for the ImageLoader pod interfaces.

    Each model is a class that inherits from pydantic.BaseModel,
    and should define the expected fields in the input req
    dictionary.
    """

    class Load(BaseModel):
        """
        Validation model for the /load wire.
        """

        model_config = ConfigDict(extra='allow', arbitrary_types_allowed=True)

        dataset_dir: Optional[str] = None
        images_dir: Optional[str] = None
        labels_dir: Optional[str] = None
