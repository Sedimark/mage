# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

# IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a utility pod that sends messages in batches.
"""

from typing import Optional

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Batch(Pod):
    """This class allows to specify an interface whose messages are
    divided in batches and sent independently through an output wire.
    """

    def __init__(self, entries: Optional[list] = None):
        """Creates a new batch pod

        Parameters
        ----------
            entries : list, optional
                Key of the entries to be batched, by default None.

        Inputs
        ------
            Interfaces.SEND (/send)
                A request to send messages in batches.

            Interfaces.TICK (/tick)
                A request to send messages in batches at each tick.

            Interfaces.RECV (/recv)
                A request to receive messages in batches.

        Outputs
        -------
            Interfaces.FIRE (/fire)
                A trigger to send messages in batches.
        """
        super().__init__()
        self.entries = entries
        self.status = None
        self.req = None
        self.register(Interfaces.SEND, self._send)
        self.register(Interfaces.TICK, self._tick)
        self.register(Interfaces.RECV, self._recv)
        self.register(Interfaces.FIRE)

    async def _send(self, req):
        entries = self.__get_entries(req)
        self.status = self.__get_status(entries, req)
        while not self.__is_completed(self.status):
            batch = self.__pop_batch(entries, req)
            await self.trigger(Interfaces.FIRE, batch)
        self.status = None

    async def _tick(self, req):
        entries = self.__get_entries(req)
        if self.req is None:
            self.req = req
        if self.status is None:
            self.status = self.__get_status(entries, self.req)
        if not self.__is_completed(self.status):
            batch = self.__pop_batch(entries, self.req)
            await self.trigger(Interfaces.FIRE, batch)
        else:
            self.req = None
            self.status = None

    async def _recv(self, req):
        status = req['status']
        if self.req is None:
            self.req = req
        else:
            for item in status:
                self.req[item].extend(req[item])
        if self.__is_completed(req['status']):
            await self.trigger(Interfaces.FIRE, self.req)

    def __get_entries(self, req):
        return req['entries'] if 'entries' in req else self.entries

    def __get_status(self, entries, req):
        status = {}
        for entry in entries:
            status[entry] = {}
            num_elements = len(req[entry])
            batch_size = entries[entry]
            status[entry]['current'] = 0
            if num_elements % batch_size == 0:
                status[entry]['total'] = num_elements // batch_size
            else:
                status[entry]['total'] = num_elements // batch_size + 1
        return status

    def __is_completed(self, status) -> bool:
        for state in status:
            if status[state]['current'] < status[state]['total']:
                return False
        return True

    def __is_first_batch(self, status) -> bool:
        for state in status:
            if status[state]['current'] != 0:
                return False
        return True

    def __pop_batch(self, entries, req):
        batch = {}
        batch['status'] = self.status
        is_first_batch = self.__is_first_batch(self.status)
        for item in req:
            if item in entries:
                batch[item] = self.__get_batch(item, entries, self.status, req)
                self.status[item]['current'] += 1
            elif is_first_batch:
                batch[item] = req[item]
        return batch

    def __get_batch(self, item, entries, status, req):
        indice = status[item]['current']
        batch_size = entries[item]
        start = indice * batch_size
        end = min(len(req[item]), start + batch_size)
        return req[item][start:end]
