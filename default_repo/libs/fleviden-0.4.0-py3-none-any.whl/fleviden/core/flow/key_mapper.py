# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a key mapper pod that maps keys in the flow to a target key
"""

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod import Pod


class KeyMapper(Pod):
    """
    A pod to map input keys to output keys in the flow.

    The pod takes two parameters, an input_key and an output_key. The pod maps the input key
    in the flow to the output key. This is, given an input dictionary with an entry
    req['input_key'], this entry is removed and the same values are present in the ouput
    in the entry req['output_key'].

    This pod can be useful when connecting other pods that have different naming conventions
    for their inputs and outputs.
    """

    def __init__(self, input_key: str, output_key: str):
        """
        Creates a KeyMapper pod.

        Parameters
        ----------
            input_key : str
                A string with the key to be mapped in the input dictionary.

            output_key : str
                A string with they key to map the input key to.

        Inputs
        ------
            Interfaces.IN (/in)
                A request to map the input dictionary.
        Outputs
        -------
            Interfaces.OUT (/out)
                Triggered after the key mapping is done.
        """
        super().__init__()

        self.input_key = input_key
        self.output_key = output_key

        self.register(Interfaces.IN, self.__map)
        self.register(Interfaces.OUT)

    async def __map(self, req: dict) -> None:
        """
        Maps an input key in req to an output key.

        Parameters
        ----------
            req : dict
                The input dictionary to perform the key mapping on.
        """
        if self.input_key in req:
            req[self.output_key] = req.pop(self.input_key)
        else:
            warning = self.__get_input_key_warning(self.input_key, req)
            await self.trigger(Interfaces.WARNING, warning)
        await self.trigger(Interfaces.OUT, req)

    def __get_input_key_warning(self, key: str, req: dict) -> dict:
        name = "KeyMapperInputKeyWarning"
        description = f"The key {self.input_key} is not present in 'req'"
        details = {"req_keys": list(req.keys())}
        return super()._get_warning(name, description, details)
