# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a timer pod that generates a trigger event after the specified
period has passed.
"""
import asyncio
import time

from fleviden.core.interfaces.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Timer(Pod):
    """
    A Timer pod that generates a trigger after the specified wait time passes. Can be set to
    loop to generate periodic triggers. It can also be stopped manually before reaching the
    timeout.

    The timeout event is notified through the /timeout interface. If stopped manually, the /stopped
    interface will be triggered instead. In both cases the output message contains the
    'elapsed_time' since the start of the timer and the 'iteration' number with how many times
    the loop has been completed.

    The Timer pod is useful to orchestrate events that need to happen on a time-based condition (for
    example, triggering the aggregation of parameters after N seconds have passed without any
    new updates), or to generate periodic actions (e.g., monitoring CPU usage).
    """

    def __init__(self, period: float, one_shot: bool = True):
        """Creates a new Timer pod.

        Parameters
        ----------
            period : float
                Number of seconds to generate the /timeout trigger.

            one_shot : bool, optional
                If True, the timer will run once after starting it with a /start trigger. If False,
                the timer will start again after reaching the end. By default True.

        Inputs
        ------
            Interfaces.START (/start)
                Starts the timer. The period will be updated if the request contains either
                'period' or 'time' with a new value.

            Interfaces.STOP (/stop)
                Stops a running timer.

        Outputs
        -------
            Interfaces.TIMEOUT (/timeout)
                A notification that the period has elapsed.

            Interfaces.STOPPED (/stopped)
                A notification that the timer has been manually stopped.
        """
        super().__init__()
        self.period = period
        self._is_running = False
        self.one_shot = one_shot
        self.stop_event = asyncio.Event()

        self.register(Interfaces.START, self._start)
        self.register(Interfaces.STOP, self._stop)

        self.register(Interfaces.TIMEOUT)
        self.register(Interfaces.STOPPED)

    async def _timer(self) -> None:
        """
        Waits for the specified period and starts over if one_shot is set to False.
        """
        self.is_running = True
        iteration = 0

        while self.is_running:
            iteration += 1
            tik = time.time()
            try:
                # Wait for the specified period, but can be interrupted by stop_event
                await asyncio.wait_for(self.stop_event.wait(), timeout=self.period)
            except asyncio.TimeoutError:
                elapsed_time = time.time() - tik

                # Timeout reached without stop_event being set
                await self.trigger(
                    Interfaces.TIMEOUT, {"elapsed_time": elapsed_time, "iteration": iteration}
                )
                if self.one_shot:
                    self.is_running = False
                    break
            else:
                # Stop was called
                elapsed_time = time.time() - tik
                await self.trigger(
                    Interfaces.STOPPED, {"elapsed_time": elapsed_time, "iteration": iteration}
                )
                break

    async def _start(self, req: dict) -> None:
        """
        Starts the timer by resetting the stop_event and running _timer.
        """
        # Set new wait time
        period = req.get("period", req.get("time", None))
        if period is not None:
            self.period = period

        # Start timer loop
        self.stop_event.clear()
        asyncio.create_task(self._timer())

    async def _stop(self, _req: dict) -> None:
        """
        Stops the timer by setting the stop_event.
        """
        self.is_running = False
        self.stop_event.set()
