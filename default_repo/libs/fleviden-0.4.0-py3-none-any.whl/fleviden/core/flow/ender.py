# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

""" This module provides the implementation of a pod that upon receiving a message
through an interface it ends the fleviden cycle.
"""

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Ender(Pod):
    """The Ender pod allows you to properly finish the fleviden cycle when a message
    is received through a specified wire.

        >>> source_pod = OtherPod(...)
        >>> ender_pod = Ender(wire=Interfaces.FINISH)
        >>> source_pod.link('/other-interface', ender_pod, Interfaces.FINISH)
        >>> ...
        >>> source_pod.trigger('/other-interface', {}) # now the fleviden cycle ends
    """

    def __init__(self, wire: str = Interfaces.FINISH):
        """The constructor of the Ender pod.

        Parameters
        ----------
            wire: str
                The name of the wire that closes the fleviden cycle.

        Inputs
        ------
            wire: str
                Triggers the ending of the fleviden cycle. By default, the wire is
                Interfaces.FINISH (/finish).
        """
        super().__init__()
        self.wire = wire
        self._finished = False
        self.register(self.wire, self.__finish)

    async def __finish(self, _req):
        """Ends the fleviden cycle."""
        if not self._finished:
            self._finished = True
            await Pod.end()
        else:
            warning = self.__get_warning()
            await self.trigger(Interfaces.WARNING, warning)

    def __get_warning(self) -> dict:
        name = "DuplicatedFinishCall"
        description = (
            "The /finish wire in the Ender pod has already been called but this wire must only been"
            " called once per execution."
        )
        details = ""
        return super()._get_warning(name, description, details)
