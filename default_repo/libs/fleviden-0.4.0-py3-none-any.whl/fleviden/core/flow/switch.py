# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a simple switch pod that bypasses the flow if it's on.
"""

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Switch(Pod):
    """
    A pod to forward the input to the output if the switch is on.

    For example:

    Create a switch pod:
        >>> pod_switch = Switch()

    Use another pod to control the switch state:
        >>> other_pod.link("/on-condition", pod_switch, Interfaces.TURN_ON)
        >>> other_pod.link("/off-condition", pod_switch, Interfaces.TURN_OFF)

    Link the pod whose output you want to forward:
        >>> pod_input.link(Interfaces.OUTPUT, pod_switch, Interfaces.FORWARD)
    """

    def __init__(self, default: bool = True):
        """
        Creates a Switch pod.

        Parameters
        ----------
            default : bool
                The default state of the switch. If True, the switch is on
                and the input is forwarded to the output.

        Inputs
        ------
            Interfaces.FORWARD (/forward)
                A request to forward the input to the output.

            Interfaces.TURN_ON (/turn-on)
                A request to turn on the switch.

            Interfaces.TURN_OFF (/turn-off)
                A request to turn off the switch.

        Outputs
        -------
            Interfaces.FORWARDED (/forwarded)
                A notification that the input has been forwarded to the output.

            Interfaces.NOT_FORWARDED (/not-forwarded)
                A notification that the input has not been forwarded to the output.

            Interfaces.TURNED_ON (/turned-on)
                A notification that the switch has been turned on.

            Interfaces.TURNED_OFF (/turned-off)
                A notification that the switch has been turned off.
        """
        super().__init__()

        self.can_forward = default

        self.register(Interfaces.FORWARD, self._forward)
        self.register(Interfaces.FORWARDED)
        self.register(Interfaces.NOT_FORWARDED)

        self.register(Interfaces.TURN_ON, self._on)
        self.register(Interfaces.TURNED_ON)
        self.register(Interfaces.TURN_OFF, self._off)
        self.register(Interfaces.TURNED_OFF)

    async def _forward(self, req: dict) -> None:
        """
        Forward the input to the output if the switch is on.
        """
        if self.can_forward:
            await self.trigger(Interfaces.FORWARDED, req)
        else:
            await self.trigger(Interfaces.NOT_FORWARDED, {})

    async def _on(self, _req: dict) -> None:
        """
        Turn on the switch.
        """
        self.can_forward = True
        await self.trigger(Interfaces.TURNED_ON, {}, info_msg="Switch ON")

    async def _off(self, _req: dict) -> None:
        """
        Turn off the switch.
        """
        self.can_forward = False
        await self.trigger(Interfaces.TURNED_OFF, {}, info_msg="Switch OFF")
