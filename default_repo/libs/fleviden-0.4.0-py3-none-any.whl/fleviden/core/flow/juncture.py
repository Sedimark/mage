# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

""" This module provides the implementation for a juncture that
merges outputs from one or more pods into a single output interface.
"""
import copy
import random

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Juncture(Pod):
    """This pod allows combine several wires into a single one.

    The juncture registers several input wires and when all of them are triggered,
    the juncture combines their outputs into a single output interface that is
    triggered a single time. Afterward, the juncture awaits again for all
    the interfaces.

    Basic example: Wait for the output interfaces of pod1, pod2 and pod3.

        >>> juncture = Juncture(count=3)
        >>> pod1.link('/pod1/wire', juncture, Interfaces.DOCK_0)
        >>> pod2.link('/pod2/wire', juncture, Interfaces.DOCK_1)
        >>> pod3.link('/pod3/wire', juncture, Interfaces.DOCK_2)

    Advanced example: Wait for output interface of pod1 and for one of the pod2 or pod3.

        >>> juncture = Juncture(count=2)
        >>> pod1.link('/pod1/wire', juncture, Interfaces.DOCK_0)
        >>> pod2.link('/pod2/wire', juncture, Interfaces.DOCK_1) # notice the same dock
        >>> pod3.link('/pod3/wire', juncture, Interfaces.DOCK_1) # notice the same dock
    """

    def __init__(
        self,
        count: int,
        keep: bool = False,
        combine: bool = False,
        prefix: str = '/dock',
        output: str = Interfaces.FIRE,
    ):
        """Creates a Juncture instance.

        It creates @count input interfaces prefixed with the @input string followed
        by a hypen and the indice of the interface from zero to @count.

        You can specify whether to @keep the messages sent through each of the input
        interfaces or drop them. If @keep is set to true, once all input interfaces
        are triggered, all messages are combined in a single dictionary with an entry
        for each input wire. The resulting dictionary is sent through @output interface.

        Parameters
        ----------
            count : int
                The number of interfaces to wait for.

            keep : bool
                Whether to keep the messages received from the waited wires.

            combine : bool
                Whether to combine all the requests content instead of creating
                a separated entry in the output interface request.

            prefix : str
                The prefix for each input wire.

            output : str
                The output interface to be triggered after all input wires
                are triggered.

        Inputs
        ------
            prefix-[i] : str
                The input interface for the Juncture instance. As many as count.

        Outputs
        -------
            output : str
                The output interface for the Juncture instance.
        """
        super().__init__()
        self.__count = count
        self.__keep = keep
        self.__combine = combine
        self.__prefix = prefix
        self.__output = output
        self.__received = set()
        self.__reqs = {}
        for i in range(self.__count):
            wire_alias = f'{self.__prefix}-{i}'
            self.register(wire_alias, self.__make_waiter(who=wire_alias))
        self.register(self.__output)

    def __make_waiter(self, who: str) -> callable:
        """Creates a handler for a given alias.

        Parameters
        ----------
            who: str
                The alias of the output interface.

        Returns
        -------
            A function callback.
        """

        async def handler(req):
            self.__received.add(who)
            if self.__keep:
                if self.__combine:
                    self.__reqs.update(req)
                else:
                    self.__reqs[who] = req
            await self._arrival()

        return handler

    async def _arrival(self):
        """Checks that the output interface can be triggered."""
        if self._can_trigger():
            self.__received.clear()
            req = self._get_requests()
            self.__reqs.clear()
            req["req_id"] = random.randint(1, int(1e12))
            await self.trigger(self.__output, req)

    def _can_trigger(self) -> bool:
        """Returns True if the juncture can trigger with the already collected
        output interface requests. False, otherwise.

        Returns
        -------
            bool
                True if the juncture can trigger and False otherwise.
        """
        return len(self.__received) == self.__count

    def _get_received(self) -> set:
        return self.__received

    def _get_count(self) -> int:
        return self.__count

    def _get_requests(self) -> dict:
        """Returns a dictionary containing the requests from the juncture source pods.
        The dictionary contains a key per unique input wire and the interface request
        information as values.

        For example, if there are two registered wires:

            >>> juncture = Juncture(count=2)

        such as each interface trigger as follows:

            >>> juncture.trigger(Interfaces.DOCK_0, {"age": 34})
            >>> juncture.trigger(Interfaces.DOCK_1, {"age": 56})

        then, the return value of this function should be:

            ```
                result = {
                    "dock-0": {
                        "age": 34
                    },
                    "dock-1": {
                        "age": 56
                    }
                }
            ```

        Returns
        -------
            dict
                A dictionary containing the combined request values of the registered
                source pod's output interfaces.
        """
        try:
            return copy.deepcopy(self.__reqs)
        except TypeError:
            return self.__reqs.copy()
