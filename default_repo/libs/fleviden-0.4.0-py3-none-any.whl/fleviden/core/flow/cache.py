# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a simple cache pod that stores data in memory.
"""

import copy
from typing import Optional

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Cache(Pod):
    """
    A Cache pod that stores data in memory.

    You can link a pod's output to the /store interface to store its data, and retrieve
    it later using the /retrieve interface.

    For example, to store the trained weights of a trainer:

    Create a cache pod:
        >>> pod_cache = Cache()

    Link a pod to the cache:
        >>> pod_trainer.link(Interfaces.TRAINED, pod_cache, Interfaces.STORE)

    Retrieve the data from the cache:
        >>> other_pod.link(Interfaces.RETRIEVE, pod_cache, Interfaces.RETRIEVE)
        >>> pod_cache.link(Interfaces.RETRIEVED, pod_trainer, Interfaces.TRAIN)

    Clear the cache:
        >>> pod_trainer.link(Interfaces.EVALUATED, pod_cache, Interfaces.CLEAR)

    Optionally, you can store the messages from more than one pod by setting the overwrite
    parameter to False.
        >>> pod_cache = Cache(overwrite=False)
        >>> pod_1.link(Interfaces.OUT, pod_cache, Interfaces.STORE)
        >>> pod_2.link(Interfaces.OUT, pod_cache, Interfaces.STORE)
    """

    def __init__(self, data: Optional[dict] = None, overwrite: Optional[bool] = True):
        """
        Creates a new cache pod.

        Parameters
        ----------
            data : dict, optional
                Initial data to store at cache.

            overwrite : bool, optional
                If True, each call to Interfaces.STORE (/store) will overwrite the currently
                stored data. If False, the cache will update the saved dictionary with the
                new one, combining them.

        Inputs
        ------
            Interfaces.STORE (/store)
                A request to store data in cache.

            Interfaces.RETRIEVE (/retrieve)
                A request to retrieve data from cache.

            Interfaces.CLEAR (/clear)
                A request to clear the cache.

        Outputs
        -------
            Interfaces.STORED (/stored)
                A notification that data has been stored in cache.

            Interfaces.RETRIEVED (/retrieved)
                A notification with the data retrieved from cache.

            Interfaces.CLEARED (/cleared)
                A notification that the cache has been cleared.
        """
        super().__init__()
        self.cache = data
        self.overwrite = overwrite

        self.register(Interfaces.STORE, self._store)
        self.register(Interfaces.STORED)

        self.register(Interfaces.RETRIEVE, self._retrieve)
        self.register(Interfaces.RETRIEVED)

        self.register(Interfaces.CLEAR, self._clear)
        self.register(Interfaces.CLEARED)

    async def _store(self, req: dict) -> None:
        """
        Store the input request message in cache.
        """
        if self.overwrite or self.cache is None:
            self.cache = req
        else:
            self.cache.update(req)
        await self.trigger(Interfaces.STORED, {})

    async def _retrieve(self, _req: dict) -> None:
        """
        Retrieve the stored message from cache.
        """
        if self.cache is None:
            warning = super()._get_warning(
                "EmptyCacheWarning", "Cache is empty.", f"Retrieved empty data at {self}."
            )
            await self.trigger(Interfaces.WARNING, warning)
        await self.trigger(Interfaces.RETRIEVED, copy.deepcopy(self.cache))

    async def _clear(self, _req: dict) -> None:
        """
        Clear the cache.
        """
        self.cache = None
        await self.trigger(Interfaces.CLEARED, {})
