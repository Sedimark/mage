# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

# IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a utility pod that send messages through different
channels like a fan.
"""

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Rotator(Pod):
    """This class allows to specify a number of wires that gets created and
    triggered in different stages in a round-robin fashion.

    This pod creates a given number of wires named `/send-to-i` where
    i < num_wires.

    When a request via the `/send` wire is received, the `Rotator` pod pick one of
    the `/send-to-i` wires and forward the received request through it.
    """

    def __init__(self, num_wires: int):
        """Creates a new rotator pod.

        Parameters
        ----------
            num_wires : int
                Number of wires to create.

        Inputs
        ------
            Interfaces.SEND (/send)
                A request to send messages through the different wires.

        Outputs
        -------
            /send-to-[i]
                A trigger to send a message through the i-th wire.
        """
        super().__init__()
        self.round = -1
        self.num_wires = num_wires
        self.register(Interfaces.SEND, self._send)
        for i in range(num_wires):
            self.register(f'/send-to-{i}')

    async def _send(self, req: dict):
        self.round = (self.round + 1) % self.num_wires
        await self.trigger(f'/send-to-{self.round}', req)
