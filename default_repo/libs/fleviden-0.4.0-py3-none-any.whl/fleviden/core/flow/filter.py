# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a filter pod to remove unwanted data from the flow.
"""

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Filter(Pod):
    """
    A pod to remove unwanted data from the flow.

    The pod takes a list of keys in the input dictionary. The entries can be removed
    or kept in the output dictionary based on the `remove` parameter.

    This pod can be useful when flow is divided into multiple branches and some branches
    require only a subset of the input data, or can modify the entries in a conflicting way.
    """

    def __init__(self, input_entries: list, remove: bool = False):
        """
        Creates a Filter pod.

        Parameters
        ----------
            input_entries : list
                A list of keys to remove or keep in the output dictionary.

            remove : bool
                If True, the selected entries are removed from the input dictionary.
                If False, the selected entries are kept, and the others are removed.

        Inputs
        ------
            Interfaces.FILTER (/filter)
                A request to filter the input message.

        Outputs
        -------
            Interfaces.FILTERED (/filtered)
                Triggered after the filtering is done.
        """
        super().__init__()

        self.input_entries = set(input_entries)
        self.remove = remove

        self.register(Interfaces.FILTER, self._filter)
        self.register(Interfaces.FILTERED)

    async def _filter(self, req: dict) -> None:
        """
        Filters the input dictionary based on the input entries.

        Parameters
        ----------
            req : dict
                The input dictionary to filter.
        """
        if self.remove:
            output = {key: req[key] for key in req if key not in self.input_entries}
        else:
            output = {key: req[key] for key in req if key in self.input_entries}

        await self.trigger(Interfaces.FILTERED, output)
