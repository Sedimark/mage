# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

""" This module provides the implementation of a pod that triggers other interfaces
automatically at the begining of the fleviden cycle.
"""

import asyncio
from typing import Optional

from fleviden.core.pod.pod import Pod


class Starter(Pod):
    """A Starter pod triggers the specified interfaces at the beggining of the fleviden
    cycle. It can be used for starting a flow of messages through out the program and
    quick specific actions.

        >>> pod_starter = Starter([Interfaces.SEND])
        >>> pod_dst = OtherPod(...)
        >>> pod_starter.link(Interfaces.SEND, pod_dst, Interfaces.RECV)
        >>> ...
        >>> Pod.start() # here the /recv wire is triggered
    """

    def __init__(self, wires: list, payloads: Optional[list] = None):
        """The constructor of a Starter pod.

        Parameters
        ----------
            wires : list
                Contains the name of the wires to be triggered at the begining of
                the fleviden cycle.

            payloads : list
                Contains a list of payloads to be sent for each of the specified
                wires. It must contain an entry for each of the wires or None in which case an empty
                payload is sent when the wires are triggered.

        Outputs
        -------
            wires : list
                The wires to be triggered.
        """
        super().__init__()
        self.__wires = wires
        self.__payloads = payloads or [{} for _ in wires]
        self.__check(self.__wires, self.__payloads)
        for wire in wires:
            self.register(wire)

    def __check(self, wires: list, payloads: list) -> None:
        """Checks that the number of wires and payloads
        match and that the payloads are dictionaries.
        """
        assert len(wires) == len(payloads)
        for payload in payloads:
            assert isinstance(payload, dict)

    async def on_run(self):
        """Triggers all the wires specified in the
        constructor and send the corresponding payloads.
        """
        zip_wire_payload = zip(self.__wires, self.__payloads)
        triggers = [self.trigger(wire, payload) for wire, payload in zip_wire_payload]
        await asyncio.gather(*triggers)
