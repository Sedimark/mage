# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

# IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module provides the implementation for a juncture that
merges outputs from one or more pods into a single output interface,
while retaining previous request information for specified output
interfaces to avoid triggering every time.
"""

from typing import Optional

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Repeater(Pod):
    """This class allows to repeat a messages a given number of times."""

    def __init__(self, num_times: Optional[int] = None, ticking: bool = True):
        """
        Initialize a Repeater object.

        Parameters
        ----------
            num_times : int, optional
                The number of times the repeater should repeat its actions.

            ticking : bool, optional
                Specifies whether the repeater should tick (execute its actions) automatically or not.

        Inputs
        ------
            Interfaces.SEND (/send)
                A request to send messages a given number of times.

            Interfaces.TICK (/tick)
                A request to send messages a given number of times at each tick.

        Outputs
        -------
            Interfaces.FIRE (/fire)
                A trigger that is fired when the repeater is triggered.
        """
        super().__init__()
        self.num_times = num_times
        self.ticking = ticking
        self.repetition = 0
        self.req = None
        self.register(Interfaces.SEND, self._send)
        self.register(Interfaces.TICK, self._tick)
        self.register(Interfaces.FIRE)

    async def _send(self, req):
        num_times = self.__get_num_times(req)
        for _ in range(num_times):
            await self.trigger(Interfaces.FIRE, req)

    async def _tick(self, req):
        self.num_times = self.__get_num_times(req)
        if self.req is None:
            self.req = req
        if self.repetition < self.num_times:
            self.repetition += 1
            await self.trigger(Interfaces.FIRE, self.req)
        else:
            self.req = None
            self.repetition = 0

    def __get_num_times(self, req) -> int:
        if 'num_times' in req:
            self.num_times = req['num_times']
        return self.num_times or 0
