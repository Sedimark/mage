# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.
# IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module implements a collector pod that collects a number of inputs before triggering an output.
"""
import copy
from typing import Optional

from fleviden.core.interfaces import Interfaces
from fleviden.core.pod.pod import Pod


class Collector(Pod):
    """
    A Pod that collects a number of inputs before triggering an output. The number of
    inputs to collect can be updated using the /update-count interface. The output is
    triggered when the expected number of inputs has been received or when the /send-output
    interface is triggered manually.

    By specifying the input_entry, the collector will only save the value of the
    specified entry in the input message. If no input_entry is specified, the
    whole input message will be saved.

    The output_entry specifies the key under which the collected entries will be
    saved in the output message. If no output_entry is specified, the collected
    entries will be saved under the same key as the input message.

    For example, if you want to collect 2 entries with the key "data" and save
    them under the key "output", you would use the following configuration.

    Create a collector pod.
        >>> Collector(2, input_entry="data", output_entry="output")

    Save the entries at "data" by triggering the "/input" interface.
        >>> await collector.trigger("/input", {"data": "test data 1"})
        >>> await collector.trigger("/input", {"data": "test data 2"})

    The output will be:
        >>> {"output": ["test data 1", "test data 2"]}

    """

    def __init__(
        self,
        count: int,
        input_entry: Optional[str] = None,
        output_entry: Optional[str] = None,
    ):
        """
        Creates a new Collector pod.

        Parameters
        ----------
            count : int
                The number of inputs to collect before triggering the output. This value can be
                updated using the /update-count interface. You can also manually trigger
                the output using the /send-output interface, independent of the number of
                inputs received.

            input_entry : str
                The key of the entry to save in the input message. If None, the whole
                input message will be saved.

            output_entry : str
                The key under which the collected entries will be saved in the output message.
                If None, the collected entries will be saved under the same key as the input
                message.

        Inputs
        ------
            Interfaces.INPUT (/input)
                Saves the input data.

            Interfaces.SEND_OUTPUT (/send-output)
                Triggers the /output with the collected entries regardless of the number of inputs
                received.

            Interfaces.CLEAR (/clear)
                Clears the saved entries.

            Interfaces.UPDATE_COUNT (/update-count)
                Updates the number of expected inputs. The new value can be provided in the
                "count" key, the "num_clients" key, or as the length of the "clients" list.

        Outputs
        -------
            Interfaces.OUTPUT (/output)
                Triggered with the collected entries after the expected number of inputs
                has been received or when the /send-output interface is triggered.

            Interfaces.CLEARED (/cleared)
                Triggers when the collected entries are cleared.

            Interfaces.UPDATED_COUNT (/updated-count)
                Triggers when the number of expected inputs has been updated.
        """
        super().__init__()
        self.count = count
        self.input_entry = input_entry
        self.output_entry = output_entry if output_entry else input_entry

        self.received = []

        self.register(Interfaces.INPUT, self._on_input)
        self.register(Interfaces.SEND_OUTPUT, self._output)
        self.register(Interfaces.OUTPUT)

        self.register(Interfaces.CLEAR, self._clear)
        self.register(Interfaces.CLEARED)

        self.register(Interfaces.UPDATE_COUNT, self._update_count)
        self.register(Interfaces.UPDATED_COUNT)

    async def _clear(self, _req: dict) -> None:
        """Clears the received entries"""
        self.received = []

        await self.trigger(Interfaces.CLEARED, {})

    async def _update_count(self, req: dict) -> None:
        """Updates the number of expected inputs"""
        self.count = req.get("count", req.get("num_clients", len(req.get("clients", []))))

        await self.trigger(Interfaces.UPDATED_COUNT, {"count": self.count})

    async def _output(self, _req: dict) -> None:
        """Triggers the output with the collected entries"""

        count = len(self.received)
        output = {self.output_entry: copy.deepcopy(self.received)}

        # Clear the received entries up to the count that triggered the output
        self.received = self.received[count:]

        await self.trigger(
            Interfaces.OUTPUT,
            output,
            info_msg=f'Collected {count}/{self.count} entries. Triggering output.',
        )

    async def _on_input(self, req: dict) -> None:
        """Saves the input and triggers the output if all the expected
        inputs have been received. The received entries are then cleared."""

        # Save an entry or the whole message
        if self.input_entry:
            if self.input_entry in req:
                self.received.append(req[self.input_entry])
            else:
                error = {
                    "name": "CollectorInputEntryError",
                    "description": f"Input entry '{self.input_entry}' not found in req.",
                    "details": {"keys": list(req.keys()), "input_entry": self.input_entry},
                }
                await self.trigger(Interfaces.ERROR, error)
        else:
            self.received.append(copy.deepcopy(req))

        # If we have received all the expected entries, trigger the output
        if len(self.received) == self.count:
            await self._output({})
