# Copyright (c) 2022-2025 Eviden SAS. All Rights Reserved.

# IMPORTANT: This software is proprietary and confidential. Unauthorized copying,
# redistribution, modification, or use of this software, in source or binary form,
# is strictly prohibited without the prior written consent of Eviden SAS.

"""
This module provides the implementation for a juncture that
merges outputs from one or more pods into a single output interface,
while retaining previous request information for specified output
interfaces to avoid triggering every time.
"""

import copy
import threading

from fleviden.core.flow.juncture import Juncture
from fleviden.core.interfaces import Interfaces


class Memory(Juncture):
    """The Memory pod is a subtype of Juncture pod that can be used
    to block the trigger of a certain pod/interface behind other prior
    triggers (for example, triggering pod_trainer/evaluate only after
    loading the data with pod_loader/load), with the extra feature of
    remembering selected input triggers so that they only have to be
    received once.

    This is useful in scenarios where agents perform an initial handshake
    to share some kind of key that is necessary for a protocol to work,
    so that the key is stored for later reuse.
    """

    def __init__(
        self,
        count: int,
        keep: bool = False,
        combine: bool = False,
        prefix: str = '/dock',
        output: str = Interfaces.FIRE,
    ):
        """Creates a Juncture instance.

        Parameters
        ----------
            count : int
                The count parameter for the Juncture instance.

            keep : bool, optional
                Whether to keep the Juncture instance, by default False.

            combine : bool, optional
                Whether to combine the Juncture instance, by default False.

            prefix : str, optional
                The prefix for the Juncture instance, by default '/dock'.

            output : str, optional
                The output for the Juncture instance, by default '/fire'.

        Inputs
        ------
            prefix-[i] : str
                The input interface for the Juncture instance. As many as count.

        Outputs
        -------
            output : str
                The output interface for the Juncture instance.
        """
        super().__init__(count, keep, combine, prefix, output)
        self.can_update = threading.Lock()

        self.once_pods = []
        self.received_once = set()
        self.once_reqs = {}

    def remember(self, pod, route: str, alias: str) -> None:
        """
        Registers a source pod/interface so that it
        is memorized with an alias of choice. After the registered
        interface is fired at least once, there is no need for a trigger
        to happen again.

        For example:
            >>> pod_memory = Memory(count=2, prefix=Interfaces.IN, output=Interfaces.OUT)
            >>> pod_key.link(Interfaces.SEND, pod_memory, Interfaces.IN_X[0])
            >>> pod_encrypted.link(Interfaces.SEND, pod_memory, Interfaces.IN_X[1])

            >>> pod_memory.remember(pod_key, Interfaces.SEND, Interfaces.IN_X[0])
            >>> pod_memory.link(Interfaces.OUT, pod_decrypt, Interfaces.DECODE)

        Here, the "/out" interface will require both pod_key/send and pod_encrypted/send
        to trigger for the first time, but then onwards, only the pod_encrypted/send will
        suffice, as the pod_key is memorized.

        Parameters
        ---------
            pod : Pod
                The source pod.

            route : str
                The output interface of the specified source pod.

            alias : str
                A unique alias for the specified output interface.
        """
        self.once_pods.append(pod)
        self.once_reqs[alias] = {}
        pod.register(route, self.__make_rememberer(who=alias))

    def __make_rememberer(self, who: str) -> callable:
        """Creates a handler for a given alias.

        Parameters
        ----------
            who : str
                The alias of the output interface.

        Returns
        -------
            handler: callable
                A function that can be registered in the source pod.
        """

        async def handler(req):
            with self.can_update:
                try:
                    self.once_reqs[who] = copy.deepcopy(req)
                except Exception:
                    self.once_reqs[who] = req.copy()
                self.received_once.add(who)
            await self._arrival()

        return handler

    def _can_trigger(self) -> bool:
        total_received = self._get_received().union(self.received_once)
        count = self._get_count()
        return len(total_received) == count

    def _get_requests(self) -> dict:
        return {**super()._get_requests(), **self.once_reqs}
